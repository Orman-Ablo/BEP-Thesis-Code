classdef vectorfitter < handle
    properties (SetAccess = immutable, GetAccess = private)
        handle uint64;
    end
    methods (Access = public)
        function this = vectorfitter(spots, roixy, params, compute_device)
            %vectorfitter(spots, roixy, params, compute_device)
            % Construct vectorfitter object.
            % The input consists of 4D spot data, roixy spot locations, a params struct and
            % a compute device string ("cpu" or "gpu").
            this.handle = vectorfit_create(spots, roixy, params, compute_device);
        end
        function theta = theta_init(this)
            %theta_init Initialize theta.
            % The resulting theta_init is returned for reference.
            theta = vectorfit_theta_init(this.handle);
        end
        function theta = theta_init_with_aberrations(this, nat_gammas, aberration_orders)
            %theta_init Initialize theta while using computed Zernike coefficients
            % from nat_gammas and aberration orders.
            % The resulting theta_init is returned for reference.
            vectorfit_update_zernike_coefficients(this.handle, nat_gammas, aberration_orders);
            theta = vectorfit_theta_init(this.handle);
        end
        function theta = flip_z(this)
            %flip_z()
            % Flip Z-coordinate in theta vector.
            % Optionally, the new theta is returned for reference.
            theta = vectorfit_flip_z(this.handle);
        end
        function [theta, num_iters] = local_update(this)
            %local_update()
            % Perform local update of theta.
            % Returns the updated theta and the number of iterations per spot.
            [theta, num_iters] = vectorfit_local_update(this.handle);
        end
        function mu = mu(this)
            %mu()
            % Mu for all spots from the last local update.
            % Note that for unconverged spots, mu is incorrect
            % (it contains the result of the last unsuccessful iteration).
            % Returns a matrix with mu per spot.
            mu = vectorfit_get_mu(this.handle);
        end
        function dmudtheta = dmudtheta(this)
            %mu()
            % dMu/dTheta for all spots from the last local update.
            % Note that for unconverged spots, dmudtheta is incorrect
            % (it contains the result of the last unsuccessful iteration).
            % Returns a matrix with dMu/dTheta per spot.
            dmudtheta = vectorfit_get_dmudtheta(this.handle);
        end
        function outliers = outliers(this)
            %outliers()
            % Compute the outliers from the last local update.
            % Returns an array of spot indices of the outliers.
            outliers = vectorfit_get_outliers(this.handle);
        end
        function fisher_crlb = fisher_crlb(this)
            %fisher_crlb()
            % Compute the Fisher CRLB from the last local update.
            % Returns a matrix with the parameter bounds per spot.
            % Note: returns NaN-values in case of matrix inversion problems.
            fisher_crlb = vectorfit_get_fisher_crlb(this.handle);
        end
        function coeffs = update_zernike_coefficients(this, nat_gammas, aberration_orders)
            %update_zernike_coefficients(nat_gammas, aberration_orders)
            % Recompute Zernike coefficients from nat_gammas and aberration orders
            % and store them in theta.
            % The normalized FOV coordinates are computed from X and Y
            % from the current state of theta.
            % Note that this function can also be called before theta_init() to improve the initial estimates.
            coeffs = vectorfit_update_zernike_coefficients(this.handle, nat_gammas, aberration_orders);
        end
        function [otfs, spot_otf_indices] = update_otfs(this, nat_gammas, aberration_orders)
            %update_otfs(nat_gammas, aberration_orders)
            % Recompute OTFs from nat_gammas and aberration orders.
            % Returns the computed OTFs and the OTF index per spot.
            [otfs, spot_otf_indices] = vectorfit_update_otfs(this.handle, nat_gammas, aberration_orders);
        end
        function set_otfs(this, otfs, spot_otf_indices)
            %set_otfs(otfs, spot_otf_indices)
            % Set OTFs and the OTF index per spot from externally computed values.
            vectorfit_set_otfs(this.handle, otfs, spot_otf_indices);
        end
        function pupil_matrix = get_pupil_matrix(this, zernike_coefficients)
            %get_pupil_matrix(zernike_coefficients)
            % Get the pupil matrix for the given Zernike coefficients
            pupil_matrix = vectorfit_get_pupil_matrix(this.handle, zernike_coefficients);
        end
        function [mu, dmudtheta] = get_modeled_spot(this, spot_index)
            %get_modeled_spot(spot_index)
            % WARNING: Debug function only. Still crashes when using the GPU device.
            % Get the modeled spot for the given spot index in the form of mu and dmudtheta,
            % based on the current state of theta.
            [mu, dmudtheta] = vectorfit_get_modeled_spot(this.handle, spot_index);
        end
        function delete(this)
            %delete Destroy vectorfitter object.
            vectorfit_destroy(this.handle);
        end
    end
end
