#include <string>
#include <cstring>

#include "yaml-cpp/yaml.h"
#include "Parameters.h"

// Return true if lhs and rhs are equal, ignoring things like underscores, spaces, capitals, etc.
bool string_inexact_match(const char* lhs, const char* rhs) {
	if (lhs == nullptr || rhs == nullptr) {
		return lhs == rhs;
	}

	while (*lhs || *rhs) {
		char l = *lhs;
		char r = *rhs;

		if (tolower(l) == tolower(r)) {
			lhs++;
			rhs++;
		} else if (isspace(l) || l == '-' || l == '_') {
			lhs++;
		} else if (isspace(r) || r == '-' || r == '_') {
			rhs++;
		} else {
			return false;
		}
	}

	return *lhs == *rhs;
}

YAML::Node delete_key(YAML::Node& config, const std::string& needle) {
	for (auto p: config) {
		std::string key = p.first.as<std::string>();

		if (string_inexact_match(needle.c_str(), key.c_str())) {
			YAML::Node out = Clone(p.second);
			config.remove(p.first);
			return out;
		}
	}

	return config[needle];
}

template <typename T>
static T parse_item(YAML::Node& config, const std::string key, T def = {}) {
	YAML::Node val = delete_key(config, key);
	if (val) {
		return val.as<T>();
	} else {
		return def;
	}
}

static double parse_double(YAML::Node& config, const std::string& key, double def = 0.0) {
	return parse_item(config, key, def);
}

static int parse_int(YAML::Node& config, const std::string& key, int def = 0) {
	return parse_item(config, key, def);
}

static std::string parse_string(YAML::Node& config, const std::string& key, std::string def = "") {
	return parse_item(config, key, def);
}

static int parse_bool(YAML::Node& config, const std::string& key, bool def = false) {
	return parse_item(config, key, def);
}

template <typename T, size_t N>
static fixed_vector<T, N> parse_array(YAML::Node& config, const std::string& key, fixed_vector<T, N> def = {}) {
	YAML::Node val = delete_key(config, key);
	if (!val) {
		return def;
	}

	fixed_vector<T, N> result = def;
	for (size_t i = 0; i < N; i++) {
		result[i] = val[i].as<T>();
	}
	return result;
}

template <typename T>
static T parse_enum(YAML::Node& config, const std::string& key, T def, std::vector<std::pair<std::string, T>> options) {
	YAML::Node val = delete_key(config, key);
	if (!val) {
		return def;
	}

	auto item = val.as<std::string>();

	for (auto& p: options) {
		if (string_inexact_match(item.c_str(), p.first.c_str())) {
			return p.second;
		}
	}

	throw std::runtime_error("unknown option for " + key + ": " + item);
}

FitModelEnum parse_fitmodel(YAML::Node& config, const std::string& key) {
	std::string model = parse_string(config, key, "xy");
	return FitParams::get_fitmodel_from_string(model);
}

FitModelEnum FitParams::get_fitmodel_from_string(const std::string& model) {
	static std::vector<FitModelEnum> models = {
			FitModelEnum::xy,
			FitModelEnum(FitModelEnum::xy_constaberrations, FitParams::MaxNaberr),
			FitModelEnum::xy_azim,
			FitModelEnum::xy_azim_pola,
			FitModelEnum::xy_azim_diffusion,
			FitModelEnum::xy_azim_pola_diffusion,
			FitModelEnum::xyz,
			FitModelEnum(FitModelEnum::xyz_constaberrations, FitParams::MaxNaberr),
			FitModelEnum(FitModelEnum::xyz_aberrations, FitParams::MaxNaberr),
			FitModelEnum::xyz_azim_pola,
			FitModelEnum(FitModelEnum::xyz_azim_pola_aberrations, FitParams::MaxNaberr),
			FitModelEnum::xyz_azim_pola_diffusion,
			FitModelEnum(FitModelEnum::xyz_azim_pola_diffusion_aberrations, FitParams::MaxNaberr),
	};

	for (auto p: models) {
		if (string_inexact_match(p.to_string().c_str(), model.c_str())) {
			return p;
		}
	}

	throw std::runtime_error("unknown fit model: " + model);
}

FitParams FitParams::parse_file(const std::string& file_path) {
	YAML::Node config;

	try {
		config = YAML::LoadFile(file_path);
	} catch (const std::exception& e) {
		throw std::runtime_error("error while reading " + file_path + ": " + e.what());
	}

	FitModelEnum fitModel = parse_fitmodel(config, "fitmodel");// xyz_azim_pola_diffusion;
	FitParams out(fitModel);

	out.NA = parse_double(config, "NA", out.NA);
	out.RefMed = parse_double(config, "RefMed", out.RefMed);
	out.RefCov = parse_double(config, "RefCov", out.RefCov);
	out.RefImm = parse_double(config, "RefImm", out.RefImm);
	out.RefImmNom = parse_double(config, "RefImmNom", out.RefCov);
	out.Lambda = parse_double(config, "Lambda", out.Lambda);
	out.LambdaCentral = parse_double(config, "LambdaCentral", out.LambdaCentral);
	out.LambdaSpread = parse_array<double, 2>(config, "LambdaSpread", out.LambdaSpread);
	out.imgSizeX = parse_int(config, "imgSizeX", out.imgSizeX);
	out.imgSizeY = parse_int(config, "imgSizeY", out.imgSizeY);
	out.NiterMax = parse_int(config, "NiterMax", out.NiterMax);
	out.Tollim = parse_double(config, "Tollim", out.Tollim);
	out.Varfit = parse_double(config, "Varfit", out.Varfit);
	out.NPupil = parse_int(config, "NPupil", out.NPupil);

	out.PixelSize = parse_double(config, "PixelSize", out.PixelSize);
	out.SamplingDistance = parse_double(config, "SamplingDistance", out.PixelSize);
	out.Fwd = parse_double(config, "Fwd", out.Fwd);
	out.Depth = parse_double(config, "Depth", out.Depth);
	out.ZRange = parse_array<double, 2>(config, "ZRange", out.ZRange);
	out.ZSpread = parse_array<double, 2>(config, "ZSpread", out.ZSpread);

	out.zstage = parse_double(config, "zstage", out.zstage);

//	int Spot_dim = parse_int(config, "Spot_dim", 9);
//	out.Mx = Spot_dim;
//	out.My = Spot_dim;
//	const int Mz=1;
//	out.K = parse_int(config, "K", out.K);
	int K = parse_int(config, "K", 1);
	if (K > 1 && !fitModel.has_z()) {
		throw std::runtime_error("failed to parse " + file_path + ": cannot have K > 1 if fit model does not have Z");
	}
	out.Mz = K;

	out.XRange = parse_double(config, "XRange", out.PixelSize * out.Mx / 2);
	out.YRange = parse_double(config, "YRange", out.PixelSize * out.My / 2);
	out.PupilSize = parse_double(config, "PupilSize", out.NA / out.Lambda);

	out.ZType = parse_enum(config, "ZType", out.ZType, {
			{"stage", ZTypeEnum::stage},
			{"medium", ZTypeEnum::medium}
	});

	out.DoeType = parse_enum(config, "DoeType", out.DoeType, {
			{"vortex", DoeTypeEnum::vortex},
			{"none", DoeTypeEnum::none}
	});

	out.DipoleType = parse_enum(config, "DipoleType", out.DipoleType, {
			{"free", DipoleTypeEnum::free},
			{"fixed", DipoleTypeEnum::fixed},
			{"diffusion", DipoleTypeEnum::diffusion}
	});

	out.Excitation = parse_enum(config, "Excitation", out.Excitation, {
			{"constant", ExcitationEnum::constant},
			{"zstack", ExcitationEnum::zstack}
	});

//	static constexpr int Naberr = 12;

	out.RingRadius = parse_int(config, "RingRadius", out.RingRadius);
	out.DoeLevels = parse_int(config, "DoeLevels", out.DoeLevels);
	out.DoePhaseDepth = parse_int(config, "DoePhaseDepth", out.DoePhaseDepth);
	out.DoeVortexFlip = parse_int(config, "DoeVortexFlip", out.DoeVortexFlip);

	out.Alpha = parse_double(config, "Alpha", out.Alpha);
	out.Beta = parse_double(config, "Beta", out.Beta);
	out.ReadNoiseStd = parse_double(config, "ReadNoiseStd", out.ReadNoiseStd);
	out.ReadNoiseVariance = parse_double(config, "ReadNoiseVariance", out.ReadNoiseVariance);

	out.Notfx = parse_int(config, "Notfx", out.Notfx);
	out.Notfy = parse_int(config, "Notfy", out.Notfy);
	if (fitModel.has_z()) {
		out.Notfz = parse_int(config, "Notfz", out.Notfz);
	} // else: use default value of 1
	out.Mpsfx = parse_int(config, "Mpsfx", out.Mpsfx);
	out.Mpsfy = parse_int(config, "Mpsfy", out.Mpsfy);
	if (fitModel.has_z()) {
		out.Mpsfz = parse_int(config, "Mpsfz", out.Mpsfz);
	} // else: use default value of 1
	out.PsfXRange = parse_double(config, "PsfXRange", out.PixelSize * out.Mpsfx / 2.0);
	out.PsfYRange = parse_double(config, "PsfYRange", out.PixelSize * out.Mpsfy / 2.0);
	out.PsfZRange = parse_double(config, "PsfZRange", out.PixelSize * out.Mpsfz / 2.0);

	out.FlagOTF = parse_bool(config, "FlagOTF", out.FlagOTF);
	out.OTFGridSizeX = parse_int(config, "OTFGridSizeX", out.OTFGridSizeX);
	out.OTFGridSizeY = parse_int(config, "OTFGridSizeY", out.OTFGridSizeY);
	out.psf_blur = parse_bool(config, "PSFBlur", out.psf_blur);
	out.initialization = parse_enum(config, "initialization", out.initialization, {
			{"phasor", InitializationMethod::phasor},
			{"centroid", InitializationMethod::centroid},
	});

	out.NumThreads = parse_int(config, "NumThreads", out.NumThreads);

	for (auto p: config)
	{
		std::cerr << "warning: ignoring unknown key \"" << p.first << "\" in " << file_path << "\n";
	}

	if (out.FlagOTF && out.FitModel != FitModelEnum::xy)
	{
		throw std::runtime_error("OTF only support for fitting xy");
	}

	return out;
}