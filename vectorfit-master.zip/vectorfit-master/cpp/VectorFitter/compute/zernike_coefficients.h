#pragma once

#include "array/host_array.h"

namespace compute {

namespace zernike_coefficients {

struct Aberration
{
    int radial_order;
    int azimuthal_order;
    double coefficient;
};

// Returns the number of NAT gammas supported by this implementation of the Zernike coefficients computation
size_t num_nat_gammas();

//TODO: Arr2D<double> compute_xy_gamma(const Arr1D<double>& xn, const Arr1D<double>& yn, const Arr1D<double>& gammas, const Arr1D<Aberration>& aberrations);

// Computes the Zernike coefficients for the given NAT gammas and FOV coordinates (xn,yn)
void compute_xy_gamma_legendre(
    const Arr1D<double>& xn,
    const Arr1D<double>& yn,
    const Arr1D<double>& gammas,
    const Arr1D<Aberration>& aberrations,
    WriteView2D<double> coeffs
);

} // namespace zernike_coefficients

} // namespace compute
