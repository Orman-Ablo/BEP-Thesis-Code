#pragma once

#include "array/host_array.h"
#include "Fitter.h"
#include "Parameters.h"


/* VectorfitFitter
 *
 * State object that stores spots, estimator and more.
*/
class VectorfitFitter
{
public:
    VectorfitFitter(
        Arr4D<double>&& spots,
        Arr2D<double>&& roixy,
        const FitParams& params,
        const std::string& compute_device
    )
    : _fitter(std::move(spots), std::move(roixy), params, compute_device)
    {
        //std::cout << "DEBUG: created vectorfitter " << reinterpret_cast<uint64_t>(this) << std::endl;
    }
    virtual ~VectorfitFitter()
    {
        //std::cout << "DEBUG: deleted vectorfitter " << reinterpret_cast<uint64_t>(this) << std::endl;
    }

    const Fitter& fitter() const { return _fitter; }
    Fitter& fitter() { return _fitter; }

protected:
    Fitter _fitter;
};

/* VectorfitMemoryManager
 *
 * Memory manager that facilidates creating and destroying
 * VectorfitFitter objects from MEX functions.
*/
class VectorfitMemoryManager
{
public:
    virtual ~VectorfitMemoryManager()
    {
        clear();
    }

    // Create a VectorfitFitter object and return its handle
    uint64_t create(
        Arr4D<double>&& spots,
        Arr2D<double>&& roixy,
        FitParams&& params,
        const std::string& compute_device
    )
    {
        // Cleanup old pointers
        cleanup_empty_ptrs();

        // Create a unique_ptr to a VectorfitFitter object using new.
        // This unique_ptr object is deleted in cleanup_ptrs() (if vectorfit_destroy() was called)
        // or eventually in the destructor.
        // A raw pointer to the unique_ptr object is stored in _fitter_ptrs.
        std::unique_ptr<VectorfitFitter>* fitter_uptr_ptr =
            new std::unique_ptr<VectorfitFitter>(
                new VectorfitFitter(std::move(spots), std::move(roixy), std::move(params), compute_device)
            );

        _fitter_ptrs.push_back(fitter_uptr_ptr);

        uint64_t handle = reinterpret_cast<uint64_t>(fitter_uptr_ptr);
        //std::cout << "DEBUG: Vectorfit object created" << std::endl;
        return handle;
    }

    // Destroy a VectorfitFitter object by its handle.
    // This function can be static by operating on pointers only.
    // A MemoryManager's memory is auto-cleaned when creating
    // new obects using create(), and in its destructor.
    static void destroy(uint64_t handle)
    {
        std::unique_ptr<VectorfitFitter>* fitter_uptr_ptr =
            reinterpret_cast<std::unique_ptr<VectorfitFitter>*>(handle);

        if ((handle != 0) && *fitter_uptr_ptr)
        {
            fitter_uptr_ptr->reset();
            //std::cout << "DEBUG: Vectorfit object destroyed" << std::endl;
        }
        else
        {
            std::cout << "DEBUG: Vectorfit object already destroyed" << std::endl;
        }
    }

    // Obtain a pointer to a VectorfitFitter object from its handle
    static VectorfitFitter* get(uint64_t handle)
    {
        std::unique_ptr<VectorfitFitter>* fitter_uptr_ptr =
            reinterpret_cast<std::unique_ptr<VectorfitFitter>*>(handle);

        return fitter_uptr_ptr->get();
    }

protected:

    void cleanup_empty_ptrs()
    {
         // Cleanup empty unique_ptr's (they were reset by vectorfit_destroy())
        for (auto it = _fitter_ptrs.begin(); it != _fitter_ptrs.end(); /*do not auto increment*/)
        {
            std::unique_ptr<VectorfitFitter>* fitter_uptr_ptr = *it;
            // If the unique ptr is empty, remove it from the vector
            if (!fitter_uptr_ptr->get())
            {
                // Delete the unique_ptr object itself
                delete fitter_uptr_ptr;
                // Remove it from the vector
                _fitter_ptrs.erase(it);
                std::cout << "DEBUG: cleaned up empty pointer" << std::endl;
            }
            else
            {
                ++it;
            }
        }
    }

    void clear()
    {
        // Final cleanup of all created objects
        while (_fitter_ptrs.size() > 0)
        {
            std::unique_ptr<VectorfitFitter>* fitter_uptr_ptr = _fitter_ptrs.back();
            // Reset the unique ptr to delete the underlying VectorfitFitter object,
            // if it still exists
            if (fitter_uptr_ptr->get())
            {
                fitter_uptr_ptr->reset();
                std::cout << "DEBUG: destroyed leftover vectorfit object" << std::endl;
            }
            // Delete the unique_ptr object itself
            delete fitter_uptr_ptr;
            // Remove it from the vector
            _fitter_ptrs.pop_back();
        }
    }

    std::vector<std::unique_ptr<VectorfitFitter>*> _fitter_ptrs;
};
