#pragma once

#include "MultiDimArray.h"

class BaseEstimator {
public:
	virtual ~BaseEstimator() = default;

	/**
	 * Calculate the initial parameter vectors (Theta) for the given spots.
	 *
	 * @param Spots Should have shape `[N, Mx, My, K]` where N is the number of spots, Mx/My is the spot dimensions and
	 *              K is the number of layers.
	 * @param ThetaInit Should have shape `[N, numparams]` where numparams is the number theta parameters.
	 */
	virtual void InitializeSpots(
			View4D<double> Spots,
			WriteView2D<double> ThetaInit) = 0;

	/**
	 * Find optimal parameter vectors (Theta) for the given spots.
	 *
	 * @param Spots Should have shape `[N, Mx, My, K]` where N is the number of spots, Mx/My are the spot dimensions
	 * 				and K is the number of layers.
	 * @param ThetaInit Should have shape `[N, numparams]` where numparams it he number of theta prameters.
	 * @param ThetaStore Should have shape `[N, numparams, iter]` where `iter` is the iteration number.
	 * @param mu Resulting Mu. Should have shape `[N, Mx, My, K]`.
	 * @param dmudtheta Derivatives of Mu over theta. Should have shape `[N, Mx, My, K, numparams]`.
	 * @param Merit Merit scores. Should have shape `[N, iter]`.
	 * @param NumIters Iterations performed per spots.
	 */
	virtual void LocalizeSpots(
			View4D<double> AllSpots,
			View2D<double> ThetaInit,
			WriteView3D<double> ThetaStore,
			WriteView4D<double> mu,
			WriteView5D<double> dmudtheta,
			WriteView2D<double> Merit,
			WriteView1D<int> NumIters,
			WriteView1D<bool> IsConverged) = 0;

	/**
	 * Set OTFs and an OTF index per spot. Only used when the estimator suports working with OTFs.
	 */
	virtual void SetOTFs(View4D<std::complex<double>> OTFs, View1D<int> SpotOTFIndices) {
		throw std::logic_error("SetOTFs not implemented for this estimator");
	};

};