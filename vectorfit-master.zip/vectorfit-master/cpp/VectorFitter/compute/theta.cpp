#include "compute/theta.h"
#include "compute/common.h"
#include "MultiDimArray.h"
#include "Parameters.h"
#include <Eigen/Dense>

namespace compute {

void ThetaLimits(
		const FitParams& AllParams,
		View1D<double> theta,
		WriteView1D<double> thetamin,
		WriteView1D<double> thetamax,
		WriteView1D<double> thetaretry)
{
	FitModelEnum fitmodel = AllParams.FitModel;
	const int NAberr = fitmodel.num_aberrations();
	const bool has_aberr = fitmodel.has_fitted_aberrations();

	double roisizex = AllParams.Mx * AllParams.PixelSize;
	double roisizey = AllParams.My * AllParams.PixelSize;

	double xmin = -roisizex / 2.0;
	double xmax = roisizex / 2.0;
	double ymin = -roisizey / 2.0;
	double ymax = roisizey / 2.0;
	double zmin = AllParams.ZSpread[0];
	double zmax = AllParams.ZSpread[1];

	if (has_aberr) {  // This seems to be the only impact of aberrations?
		double deltaz = zmax - zmin;
		zmin -= 0.5 * deltaz;
		zmax += 0.5 * deltaz;
	}

	double azimmax = 2 * M_PI;
	double polamax = M_PI;

	// x
	index_t index = fitmodel.offset_x();
	thetamin[index] = xmin;
	thetamax[index] = xmax;

	// y
	index = fitmodel.offset_y();
	thetamin[index] = ymin;
	thetamax[index] = ymax;

	// z
	if (fitmodel.has_z()) {
		index = fitmodel.offset_z();
		thetamin[index] = zmin;
		thetamax[index] = zmax;
	}

	// Nph
	index = fitmodel.offset_nph();
	thetamin[index] = theta[index] / 10.0;
	thetamax[index] = 2.0 * theta[index];

	// bg
	index = fitmodel.offset_nbg();
	thetamin[index] = theta[index]/ 10.0;
	thetamax[index] = std::max(theta[fitmodel.offset_nph()] / AllParams.Mx / AllParams.My / 2.0, 2.0 * theta[index]);

	// Azim
	if (fitmodel.has_azim()) {
		index = fitmodel.offset_azim();
		thetamin[index] = 0;
		thetamax[index] = azimmax;
	}

	// Pola
	if (fitmodel.has_pola()) {
		index = fitmodel.offset_pola();
		thetamin[index] = 0;
		thetamax[index] = polamax;
	}

	// Diffusion (G2)
	if (fitmodel.has_diffusion()) {
		index = fitmodel.offset_diffusion();
		thetamin[index] = 0;
		thetamax[index] = 1;
	}

	// Aberrations
	if (fitmodel.has_aberrations()) {
		index = fitmodel.offset_aberrations();

		if (fitmodel.has_fitted_aberrations()) {
			for (int ii = 0; ii < NAberr; ii++) {
				double zernikecoefsmax = 0.25 * AllParams.Lambda;
				thetamin[index + ii] = -zernikecoefsmax;
				thetamax[index + ii] = zernikecoefsmax;
			}
		} else if (fitmodel.has_const_aberrations()) {
			// No modifications
			for (int ii = 0; ii < NAberr; ii++)	{
				int theta_index = index + ii;
				thetamin[theta_index] = theta[theta_index];
				thetamax[theta_index] = theta[theta_index];
			}
		}
	}

	switch (fitmodel) {
		// These two exceptions were in the original code! Are they correct
		case FitModelEnum::xy_azim:
			// Azim?
			thetamax[4] = theta[2];
			break;
	}

	for (int i = 0; i < fitmodel.theta_size(); i++)
	{
		thetaretry[i] = (thetamax[i] + thetamin[i]) / 2.0;
	}
}

bool ThetaUpdate(
		const FitParams& AllParams,
		View1D<double> theta,
		View1D<double> thetamax,
		View1D<double> thetamin,
		View1D<double> thetaretry,
		View1D<double> grad,
		View2D<double> Hessian,
		const double& alamda,
		WriteView1D<double> thetatry
) {
	// This function calculates the new parameters in each iteration step.
	FitModelEnum fitmodel = AllParams.FitModel;
	int NumParams = fitmodel.num_parameters();

	// check for det(H) = 0 in order to avoid inversion of H
	int n = Hessian.size(0);
	Eigen::MatrixXd A(NumParams, NumParams);
	//Eigen::MatrixXd Ainverse(NumParams, NumParams);
	Eigen::VectorXd dtheta(NumParams);
	VF_ASSERT(NumParams != 0);

	for (int mm = 0; mm < n; mm++)
	{
		for (int nn = 0; nn < n; nn++)
		{
			A(mm, nn) = Hessian(mm, nn);
		}
	}

	// + A.diag() * alambda
	for (int mm = 0; mm < n; mm++)
	{
		A(mm, mm) += A(mm, mm) * alamda;
	}

	//Levenberg Marquart with enforced boundary
	// update_aberrations of fit parameters via Levenberg - Marquardt
	//solution of system of linear equations of form (Bmat)(dtheta)=grad
	// Solve Ax=b with:
	// - A: A
	// - x: -dtheta
	// - b: grad
	const auto cod = A.completeOrthogonalDecomposition();
	Eigen::VectorXd b((size_t)grad.numel());
	std::copy(grad.data(), grad.data() + grad.numel(), b.data());
	dtheta = -cod.solve(b);

	// if (!qr.isInvertible()) ?
	//Eigen::MatrixXd Apseudoinverse = A.completeOrthogonalDecomposition().pseudoInverse();

	for (int mm = 0; mm < NumParams; mm++)
	{
		thetatry[mm] = theta[mm] + dtheta[mm];
	}

	//cout << "go ahead!" << endl;

	// enforce physical boundaries in angular space
	if (fitmodel.has_azim_pola())
	{
		if (fitmodel.has_z())
		{
			int offset_azim = fitmodel.offset_azim();
			int offset_pola = fitmodel.offset_pola();

			if (thetatry[offset_azim] > thetamax[offset_azim])
			{
				thetatry[offset_azim] -= 2*M_PI; //-=M_PI
				thetatry[offset_pola] = M_PI - thetatry[offset_pola]; //?
			}
			else if (thetatry[offset_azim] < thetamin[offset_azim])
			{
				thetatry[offset_azim] += 2*M_PI;
				thetatry[6] = M_PI - thetatry[6];//?
			}

			thetatry[offset_pola] = thetatry[offset_pola] - ((int)(thetatry[offset_pola] / (M_PI))) * (M_PI);

			if (fitmodel.has_diffusion())
			{
				int offset_diff = fitmodel.offset_diffusion();

				if (thetatry[offset_diff] > thetamax[offset_diff])
				{
					thetatry[offset_diff] = thetamax[offset_diff] - thetatry[offset_diff];
				}
				else if (thetatry[offset_diff] < thetamin[offset_diff])
				{
					thetatry[offset_diff] = thetamin[offset_diff] - thetatry[offset_diff];
				}
			}
		}
		else
		{
			int offset_azim = fitmodel.offset_azim();
			int offset_pola = fitmodel.offset_pola();

			if (thetatry[offset_azim] > thetamax[offset_azim])
			{
				thetatry[offset_azim] -= M_PI;
				thetatry[offset_pola] = M_PI - thetatry[offset_pola];
			}
			else if (thetatry[offset_azim] < thetamin[offset_azim])
			{
				thetatry[offset_azim] += M_PI;
				thetatry[offset_pola] = M_PI - thetatry[offset_pola];
			}
			thetatry[offset_pola] = thetatry[offset_pola] - (int)(thetatry[offset_pola] / M_PI) * M_PI;
			if (thetatry[offset_pola] < 0)
			{
				thetatry[offset_pola] = thetatry[offset_pola] + M_PI; //bound [M_PI]
			}
		}
	}

	if (fitmodel.has_azim())
	{
		int offset_azim = fitmodel.offset_azim();

		//thetatry[4] = fmod(thetatry[4], 2 * M_PI);  //double modulus
		//thetatry[5] = fmod(thetatry[5], M_PI);
		thetatry[offset_azim] = thetatry[offset_azim] - (int)(thetatry[offset_azim] / (2 * M_PI)) * (2 * M_PI);

		if (thetatry[offset_azim] < 0)
		{
			thetatry[offset_azim] = thetatry[offset_azim] + 2 * M_PI; //bound [2M_PI]
		}
	}

	// enforce physical boundaries in parameter space.
	for (int jj = 0; jj < theta.size(0); jj++)
	{
		if ((thetatry[jj] > thetamax[jj]) || (thetatry[jj] < thetamin[jj]))
		{
			thetatry[jj] = thetaretry[jj];
		}
	}

	return true;
}

void AddMeritOffset(
		const FitParams& AllParams,
		WriteView1D<double> Merit,
		View3D<const double> OneSpot
) {
	double varfit = AllParams.Varfit;
	int Mx = AllParams.Mx;
	int My = AllParams.My;
	int K = AllParams.Mz;

	VF_ASSERT(OneSpot.shape() == shape(Mx, My, K));

	double sum = 0.0;

	for (int xx = 0; xx < Mx; xx++)
	{
		for (int yy = 0; yy < My; yy++)
		{
			for (int kk = 0; kk < K; kk++)
			{
				sum += -gammaln(OneSpot(xx, yy, kk) + 1.0 + varfit);
			}
		}
	}

	//Add offset to Merit functions
	Merit += sum;
}

}