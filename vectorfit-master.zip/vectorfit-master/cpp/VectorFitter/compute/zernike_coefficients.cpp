#include "zernike_coefficients.h"
#include "legendre_polynomials.h"
#include <vector>
#include <algorithm>
#include <iterator>
#include <numeric>
#include <cmath>


namespace compute {

namespace zernike_coefficients {

// NAT (Nodal Aberration Theory) gammas
// Format: [px py n m w]. Here (n,m) are the radial and azimuthal
// Zernike indices and (px,py) are the Legendre indices. The weight w is
// introduced to properly take into account the NAT symmetries between the
// different NAT coefficients.

struct NATvec
{
    int px;
    int py;
    int n;
    int m;
    double w;
};

static const std::vector<std::vector<NATvec>> nat_gammas{
    {{0, 0, 2,  0,  1.0}},
    {{1, 0, 2,  0,  1.0}},
    {{0, 1, 2,  0,  1.0}},
    {{2, 0, 2,  0,  1.0}, {0, 2, 2,  0, 1.0}},
    {{0, 0, 2,  2,  1.0}},
    {{0, 0, 2, -2,  1.0}},
    {{1, 0, 2,  2,  1.0}, {0, 1, 2, -2, 1.0}},
    {{0, 1, 2,  2, -1.0}, {1, 0, 2, -2, 1.0}},
    {{2, 0, 2,  2, 1.0/sqrt(5.0)}, {0, 2, 2,  2, -1.0/sqrt(5.0)}, {1, 1, 2, -2, 1.0}},
    {{0, 0, 3,  1,  1.0}},
    {{0, 0, 3, -1,  1.0}},
    {{1, 0, 3,  1,  1.0}, {0, 1, 3, -1, 1.0}},
    {{0, 0, 4,  0,  1.0}}
};

size_t num_nat_gammas() {
    return nat_gammas.size();
}

static const Arr2D<int> nat_gammas_orders2D()
{
    size_t numNATparvecs = std::accumulate(
        nat_gammas.begin(), nat_gammas.end(),
        (size_t)0,
        [](size_t sum, const std::vector<NATvec>& RR){ return sum + RR.size();}
    );
    Arr2D<int> result(2, (int)numNATparvecs);
    int i_result=0;
    for (const auto& RR : nat_gammas)
    {
        size_t multiples = RR.size();
        for (const NATvec& nat_vec: RR)
        {
            result.access({0, i_result}) = nat_vec.px;
            result.access({1, i_result}) = nat_vec.py;
            ++i_result;
        }
    }
    return result;
};

void compute_xy_gamma_legendre(
    const Arr1D<double>& xn,
    const Arr1D<double>& yn,
    const Arr1D<double>& gammas,
    const Arr1D<Aberration>& aberrations,
    WriteView2D<double> coeffs
)
{
    // TODO: xn and yn should be known within the C++ code, no need to pass them

    /* Matlab code

    NATgammas = params.NATgammas;
    orders2D = params.orders2D;
    nr_of_zernike_modes = size(params.aberrations,1);
    numgammas = length(NATgammas);

    if size(xn,1) == 1
        xn = xn';
        yn = yn';
    end

    size_grid = size(xn);
    zernikeCoefficients = zeros(size_grid(1),size_grid(2),nr_of_zernike_modes);

    alllegendres2D = get_legendrepolynomials2D(orders2D,xn,yn);
    legendre_normfac = sqrt((1+2*orders2D(:,1)).*(1+2*orders2D(:,2)));

    % loop over NATgammas, add up per zernike
    jv = 1;
    for jgam = 1:numgammas
        RR = NATgammas{jgam};
        multiples = length(RR)-1;
        for jm = 1:multiples
            NATvec = RR{jm};
            nn = NATvec(3);
            mm = NATvec(4);
            weight = NATvec(5);
            jzer = intersect(find(params.aberrations(:,1)==nn),find(params.aberrations(:,2)==mm)); % find the right Zernike in the list
            zernikeCoefficients(:,:,jzer) = zernikeCoefficients(:,:,jzer) + gammas(jgam)*weight*legendre_normfac(jv)*alllegendres2D(:,:,jv);
            jv = jv+1;
        end

    end

    if size_grid(2) == 1
        zernikeCoefficients = permute(zernikeCoefficients,[1 3 2]);
    end

    */
    VF_ASSERT(coeffs.shape() == shape(xn.size(0), aberrations.size(0)));
    coeffs.fill(0.0);

    // Compute static numbers
    static const Arr2D<int> orders2D = nat_gammas_orders2D();
    static const View1D<int>& orders2D_x = orders2D.view(0, placeholder::_);
    static const View1D<int>& orders2D_y = orders2D.view(1, placeholder::_);

    auto alllegendres2D = legendre_polynomials::get2D(orders2D, xn, yn);

    std::vector<double> legendre_normfac;
    for (int i_orderset=0; i_orderset < orders2D.size(1); ++i_orderset)
    {
        legendre_normfac.push_back(std::sqrt((1.0 + 2*orders2D_x[i_orderset]) * (1.0 + 2*orders2D_y[i_orderset])));
    }

    size_t jv=0;
    for (size_t j_gamma=0; j_gamma<nat_gammas.size(); ++j_gamma)
    {
        const std::vector<NATvec>& RR = nat_gammas[j_gamma];
        size_t multiples = RR.size();
        for (const NATvec& nat_vec: RR)
        {
            auto it_aberr = std::find_if(aberrations.begin(), aberrations.end(),
                [nat_vec](const Aberration& aberr)
                {
                    return nat_vec.n == aberr.radial_order && nat_vec.m == aberr.azimuthal_order;
                }
            );
            if (it_aberr == aberrations.end())
            {
                throw std::invalid_argument(
                    "Could not find aberration for Zernike (n,m)=("
                    + std::to_string(nat_vec.n) + ","
                    + std::to_string(nat_vec.m)
                    + ")"
                );
            }
            int i_aberr = (int)std::distance(aberrations.begin(), it_aberr);
            for (int i_p = 0; i_p < coeffs.size(0); ++i_p)
            {
                coeffs.access({i_p, i_aberr}) += gammas((int)j_gamma)*nat_vec.w*legendre_normfac[jv]*alllegendres2D[jv][i_p];
            }
            jv++;
        }
    }
}

} // namespace zernike_coefficients

} // namespace compute
