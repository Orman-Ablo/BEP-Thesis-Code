/* vectorfit_get_zernike_coefficients
 * z_coeffs = vectorfit_get_zernike_coefficients(xn, yn, gammas, params);
 * Calculates the Zernike coefficients, given gamma coefficients and x,y locations.
 * - xn,yn: coordinates or meshgrid of points for which we want to determine
 *   the Zernike coefficients. Units: physical coordinates of the total FOV
 *   (um) where the origin is at the outer edge of pixel 1,1.
 * - gammas: the gamma coefficients that determine how the Zernike
 *   Coefficients depend on x,y.
 *
 * returns an array or surface containing the zernike coeffcients in nm for each point (xn,yn)
*/

#include "vectorfit_mex.hpp"
#include "compute/zernike_coefficients.h"
#include "array/operators.h"


class MexFunction : public VectorfitMexFunction {
public:
    using Struct = matlab::data::Struct;
    using StructArray = matlab::data::StructArray;

    void execute(ArgumentList outputs, ArgumentList inputs) override {
        TypedArray<double> input_x = std::move(inputs[0]);
        TypedArray<double> input_y = std::move(inputs[1]);
        TypedArray<double> input_gammas = std::move(inputs[2]);
        StructArray input_params_array = std::move(inputs[3]);
        const Struct& input_params = input_params_array[0];
        TypedArray<double> input_aberrations = input_params["aberrations"];

        // Define input
        Arr1D<double> x((int)input_x.getNumberOfElements());
        Arr1D<double> y((int)input_y.getNumberOfElements());
        Arr1D<double> gammas((int)input_gammas.getNumberOfElements());
        Arr1D<compute::zernike_coefficients::Aberration> aberrations((int)input_aberrations.getDimensions()[0]);

        // Populate input
        std::copy(input_x.begin(), input_x.end(), x.data());
        std::copy(input_y.begin(), input_y.end(), y.data());
        std::copy(input_gammas.cbegin(), input_gammas.cend(), gammas.data());
        for (int i_aberr=0; i_aberr<aberrations.size(0); ++i_aberr)
        {
            aberrations[i_aberr].radial_order = input_aberrations[i_aberr][0];
            aberrations[i_aberr].azimuthal_order = input_aberrations[i_aberr][1];
            aberrations[i_aberr].coefficient = input_aberrations[i_aberr][2];
        }

        // Compute result
        Arr2D<double> result(x.size(0), aberrations.size(0));
        compute::zernike_coefficients::compute_xy_gamma_legendre(x, y, gammas, aberrations, result);

        // Populate output
        TypedArray<double> output_result = _array_factory.createArray(
            {(uint32_t)x.size(0), (uint32_t)aberrations.size(0)},
            result.begin(), result.end(),
            matlab::data::InputLayout::ROW_MAJOR
        );
        outputs[0] = std::move(output_result);
    }

    void checkArguments(ArgumentList outputs, ArgumentList inputs) {
        // inputs[0]: xn: double array
        // inputs[1]: yn: double array
        // inputs[2]: gammas: double array
        // inputs[3]: params: struct
        static const std::vector<std::string> param_names{"xn", "yn", "gammas", "params"};

        // Check xn, yn, gammas
        for (size_t i_param=0; i_param<3; ++i_param)
        {
            if (inputs[i_param].getType() != ArrayType::DOUBLE ||
                inputs[i_param].getType() == ArrayType::COMPLEX_DOUBLE)
            {
                feval_error(
                    "Input " + std::to_string(i_param+1)
                    + " '" + param_names[i_param]
                    + "' must be a double array"
                );
            }
        }

        // Check length of xn and yn
        const size_t xn_size = inputs[0].getNumberOfElements();
        const size_t yn_size = inputs[1].getNumberOfElements();
        if (xn_size != yn_size)
        {
            throw std::invalid_argument(
                "Length of x (" + std::to_string(xn_size) + ") and y (" + std::to_string(yn_size) + ") must be equal"
            );
        }

        // Check params struct
        if (inputs[3].getType() != ArrayType::STRUCT)
        {
            feval_error("Input 4 'params' must be a struct");
        }

        // Check number of outputs
        if (outputs.size() > 1) {
            feval_error("Only one output is returned");
        }
    }
};
