#include <omp.h>
#include <atomic>

#include "estimator/parallel_estimator.h"

ParallelEstimator::ParallelEstimator(const Estimator& fun): num_threads(fun.AllParams.NumThreads) {
	for (int i = 0; i < num_threads; i++) {
		thread_estimators.emplace_back(fun);
	}
}

void ParallelEstimator::LocalizeSpots(
		View4D<double> Spots,
		View2D<double> ThetaInit,
		WriteView3D<double> ThetaStore,
		WriteView4D<double> mu,
		WriteView5D<double> dmudtheta,
		WriteView2D<double> Merit,
		WriteView1D<int> NumIters,
		WriteView1D<bool> IsConverged
) {
	using namespace placeholder;
	
	int Ncfg = Spots.size(0);

	std::atomic<int> num_processed = 0;
	int print_progress_every = std::max(10, (Ncfg + 9) / 10);

#pragma omp parallel for default(shared) num_threads(num_threads)
	for (int cfg = 0; cfg < Ncfg; cfg++) {
		int p = ++num_processed;
		if (p % print_progress_every == 0) {
			std::cout << "spots processed: " << p << std::endl;
		}

		int thread_id = omp_get_thread_num();
		thread_estimators[thread_id].Localize(
			Spots.view(cfg, _, _, _),
			ThetaInit.view(cfg, _),
			GetSpotOTF(cfg),
			ThetaStore.view(cfg, _, _),
			mu.view(cfg, _, _, _),
			dmudtheta.view(cfg, _, _, _, _),
			Merit.view(cfg, _),
			NumIters(cfg),
			IsConverged(cfg)
		);
	}
}

void ParallelEstimator::InitializeSpots(
		View4D<double> Spots,
		WriteView2D<double> ThetaInit
) {
	using namespace placeholder;

	int Ncfg = Spots.size(0);

#pragma omp parallel for default(shared) num_threads(num_threads)
	for (int cfg = 0; cfg < Ncfg; cfg++) {
		int thread_id = omp_get_thread_num();
		thread_estimators[thread_id].InitialValues(
			Spots.view(cfg, _, _, _),
			ThetaInit.view(cfg, _));
	}
}

void ParallelEstimator::SetOTFs(View4D<std::complex<double>> OTFs, View1D<int> SpotOTFIndices) {
	// Simply copy memory
	otfs = OTFs;
	spot_otf_indices = SpotOTFIndices;
}

View3D<std::complex<double>> ParallelEstimator::GetSpotOTF(int spot_index) {
	if (thread_estimators[0].AllParams.FlagOTF) {
		if (otfs.data()) {
			int otf_index = spot_otf_indices(spot_index);
			return otfs.view(otf_index, placeholder::_, placeholder::_, placeholder::_);
		} else {
			throw std::runtime_error("ParallelEstimator: OTF data not set");
		}
	} else {
		return {};
	}
}

void ParallelEstimator::ComputeOTFs(
	View2D<double> otf_zernike_coefficients,
	WriteView4D<std::complex<double>> OTFs
) {
	using namespace placeholder;
	VF_ASSERT(OTFs.size(0) == otf_zernike_coefficients.size(0));
	int num_otfs = OTFs.size(0);

#pragma omp parallel for default(shared) num_threads(num_threads)
	for (int i_otf = 0; i_otf < num_otfs; i_otf++) {
		int thread_id = omp_get_thread_num();
		thread_estimators[thread_id].ComputeOTF(
			otf_zernike_coefficients.view(i_otf, _),
			OTFs.view(i_otf, _, _, _)
		);
	}
}
