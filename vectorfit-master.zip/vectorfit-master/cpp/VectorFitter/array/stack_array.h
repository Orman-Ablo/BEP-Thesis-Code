#pragma once
#include "container.h"

#ifndef __CUDA_ARCH__
static constexpr MemorySpace current_memory_space = MemorySpace::Host;
#else
static constexpr MemorySpace current_memory_space = MemorySpace::Device;
#endif

namespace detail {
	template <dim_t... Sizes>
	struct SizesHelper;

	template <dim_t Size, dim_t... Rest>
	struct SizesHelper<Size, Rest...> {
		static_assert(Size >= 0, "Size cannot be negative");
		static constexpr dim_t product = Size * SizesHelper<Rest...>::product;
	};

	template <>
	struct SizesHelper<> {
		static constexpr dim_t product = 1;
	};
}

template <typename T, dim_t... Sizes>
class StackArrayND: public StridedContainerOps<StackArrayND<T, Sizes...>, T, sizeof...(Sizes), current_memory_space> {
	static constexpr size_t N = sizeof...(Sizes);

public:
	CUDA_HOST_DEVICE
	explicit StackArrayND(T initial = {}) {}

	template <typename D2, typename T2>
	StackArrayND(const Expression<D2, T2, N, MemorySpace::Host> &rhs) {
		this->copy_from(rhs.derived());
	}

	explicit StackArrayND(const StackArrayND&) = default;
	StackArrayND(StackArrayND&&) noexcept = default;
	StackArrayND& operator=(StackArrayND&& rhs) noexcept = default;
	StackArrayND& operator=(const StackArrayND &rhs) = default;

	template <typename D2, typename T2>
	CUDA_HOST_DEVICE
	StackArrayND& operator=(const Expression<D2, T2, N, MemorySpace::Host> &rhs) {
		this->copy_from(rhs.derived());
		return *this;
	}

	CUDA_HOST_DEVICE
	stride_t stride(size_t axis) const {
		VF_ASSERT(N > 0 && axis < N);
		stride_t result = 1;

		for (size_t i = axis + 1; i < N; i++) {
			result *= size(i);
		}

		return result;
	}

	CUDA_HOST_DEVICE
	dim_t size(size_t axis) const {
		static constexpr dim_t static_sizes[N] = {Sizes...};

		VF_ASSERT(N > 0 && axis < N);
		return static_sizes[axis];
	}

	CUDA_HOST_DEVICE
	T* data() {
		return &data_[0];
	}

	CUDA_HOST_DEVICE
	const T* data() const {
		return &data_[0];
	}

private:
	fixed_vector<T, detail::SizesHelper<Sizes...>::product> data_;
};


// Some nice aliases
template <typename T, dim_t... Sizes> using SmallArr = StackArrayND<T, Sizes...>;
