#pragma once

#include "MultiDimArray.h"
#include "Parameters.h"
#include "compute/czt.h"
#include "compute/fft.h"
#include "compute/pupil_matrix.h"

class Estimator
{
public:
	const FitParams AllParams;
	PupilMatrix pupil_matrix;
	using otf_type = Arr3D<std::complex<double>>;
	//std::shared_ptr<otf_type> OTF;  // If empty, OTF is not used
	CztPlan czt_psf; // For computing the PSF directly
	CztPlan czt_otf_to_psf; // For computing the PSF from the OTF
	CztPlan czt_psf_for_otf; // For computing the source PSF for the OTF computation (different size)
	CztPlan3D czt_psf_to_otf; // For computing the OTF from the PSF
	FFT2DPlan pixel_bluring_fft;

	// Constructor from FitParams
	Estimator(FitParams params);
	~Estimator();

	// Set new OTF view.
	// Be sure to keep the actual OTF memory while using the estimator!
	//void SetOTF(const std::shared_ptr<otf_type>& NewOTF);

	void InitialValues(
			View3D<double> OneSpot,
			WriteView1D<double> ThetaInit); //set initial theta values

	// Localize single spot.
	// To disable OTF, simply pass an empty view.
	void Localize(
			View3D<double> OneSpot,
			View1D<double> ThetaInit,
			View3D<std::complex<double>> OTF,
			WriteView2D<double> ThetaStore,
			WriteView3D<double> mu,
			WriteView4D<double> dmudtheta,
			WriteView1D<double> Merit,
			int& NumIters,
			bool& IsConverged);

	// Compute poisson rate.
	// Note: otf is only used if it is non-empty.
	void PoissonRate(
			const SpotParameters& spot,
			WriteView3D<double> mu,
			WriteView4D<double> dmudtheta,
			View3D<std::complex<double>> OTF = {});

	// Compute an OTF from an array of zernike coefficients.
	void ComputeOTF(
		View1D<double> otf_zernike_coefficients,
		WriteView3D<std::complex<double>> OTF
	);

protected:
	// Verify computed OTF. Mostly for debugging.
	void VerifyOTF(SpotParameters spot, View3D<std::complex<double>> OTF);
	void PoissonRate(
			const SpotParameters& spot,
			WriteView3D<double> mu,
			WriteView4D<double> dmudtheta,
			int Mx,
			int My,
			int Mz,
			CztPlan& czt,
			View3D<std::complex<double>> OTF = {});
};
