import kernel_tuner
import cupy
import numpy as np
from collections import OrderedDict

def device_name():
    import pycuda
    pycuda.driver.init()
    return pycuda.driver.Device(0).name().replace(" ", "_")


def tune_problem(problem_size, TF):
    kernel_source = """
    #include "compute_gpu/czt_kernels.cuh"

    template <int N, int M, int block_size_x, int block_size_y, int blocks_per_sm, typename TF>
    __global__
    __launch_bounds__(block_size_x * block_size_y, blocks_per_sm)
    void czt_kernel(
        const complex_type<TF>* input_ptr,
        int input_stride_0,
        int input_stride_1,
        int input_stride_2,
        complex_type<TF>* output_ptr,
        int output_stride_0,
        int output_stride_1,
        int output_stride_2,
        const complex_type<TF>* Ax,
        const complex_type<TF>* Bx,
        const complex_type<TF>* Dx
    ) {
        cuda_czt::State<N, M, TF> state {Ax, Bx, Dx};

        auto input = [&](int i, int j) {
            int b = blockIdx.x;
            return input_ptr[b * input_stride_0 + i * input_stride_1 + j * input_stride_2];
        };

        auto output = [&](int i, int j, complex_type<TF> result) {
            int b = blockIdx.x;
            output_ptr[b * output_stride_0 + i * output_stride_1 + j * output_stride_2] = result;
        };

        cuda_czt::execute<block_size_x, block_size_y>(input, output, state);
    }

    """


    N = 56
    M = 9
    L = N + M - 1

    float_name = "float" if TF == np.float32 else "double"
    kernel_name = f"czt_kernel<{N}, {M}, block_size_x, block_size_y, blocks_per_sm, {float_name}>"

    Ax = np.random.random((N, 2)).astype(TF)
    Bx = np.random.random((M, 2)).astype(TF)
    Dx = np.random.random((L, 2)).astype(TF)

    input_data = np.random.random((problem_size, N, N, 2)).astype(TF)
    output_data = np.random.random((problem_size, M, M, 2)).astype(TF)

    args = [
            input_data,
            np.int32(N * N),
            np.int32(N),
            np.int32(1),
            output_data,
            np.int32(M * M),
            np.int32(M),
            np.int32(1),
            Ax,
            Bx,
            Dx,
    ]


    tune_params = OrderedDict()
    tune_params["block_size_x"] = [i for i in range(1, 32 + 1) if L % i == 0]
    tune_params["block_size_y"] = [i for i in range(1, 32 + 1)]
    tune_params["blocks_per_sm"] = [1, 2, 3, 4, 5, 6, 7, 8]

    restrictions = [
            "32 <= block_size_x * block_size_y <= 1024",
    ]

    options = ["-I../VectorFitter"]

    cache_file = f"{device_name()}-{problem_size}-{float_name}"

    kernel_tuner.tune_kernel(
        kernel_name,
        kernel_source,
        problem_size,
        args,
        tune_params,
        grid_div_x=[],
        grid_div_y=[],
        restrictions=restrictions,
        compiler_options=options,
        lang="cupy",
        cache=cache_file,
        defines=dict()
    )

for n in [10, 100, 1000, 10000, 100000, 1000000]:
    tune_problem(n, np.float32)
    tune_problem(n, np.float64)
