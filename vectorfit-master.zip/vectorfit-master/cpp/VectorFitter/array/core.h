#pragma once

#include "types.h"
#include "cuda/macros.cuh"

template <typename Derived, typename T, size_t N, MemorySpace S>
class Expression {
public:
	using value_type = T;
	using shape_type = shape_t<N>;
	static constexpr size_t rank = N;
	static constexpr MemorySpace space = S;

	CUDA_HOST_DEVICE
	Derived& derived() {
		return *static_cast<Derived*>(this);
	}

	CUDA_HOST_DEVICE
	const Derived& derived() const {
		return *static_cast<const Derived*>(this);
	}

	CUDA_HOST_DEVICE
	dim_t numel() const {
		unsigned result = 1;
		for (size_t i = 0; cmp_less(i, N); i++) {
			result *= derived().size(i);
		}
		return result;
	}

	CUDA_HOST_DEVICE
	bool is_empty() const {
		for (size_t i = 0; cmp_less(i, N); i++) {
			if (derived().size(i) <= 0) {
				return true;
			}
		}
		return false;
	}

	CUDA_HOST_DEVICE
	bool in_bounds(ndindex_t<N> ndindex) const {
		for (size_t i = 0; cmp_less(i, N); i++) {
			if (ndindex[i] >= derived().size(i)) {
				return false;
			}
		}

		return true;
	}

	CUDA_HOST_DEVICE
	shape_type shape() const {
		shape_type result;
		for (size_t i = 0; cmp_less(i, N); i++) {
			result[i] = derived().size(i);
		}
		return result;
	}

	CUDA_HOST_DEVICE
	bool is_square() const {
		for (size_t i = 0; cmp_less(i, N); i++) {
			if (derived().size(0) != derived().size(i)) {
				return false;
			}
		}

		return true;
	}
};

template <size_t N, typename F>
void iterate_nd(shape_t<N> shape, F fun) {
	ndindex_t<N> ndindex {};
	bool is_empty = false;

	for (size_t i = 0; cmp_less(i, N); i++) {
		ndindex[i] = 0;
		is_empty |= shape[i] <= 0;
	}

	if (is_empty) {
		return;
	}

	while (true) {
		fun(ndindex);

		ndindex[N-1]++;
		for (size_t i = 0; i < N; i++) {
			size_t axis = N - i - 1;

			if (ndindex[axis] >= shape[axis]) {
				if (i + 1 < N) {
					ndindex[axis] = 0;
					ndindex[axis - 1]++;
				} else {
					return;
				}
			} else {
				break;
			}
		}
	}
}

template <typename Derived, typename T, size_t N, MemorySpace space>
class ExpressionOps: public Expression<Derived, T, N, space> {};

#if !CUDA_RTC
template <typename Derived, typename T, size_t N>
class ExpressionOps<Derived, T, N, MemorySpace::Host>: public Expression<Derived, T, N, MemorySpace::Host> {
	using base_type = Expression<Derived, T, N, MemorySpace::Host>;

public:
	using base_type::derived;

	template <typename F>
	void for_each(F fun) {
		iterate_nd(this->shape(), [&](auto index) {
			fun(derived().access(index));
		});
	}

	template <typename F>
	void for_each(F fun) const {
		iterate_nd(this->shape(), [&](auto index) {
			fun(derived().access(index));
		});
	}

	template <typename F, typename R = T>
	R fold(R accum, F fun) const {
		for_each([&](const T& entry) {
			accum = fun(std::move(accum), entry);
		});

		return accum;
	}

	T maximum(T accum = -std::numeric_limits<T>::max()) const {
		for_each([&](const T& entry) {
			accum = std::max(accum, entry);
		});

		return accum;
	}

	T minimum(T accum = std::numeric_limits<T>::max()) const {
		for_each([&](const T& entry) {
			accum = std::min(accum, entry);
		});

		return accum;
	}

	T sum(T accum = {}) const {
		for_each([&](const T& entry) {
			accum += entry;
		});

		return accum;
	}

	void clamp(T lbnd, T ubnd) {
		this->for_each([&](T& entry) {
			if (entry < lbnd) entry = lbnd;
			if (entry > ubnd) entry = ubnd;
		});
	}

	void fill(T value) {
		this->for_each([&](T& entry) {
			entry = value;
		});
	}
};
#endif

