/* vectorfit_get_outliers()
 * Computes the outliers from the last local update.
 *
 * returns an array of spot indices of the outliers.
*/

#include "vectorfit_mex.hpp"
#include "vectorfit_fitter.hpp"
#include "array/operators.h"


class MexFunction : public VectorfitMexFunction {
public:
    using ArgumentList = matlab::mex::ArgumentList;
    using Struct = matlab::data::Struct;
    using StructArray = matlab::data::StructArray;

    void execute(ArgumentList outputs, ArgumentList inputs) {
        // Obtain fitter object handle
        const uint64_t handle = inputs[0][0];
        VectorfitFitter* fitter = VectorfitMemoryManager::get(handle);
        // Obtain the outliers. Make sure they are 1-based for matlab.
        std::vector<int> outliers = fitter->fitter().get_outliers();
        for (int& index : outliers) {
            index++;
        }
        // Output outliers.
        outputs[0] = _array_factory.createArray<int>(
            {(uint64_t)outliers.size()},
            outliers.data(),
            outliers.data() + outliers.size()
        );
    }

    void checkArguments(ArgumentList outputs, ArgumentList inputs) {
        // Check array arguments
        if (inputs.size() != 1) {
            feval_error("Number of required inputs is 1: (vectorfit_handle)");
        }
        // Check array argument: first input must be a uint64_t scalar
        if (inputs[0].getType() != ArrayType::UINT64 ||
            inputs[0].getNumberOfElements() != 1)
        {
            feval_error("Input 1 must be a vectorfit handle in the form of a uint64 scalar");
        }
        if (outputs.size() != 1)
        {
            feval_error("One output is returned: array of outlier spot indices");
        }
    }
};
