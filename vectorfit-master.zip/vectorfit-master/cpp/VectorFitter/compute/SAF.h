#pragma once

#include "Parameters.h"
#include "MultiDimArray.h"
//#include "Parameters_aberr.h"

fixed_vector<double, 3> setSAF(const PupilParams& AllParams); //a good polyfit cpp code has to be used for this function. (needs to be optimized)

fixed_vector<double, 3> GetSafFocus(
		const PupilParams& AllParams,
		const Arr4D<std::complex<double>>& PolarizationVector,
		const Arr2D<std::complex<double>>& Amplitude,
		const Arr2D<std::complex<double>>& Waberration,
		const Arr2D<double>& XPupil,
		const Arr2D<double>& YPupil,
		Arr2D<std::complex<double>> cosThetaMed,
		Arr2D<std::complex<double>> cosThetaImm,
		Arr2D<std::complex<double>> cosThetaImmnom,
		Arr2D<std::complex<double>> ApertureMask);

fixed_vector<double, 3> getRIMismatchPars(
		const PupilParams& AllParams);
