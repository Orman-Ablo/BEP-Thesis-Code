/* vectorfit_update_otfs
 * otfs, spot_otf_indices = vectorfit_update_otfs(vectorfit_handle, nat_gammas, aberration_orders);
 * Recomputes and stores OTFs, given gamma coefficients and aberration orders.
 * - gammas: the gamma coefficients that determine how the Zernike
 *   Coefficients depend on x,y.
 *
 * returns an array of OTF matrices and an array with the OTF index per spot.
*/

#include "vectorfit_mex.hpp"
#include "vectorfit_fitter.hpp"
#include "compute/zernike_coefficients.h"
#include "array/operators.h"


class MexFunction : public VectorfitMexFunction {
public:
    using Struct = matlab::data::Struct;
    using StructArray = matlab::data::StructArray;

    void execute(ArgumentList outputs, ArgumentList inputs) override {
        // Obtain fitter object handle
        const uint64_t handle = inputs[0][0];
        VectorfitFitter* fitter = VectorfitMemoryManager::get(handle);
        const FitParams& params = fitter->fitter().params();
        // Obtain nat_gammas and aberrations arrays
        TypedArray<double> input_gammas = std::move(inputs[1]);
        TypedArray<double> input_aberrations = std::move(inputs[2]);

        // Define input
        Arr1D<double> gammas((int)input_gammas.getNumberOfElements());
        Arr1D<compute::zernike_coefficients::Aberration> aberrations((int)input_aberrations.getDimensions()[0]);

        // Populate input
        std::copy(input_gammas.cbegin(), input_gammas.cend(), gammas.data());
        for (int i_aberr=0; i_aberr<aberrations.size(0); ++i_aberr)
        {
            aberrations[i_aberr].radial_order = input_aberrations[i_aberr][0];
            aberrations[i_aberr].azimuthal_order = input_aberrations[i_aberr][1];
            aberrations[i_aberr].coefficient = input_aberrations[i_aberr][2];
        }

        // Update OTFs
        Arr4D<std::complex<double>> otfs(
            fitter->fitter().num_otfs(),
            params.Notfx,
            params.Notfy,
            params.Notfz);
        Arr1D<int> spot_otf_indices(fitter->fitter().num_spots());
        fitter->fitter().update_otfs(gammas, aberrations, otfs, spot_otf_indices);

        // Populate output (optional)
        if (outputs.size() == 2) {
            // Output OTFs
            TypedArray<std::complex<double>> output_otfs = _array_factory.createArray(
                {
                    (uint32_t)otfs.size(0),
                    (uint32_t)otfs.size(1),
                    (uint32_t)otfs.size(2),
                    (uint32_t)otfs.size(3)
                },
                otfs.begin(), otfs.end(),
                matlab::data::InputLayout::ROW_MAJOR
            );
            outputs[0] = std::move(output_otfs);

            // Output OTF index per spot
            TypedArray<int32_t> output_spot_otf_indices = _array_factory.createArray(
                {(uint32_t)fitter->fitter().num_spots()},
                spot_otf_indices.begin(), spot_otf_indices.end(),
                matlab::data::InputLayout::ROW_MAJOR
            );
            outputs[1] = std::move(output_spot_otf_indices);
        }
    }

    void checkArguments(ArgumentList outputs, ArgumentList inputs) {
        // inputs[0]: handle: uint64
        // inputs[1]: nat_gammas: double array
        // inputs[2]: aberration_orders: double array
        // Check number of input arguments
        if (inputs.size() != 3) {
            feval_error("Number of required inputs is 3: (vectorfit_handle, nat_gammas, aberration_orders)");
        }
        // Input 1 must be a uint64_t scalar
        if (inputs[0].getType() != ArrayType::UINT64 ||
            inputs[0].getNumberOfElements() != 1)
        {
            feval_error("Input 1 must be a vectorfit handle in the form of a uint64 scalar");
        }

        static const std::vector<std::string> param_names{"gammas", "aberration_orders"};

        // Check array type of gammas, aberration_orders
        for (size_t i_param=1; i_param<3; ++i_param)
        {
            if (inputs[i_param].getType() != ArrayType::DOUBLE ||
                inputs[i_param].getType() == ArrayType::COMPLEX_DOUBLE)
            {
                feval_error(
                    "Input " + std::to_string(i_param+1)
                    + " '" + param_names[i_param]
                    + "' must be a double array"
                );
            }
        }

        // Input 2 input must be theta_global ('gammas')
        size_t num_nat_gammas = compute::zernike_coefficients::num_nat_gammas();
        if (inputs[1].getType() != ArrayType::DOUBLE ||
            inputs[1].getType() == ArrayType::COMPLEX_DOUBLE ||
            inputs[1].getNumberOfElements() != num_nat_gammas
        ) {
            feval_error("Input 2 'nat_gammas' must be a double array of size " + std::to_string(num_nat_gammas));
        }

        // Check number of outputs: either 0 or 2
        if ((outputs.size() != 0) && (outputs.size() != 2)) {
            feval_error("Number of outputs must be either 0 or 2");
        }
    }
};
