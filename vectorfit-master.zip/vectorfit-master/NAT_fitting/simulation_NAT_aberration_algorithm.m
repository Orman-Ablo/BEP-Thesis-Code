close all;
clearvars;

% Folder that contains the code (for cluster)
code_path = "/home/idroste/Code/smlm-vector-localization";

addpath(genpath(code_path))

% Path where the input and output data will be saved. To fit existing data,
% put the path here and set generate_new_data to false.
path_input_data = 'read/nat/input_spots_';

path_output_data = 'read/nat/results_';

% Number of simulations.
nr_of_runs = 1;

params = set_parameters_xyz_NAT;

params.N_level = 5000;
params.Ncfg_total = 100;%5e5/params.N_level; % Total nr of input/simulated spots before selection.
params.b_level = params.N_level/250;%params.N_level/250;

params.select_spots_from_file = false;
params.generate_new_data = true;
params.add_newnoise = false; % create a different noise realisation for an existing ground truth.
params.simulated_data = true;
params.groundtruth_exists = true;
params.delete_parpool = false;
plot_data = true;
final_local_update = false;

system_aberration_error_all = zeros(nr_of_runs,1);
CRLB_all = zeros(nr_of_runs,1);

% Set up parallel pool
if isempty(gcp('nocreate'))
    number_of_parallel_workers = params.nr_of_parallel_workers;
    parpool('Threads', number_of_parallel_workers);
end

for r=1:nr_of_runs
    
    fprintf('\nStarting run %i\n',r);

    % Generate data
    if params.generate_new_data
        get_NAT_data
        path_input_data_full = strcat(path_input_data,num2str(r),'_.mat');
        save(path_input_data_full,'allspots','roixy','params','groundtruth','zernikeCoefficients','Wrms','merit_total_gt','fov_coordinates','framelist','ID');

        if plot_data
            show_simulated_data
            fprintf('\nPress a key to continue\n');
            pause
        end
        
    else    
        path_input_data_full = strcat(path_input_data,num2str(r),'_.mat');
        fprintf('Input data = %s\n',path_input_data_full);
    end

    % Fit aberrations
    tic;
    fprintf('\nStart localization\n');
    fit_NAT_data
    toc;
    path_output_data_full = strcat(path_output_data,num2str(r),'_.mat');

    err1 = get_system_aberration_value(theta_full.global - groundtruth.global,params)
    err2 = get_system_aberration_value(theta_full.global.*[-1,-1,-1,-1,-1,-1,-1,-1,-1,1,1,1,-1]' - groundtruth.global,params)
    system_aberration_error_all(r) = min(err1,err2)
    save(path_output_data_full,'theta_full','thetastore_full','localizations_full','localizations_with_outliers_full','meritstore_full','mu_full','dmudtheta_full','Niters_full','allspots','roixy','thetainit','params','groundtruth','max_merit_index','outliers_full','monitorstore_total','-v7.3');
    
    xn = linspace(-1,1,50);
    yn = linspace(-1,1,50);
    [Xn,Yn] = meshgrid(xn,yn);
    [CRLB_global_surface,Fisher_global,Fisher_global_inverse,CRLB_gammas,CRLB_Wsys,rcondstore_global] = get_fisher_crlb_global(mu_full,dmudtheta_full.global,Xn,Yn,outliers,theta_full.global,params);
    CRLB_all(r) = get_system_aberration_value(CRLB_gammas,params)

    if plot_data
        show_fitted_data
    end

end

fprintf('\nFinished simulation\n');


%% End parallel pool
if params.delete_parpool
    delete(gcp('nocreate'));
end