#pragma once
#include <memory>
#include <omp.h>
#include <functional>

#include "estimator/cpu_estimator.h"
#include "estimator/interface.h"

class ParallelEstimator: public BaseEstimator {
	const int num_threads;
	std::vector<Estimator> thread_estimators;
	Arr4D<std::complex<double>> otfs; // Array of 3D OTFs
	Arr1D<int> spot_otf_indices;

public:
	ParallelEstimator(const Estimator& fun);

	Estimator& thread_estimator(size_t index) { return thread_estimators[index]; }

	void InitializeSpots(
			View4D<double> Spots,
			WriteView2D<double> ThetaInit) override;

	void LocalizeSpots(
			View4D<double> Spots,
			View2D<double> ThetaInit,
			WriteView3D<double> ThetaStore,
			WriteView4D<double> mu,
			WriteView5D<double> dmudtheta,
			WriteView2D<double> Merit,
			WriteView1D<int> NumIters,
			WriteView1D<bool> IsConverged) override;

	void SetOTFs(View4D<std::complex<double>> OTFs, View1D<int> SpotOTFIndices) override;

	// Compute an array of OTFs from an array of zernike coefficients, in parallel on the CPU.
	void ComputeOTFs(
		View2D<double> otf_zernike_coefficients,
		WriteView4D<std::complex<double>> OTFs
	);

protected:
	View3D<std::complex<double>> GetSpotOTF(int spot_index);
};