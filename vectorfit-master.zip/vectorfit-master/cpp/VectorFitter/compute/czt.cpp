#include <unordered_map>
#include <vector>

#include "compute/czt.h"

void CztPlan::execute(View2D<std::complex<double>> input, WriteView2D<std::complex<double>> output) {
 	VF_ASSERT(input.size(0) == nrows_ && input.size(1) == nrows_);
	VF_ASSERT(output.size(0) == ncols_ && output.size(1) == ncols_);

	const int N = nrows_;
	const int M = ncols_;
	const int L = N + M - 1;

	//cols
	for (index_t j = 0; j < N; j++) {
		for (index_t i = 0; i < N; i++) {
			fft_.in(i) = Ax(i) * input(i, j);
		}
		for (index_t i = N; i < L; i++) {
			fft_.in(i) = 0;
		}

		fft_.execute_forward();

		for (index_t i = 0; i < L; i++) {
			fft_.in(i) = fft_.out(i) * Dx(i);
		}

		fft_.execute_backward();

		for (index_t i = 0; i < M; i++) {
			IntermediateImage(i, j) = Bx(i) * fft_.out(i) / (double) L;
		}
	}

	//rows
	for (index_t i = 0; i < M; i++) {
		for (index_t j = 0; j < N; j++) {
			fft_.in(j) = Ax(j) * IntermediateImage(i, j);
		}

		for (index_t j = N; j < L; j++) {
			fft_.in(j) = 0;
		}

		fft_.execute_forward();

		for (index_t j = 0; j < L; j++) {
			fft_.in(j) = fft_.out(j) * Dx(j);
		}

		fft_.execute_backward();

		for (index_t j = 0; j < M; j++) {
			output(i, j) = Bx(j) * fft_.out(j) / (double) L;
		}
	}
}

void CztPlan::PreChirpZ(
		int n, int m,
		double xsize, double qsize,
		Arr1D<std::complex<double>>& Ax,
		Arr1D<std::complex<double>>& Bx,
		Arr1D<std::complex<double>>& Dx
) {
	using namespace std::complex_literals;
	/*
	function[A, B, D] = prechirpz(xsize, qsize, N, M)
		% This function evaluates the auxiliary vectors for the evaluation of the
		% FT via the czt - algorithm
		% arguments: xsize = window in real space abs(x) < xsize
		% qsize = window in Fourier space abs(q) < qsize
		% N = # sample points in real space(even)
		% M = # sample points in Fourier space(odd)
		% function value : A, B, D = auxiliary vectors of lengths N, M, and L = N + M - 1
		%
		%copyright Sjoerd Stallinga, TU Delft, 2017
		*/
	const int L = n + m - 1;
	const int N = n;
	const int M = m;

	std::complex<double> Afac, Bfac, sqW, W, Gfac;
	std::vector<std::complex<double> >Utmp, Vtmp;

	Ax.resize(N);
	Bx.resize(M);
	Dx.resize(L);

	double sigma = 2.0 * M_PI * xsize * qsize / (N * M);

	Afac = exp(2.0 * 1i * sigma * (1.0 - M));
	Bfac = exp(2.0 * 1i * sigma * (1.0 - N));
	sqW = exp(2.0 * 1i * sigma);
	W = pow(sqW, 2);

	Gfac = (2.0 * xsize / N) * exp(1i * sigma * (1.0 - N) * (1.0 - M));

	Utmp.resize(N);
	Utmp[0] = sqW * Afac;
	Ax[0] = 1.0;

	for (int ii = 1; ii < N; ii++)
	{
		Ax[ii] = Utmp[ii - 1] * Ax[ii - 1];
		Utmp[ii] = Utmp[ii - 1] * W;
	}

	Utmp.resize(M, 0.0);
	//Bx.resize(M, 1.0);
	Utmp[0] = sqW * Bfac;
	Bx[0] = Gfac;

	for (int ii = 1; ii < M; ii++)
	{
		Bx[ii] = Utmp[ii - 1] * Bx[ii - 1];
		Utmp[ii] = Utmp[ii - 1] * W;
	}

	int P = std::max(N, M);
	Utmp.resize(P + 1, 0.0);
	Vtmp.resize(P + 1, 0.0);
	Utmp[0] = sqW;
	Vtmp[0] = 1.0;
	for (int ii = 1; ii < P + 1; ii++)
	{
		Vtmp[ii] = Utmp[ii - 1] * Vtmp[ii - 1];
		Utmp[ii] = Utmp[ii - 1] * W;
	}

	for (int ii = 0; ii < M; ii++)
	{
		Dx[ii] = conj(Vtmp[ii]);
	}

	for (int ii = 0; ii < N-1; ii++)
	{
		Dx[L - 1 - ii] = conj(Vtmp[ii + 1]);
	}

	FFT1DPlan fft(L);

	for (int i = 0; i < L; i++) {
		fft.in(i) = Dx[i];
	}

	fft.execute_forward();

	for (int i = 0; i < L; i++) {
		Dx[i] = fft.out(i);
	}
}

void CztPlan::resize(int n, int m, double xsize, double qsize) {
	nrows_ = n;
	ncols_ = m;

	if (n > 0 && m > 0) {
		int L = n + m - 1;
		fft_.resize(L);

		IntermediateImage.resize(m, n);
		PreChirpZ(n, m, xsize, qsize, Ax, Bx, Dx);
	}
}


void czt(View2D<std::complex<double>> input, WriteView2D<std::complex<double>> output)
{
	VF_ASSERT(false);
}

void CztPlan3D::resize(shape_t<3> input_shape, shape_t<3> output_shape, std::array<double, 3> input_sizes, std::array<double, 3> output_sizes) {
	// Fill dim_props_ for all dimensions
	for (size_t i_dim=0; i_dim<3; ++i_dim) {
		DimProps& p = dim_props_[i_dim];
		p.N = input_shape[i_dim];
		p.M = output_shape[i_dim];
		p.L = p.N + p.M - 1;
		p.xsize = input_sizes[i_dim];
		p.qsize = output_sizes[i_dim];
		if (p.L > 0) {
			p.Ax.resize(p.N);
			p.Bx.resize(p.M);
			p.Dx.resize(p.L);
			p.fft.resize(p.L);
			PreChirpZ(p.N, p.M, p.xsize, p.qsize, p.Ax, p.Bx, p.Dx);
		}
	}

	// Prepare intermediate output images with reordered axes to simplify the loops in execute()
	IntermediateImages[0].resize(input_shape[1], input_shape[2], output_shape[0]);  // Axes: {1, 2, 0}
	IntermediateImages[1].resize(input_shape[2], output_shape[0], output_shape[1]); // Axes: {2, 0, 1}
}

/*
void dbg_report_1darray_diff(View1D<std::complex<double>> a, View1D<std::complex<double>> b, const std::string& arr_name) {
	Arr1D<std::complex<double>> diff = a - b;
	Arr1D<double> diff_norm(diff.numel());
	for (int i=0; i<diff.numel(); ++i) {
		diff_norm[i] = norm(diff[i]);
	}
	std::cout << arr_name << " diff norm [min, max]: [" << diff_norm.minimum() << ", " << diff_norm.maximum() << "]" << std::endl;
}
*/

void CztPlan3D::execute(View3D<std::complex<double>> input, WriteView3D<std::complex<double>> output) {
	shape_t<3> input_shape{dim_props_[0].N, dim_props_[1].N, dim_props_[2].N};
	shape_t<3> output_shape{dim_props_[0].M, dim_props_[1].M, dim_props_[2].M};
	VF_ASSERT(input.shape() == input_shape);
	VF_ASSERT(output.shape() == output_shape);

	/*
	// DEBUG code: 2D verification
	CztPlan czt2d(dim_props_[0].N, dim_props_[0].M, dim_props_[0].xsize, dim_props_[0].qsize);
	Arr2D<std::complex<double>> output2d(dim_props_[0].M, dim_props_[0].M);
	czt2d.execute(input.drop_axis(2), output2d);
	// Ax, Bx, Dx comparison
	std::cout << "3D czt - 2D czt comparison:" << std::endl;
	dbg_report_1darray_diff(dim_props_[0].Ax, czt2d.ax(), "Ax");
	dbg_report_1darray_diff(dim_props_[0].Bx, czt2d.bx(), "Bx");
	dbg_report_1darray_diff(dim_props_[0].Dx, czt2d.dx(), "Dx");
	// END DEBUG code
	*/

	// Prepare input and output images for the passes over all dimensions
	View3D<std::complex<double>> input_images[3] = {
		input,
		IntermediateImages[0],
		IntermediateImages[1]};
	WriteView3D<std::complex<double>> output_images[3] = {
		IntermediateImages[0],
		// If the Z-dimension is degenerate (size 1), the second (Y) pass writes in output.
		// Each pass outputs with indexing (j, k, i),
		(input.size(2) > 1) ? IntermediateImages[1].view() : output.reorder_axes({2, 0, 1}),
		output};

	// Loop over all dimensions
	for (size_t i_dim=0; i_dim<3; ++i_dim) {
		// Per dimension, the inner loop performs 1D (i)fft's in that dimension
		// while two outer loops iterate over the other two dimensions.
		// By reordering the axes of the output image and using that as input
		// for the next pass, the input image can always be indexed as (i, j, k).
		//
		// In case one of the dimensions is degenerate (size 1), it is skipped.
		View3D<std::complex<double>> pass_input = input_images[i_dim];
		shape_t<3> pass_input_shape = pass_input.shape();
		WriteView3D<std::complex<double>> pass_output = output_images[i_dim];
		int Ni = pass_input_shape[0];
		int Nj = pass_input_shape[1];
		int Nk = pass_input_shape[2];
		if (Ni == 1) {
			continue;
		}
		DimProps& p = dim_props_[i_dim];
		int Lpass = p.fft.size();
		for (index_t k = 0; k < Nk; k++) {
			for (index_t j = 0; j < Nj; j++) {
				for (index_t i = 0; i < Ni; i++) {
					p.fft.in(i) = p.Ax(i) * pass_input(i, j, k);
				}
				for (index_t i = Ni; i < Lpass; i++) {
					p.fft.in(i) = 0;
				}

				p.fft.execute_forward();

				for (index_t i = 0; i < Lpass; i++) {
					p.fft.in(i) = p.fft.out(i) * p.Dx(i);
				}

				p.fft.execute_backward();

				// Store in output image, which has reordered axes
				for (index_t i = 0; i < pass_output.size(2); i++) {
					pass_output(j, k, i) = p.Bx(i) * p.fft.out(i) / (double) Lpass;
				}
			}
		}
	}
	/*
	// DEBUG code
	for (int iM=0; iM<dim_props_[0].M; ++iM)
	{
		dbg_report_1darray_diff(
			output2d.view(iM, placeholder::_),
			output.view(iM, placeholder::_, 0),
			"out[" + std::to_string(iM) + "]"
		);
	}
	// END DEBUG code
	*/
}

void CztPlan3D::PreChirpZ(
	index_t N,
	index_t M,
	double xsize,
	double qsize,
	Arr1D<std::complex<double>>& Ax,
	Arr1D<std::complex<double>>& Bx,
	Arr1D<std::complex<double>>& Dx
) {
	//This function is ported from the function below, for 3 dimensions.

	/*
	function [allA,allB,allD] = prechirpzn(allxsize,allqsize,allN,allM)
	% This function evaluates the auxiliary vectors for the evaluation of the
	% FT via the n-dimensional czt-algorithm
	% arguments: xsize = window in real space abs(x)<xsize
	%            qsize = window in Fourier space abs(q)<qsize
	%            N = # sample points in real space (even)
	%            M = # sample points in Fourier space (odd)
	% function value: A,B,D = auxiliary vectors of lengths N, M, and L=N+M-1
	%
	% copyright Sjoerd Stallinga, TU Delft, 2023
    */

	using namespace std::complex_literals;

	// computation ABD
	index_t L = N+M-1;
	double sigma = 2.0*M_PI*xsize*qsize/N/M;
	std::complex<double> Gfac = (2.0*xsize/N)*exp(1i*(sigma*(1.0-N)*(1.0-M)));

	for (size_t i=0; i<N; ++i) {
		Ax[i] = exp(2.0*1i*(sigma*i*(i+1.0-M)));
	}
	for (size_t i=0; i<M; ++i) {
		Bx[i] = Gfac*exp(2.0*1i*(sigma*i*(i+1.0-N)));
	}
	Arr1D<std::complex<double>> Vtmp(std::max(N,M) + 2);
	for (size_t i=0; i<=std::max(N,M)+1; ++i) {
		Vtmp[i] = exp(2.0*1i*(sigma*i*i));
	}

	for (size_t i=0; i<M; ++i) {
		Dx[i] = conj(Vtmp[i]);
	}
	for (size_t i=M; i<L; ++i) {
		Dx[i] = conj(Vtmp[L-i]);
	}

	FFT1DPlan fft(L);

	for (int i = 0; i < L; i++) {
		fft.in(i) = Dx[i];
	}

	fft.execute_forward();

	for (int i = 0; i < L; i++) {
		Dx[i] = fft.out(i);
	}
}
