#include "simpleton.hpp"

void other_function(const boost::numeric::ublas::matrix<double>& m) {
    m(0, 0) * 0.0;
}
