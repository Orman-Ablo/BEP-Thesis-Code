import kernel_tuner
from kernel_tuner.util import read_cache
import glob

files = glob.glob("*json")
files.sort(key=lambda f: ("float" in f, f))

for filename in files:
    try:
        cache = read_cache(filename, open_cache=False)["cache"]
    except Exception as e:
        print(e)
        cache = []

    if not cache:
        continue

    best = min(cache.values(), key=lambda r: r["time"])

    keys = [
        "block_size_x",
        "block_size_y",
        "blocks_per_sm",
        "time"
    ]

    items = [str(best[key]) for key in keys]
    line = f"{filename} {' '.join(items)}"
    print(line)

