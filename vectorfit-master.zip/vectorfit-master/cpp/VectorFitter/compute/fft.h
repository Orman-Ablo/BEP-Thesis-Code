#pragma once

#include <complex>

#include "MultiDimArray.h"
#include "fftw3.h"

class FFT1DPlan {
public:
	FFT1DPlan(int n = 0);
	FFT1DPlan(FFT1DPlan&&) noexcept;
	FFT1DPlan& operator=(FFT1DPlan&&) noexcept;

	FFT1DPlan(const FFT1DPlan& that): FFT1DPlan(that.size_) {}
	FFT1DPlan& operator=(const FFT1DPlan& that) {
		resize(that.size());
		return *this;
	}

	~FFT1DPlan();

	int size() const;
	void resize(int n);
	void execute_forward();
	void execute_backward();

	std::complex<double>& in(int index) {
		VF_DEBUG_ASSERT(index < size_);
		return *(std::complex<double>*)(input_ + index);
	}

	const std::complex<double> out(int index) const {
		VF_DEBUG_ASSERT(index < size_);
		return *(const std::complex<double>*)(output_ + index);
	}

private:
	int size_ = 0;
	fftw_complex *input_ = nullptr;
	fftw_complex *output_ = nullptr;
	fftw_plan plan_forward_ = nullptr;
	fftw_plan plan_backward_ = nullptr;
};

class FFT2DPlan {
public:
	FFT2DPlan(int nrows, int ncols);
	FFT2DPlan(): FFT2DPlan(0, 0) {}
	FFT2DPlan(FFT2DPlan&&) noexcept;
	FFT2DPlan& operator=(FFT2DPlan&&) noexcept;

	FFT2DPlan(const FFT2DPlan& that): FFT2DPlan(that.nrows_, that.ncols_) {}
	FFT2DPlan& operator=(const FFT2DPlan& that) {
		resize(that.nrows_, that.ncols_);
		return *this;
	}

	~FFT2DPlan();

	int nrows() const;
	int ncols() const;
	void resize(int nrows, int ncols);
	void execute_forward();
	void execute_backward();

	VF_INLINE
	std::complex<double>& in(int i, int j) {
		VF_DEBUG_ASSERT(i < ncols_ && j < nrows_);
		return *(std::complex<double>*)(input_ + i * ncols_ + j);
	}

	VF_INLINE
	std::complex<double> out(int i, int j) const {
		VF_DEBUG_ASSERT(i < ncols_ && j < nrows_);
		return *(const std::complex<double>*)(output_ + i * ncols_ + j);
	}

private:
	int nrows_ = 0;
	int ncols_ = 0;
	fftw_complex *input_ = nullptr;
	fftw_complex *output_= nullptr;
	fftw_plan plan_forward_ = nullptr;
	fftw_plan plan_backward_ = nullptr;
};
