#pragma once

#include <utility>

#include "MultiDimArray.h"
#include "cuda/allocator.h"
#include "cuda/memory.h"

template <typename T, size_t N>
class CudaArrayND: public StridedContainerOps<CudaArrayND<T, N>, T, N, MemorySpace::Device> {
	static_assert(std::is_trivially_copyable<T>::value, "type must be trivial copyable");

public:
	using base_type = StridedContainerOps<CudaArrayND<T, N>, T, N, MemorySpace::Device>;
	using typename base_type::strides_type;
	using typename base_type::shape_type;

	explicit CudaArrayND(CudaAllocator alloc = {}): allocator_(std::move(alloc)) {
		resize({});
	}

	explicit CudaArrayND(shape_type shape, CudaAllocator alloc = {}): CudaArrayND(alloc) {
		resize(shape);
	}

	explicit CudaArrayND(shape_type shape, fixed_vector<index_t, N> axes_order, CudaAllocator alloc = {}): CudaArrayND(alloc) {
		resize(shape, axes_order);
	}

	template <typename... Is, typename = typename std::enable_if<is_ndindex<N, Is...>>::type>
	explicit CudaArrayND(Is... sizes): CudaArrayND(shape_type{sizes...}) {
	}

	template <typename D, typename T2, MemorySpace S>
	explicit CudaArrayND(const StridedContainer<D, T2, N, S>& that): CudaArrayND(that.shape()) {
		cuda_copy(that, *this);
	}

	explicit CudaArrayND(const CudaArrayND& that): CudaArrayND(that.shape()) {
		cuda_copy(that, *this);
	}

	CudaArrayND(CudaArrayND&& that) noexcept {
		*this = std::move(that);
	}

	CudaArrayND& operator=(CudaArrayND&& that) noexcept {
		std::swap(data_, that.data_);
		std::swap(sizes_, that.sizes_);
		std::swap(strides_, that.strides_);
		std::swap(allocator_, that.allocator_);
		return *this;
	}

	~CudaArrayND() {
		free();
	}

	CUDA_HOST_DEVICE
	stride_t stride(size_t axis) const {
		VF_ASSERT(axis < N);
		return strides_[axis];
	}

	CUDA_HOST_DEVICE
	dim_t size(size_t axis) const {
		VF_ASSERT(axis < N);
		return sizes_[axis];
	}

	CUDA_HOST_DEVICE
	T* data() {
		return &data_[0];
	}

	CUDA_HOST_DEVICE
	const T* data() const {
		return &data_[0];
	}

	VF_INLINE
	void resize(shape_type new_shape) {
		fixed_vector<index_t, N> axes_order;
		for (size_t i = 0; i < N; i++) {
			axes_order[i] = index_t(i);
		}

		resize(new_shape, axes_order);
	}

	VF_INLINE
	void resize(shape_type new_shape, fixed_vector<index_t, N> axes_order) {

		// Check if the axes are a permutation of [0, ..., N - 1]:
		// 1. All entries in range 0 to N
		// 2. No duplicate entries.
		bool is_permutation = true;
		for (size_t i = 0; i < N; i++) {
			is_permutation &= axes_order[i] >= 0 && axes_order[i] < N;
		}
		for (size_t i = 0; i < N; i++) {
			for (size_t j = 0; j < i; j++) {
				is_permutation &= axes_order[i] != axes_order[j];
			}
		}
		VF_ASSERT(is_permutation);

		fixed_vector<stride_t, N> new_strides;
		stride_t total = 1;

		// iterate in reverse order since the last axis has the smallest stride.
		for (size_t i = N; i > 0; i--) {
			index_t axis = axes_order[i - 1];
			new_strides[axis] = total;
			total *= new_shape[axis];
		}

		// If the new strides and new sizes match the old ones, do not reallocate
		if (sizes_ == new_shape && strides_ == new_strides) {
			return;
		}

		free();

		if (total > 0) {
			data_ = static_cast<T*>(allocator_.allocate(sizeof(T) * total));
		}

		strides_ = new_strides;
		sizes_ = new_shape;
	}

	void free() {
		if (data_) {
			allocator_.deallocate(static_cast<void*>(data_));
			data_ = nullptr;
			sizes_ = {};
		}
	}

	template <typename... Is, typename = typename std::enable_if<is_ndindex<N, Is...>>::type>
	VF_INLINE
	void resize(Is... sizes) {
		resize(shape_type{sizes...});
	}


private:
	T* data_ = nullptr;
	shape_type sizes_ {};
	strides_type strides_ {};
	CudaAllocator allocator_;
};

template <typename T, size_t N>
class PinnedArrayND: public StridedContainerOps<PinnedArrayND<T, N>, T, N, MemorySpace::Host> {
	using base_type = StridedContainerOps<PinnedArrayND<T, N>, T, N, MemorySpace::Host>;
	using typename base_type::strides_type;
	using typename base_type::shape_type;

public:
	explicit PinnedArrayND(shape_type shape) {
		resize(shape);
	}

	template <typename... Is, typename = typename std::enable_if<is_ndindex<N, Is...>>::type>
	explicit PinnedArrayND(Is... sizes): PinnedArrayND(shape_type{sizes...}) {
	}

	PinnedArrayND(): PinnedArrayND(shape_type {}) {
	}

	template <typename D2, typename T2>
	PinnedArrayND(const Expression<D2, T2, N, MemorySpace::Host> &that) {
		*this = that;
	}

	PinnedArrayND(const PinnedArrayND& that) {
		*this = that;
	}

	PinnedArrayND(PinnedArrayND&&) noexcept = default;
	PinnedArrayND& operator=(PinnedArrayND&& rhs) noexcept = default;

	PinnedArrayND& operator=(const PinnedArrayND &rhs) {
		resize(rhs.shape());
		this->copy_from(rhs.derived());
		return *this;
	}

	template <typename D2, typename T2>
	PinnedArrayND& operator=(const Expression<D2, T2, N, MemorySpace::Host> &rhs) {
		resize(rhs.shape());
		this->copy_from(rhs.derived());
		return *this;
	}

	~PinnedArrayND() {
		resize({});
	}

	CUDA_HOST_DEVICE
	stride_t stride(size_t axis) const {
		VF_ASSERT(N > 0 && axis < N);
		stride_t result = 1;

		for (size_t i = axis + 1; i < N; i++) {
			result *= sizes_[i];
		}

		return result;
	}

	CUDA_HOST_DEVICE
	dim_t size(size_t axis) const {
		VF_ASSERT(N > 0 && axis < N);
		return sizes_[axis];
	}

	CUDA_HOST_DEVICE
	T* data() {
		return &data_[0];
	}

	CUDA_HOST_DEVICE
	const T* data() const {
		return &data_[0];
	}

	VF_INLINE
	void resize(shape_type new_shape, T initial = {}) {
		if (new_shape == sizes_ || N == 0) {
			return;
		}

		if (data_) {
			// Set data_ to nullptr here in case cuda_free throws exception
			T* old_ptr = data_;
			data_ = nullptr;
			sizes_ = {};

			cuda_free_pinned(old_ptr);
		}

		size_t total = 1;
		for (size_t i = 0; i < N; i++) {
			total *= new_shape[i];
		}

		if (total > 0) {
			// Only assign new_ptr to data_ after all elements have been initialized
			T *new_ptr = static_cast<T*>(cuda_malloc_pinned(total * sizeof(T)));

			for (size_t i = 0; i < total; i++) {
				new(&new_ptr[i]) T(initial);
			}

			data_ = new_ptr;
			sizes_ = new_shape;
		}
	}

	template <typename... Is, typename = typename std::enable_if<is_ndindex<N, Is...>>::type>
	VF_INLINE
	void resize(Is... sizes) {
		resize(shape_type{sizes...});
	}

	ViewND<T, N, MemorySpace::Host> as_host() {
		return {data(), this->shape(), this->strides()};
	}

	ViewND<const T, N, MemorySpace::Host> as_host() const {
		return {data(), this->shape(), this->strides()};
	}

	ViewND<T, N, MemorySpace::Device> as_device() {
		return {data(), this->shape(), this->strides()};
	}

	ViewND<const T, N, MemorySpace::Device> as_device() const {
		return {data(), this->shape(), this->strides()};
	}


private:
	T* data_ = nullptr;
	shape_type sizes_ {};
};

template <typename D1, typename D2, typename Ts, typename T, size_t N, MemorySpace S1, MemorySpace S2>
void cuda_copy(const StridedContainer<D1, Ts, N, S1>& src, StridedContainer<D2, T, N, S2>& dst) {
	static_assert(is_copy_compatible<Ts, T>::value && sizeof(Ts) == sizeof(T), "invalid container types");
	VF_ASSERT(src.shape() == dst.shape());
	auto shape = src.shape();

	const void* src_ptr = static_cast<const void*>(src.derived().data());
	void* dst_ptr = static_cast<void*>(dst.derived().data());

	if (src.is_contiguous() && dst.is_contiguous()) {
		size_t nbytes = src.numel() * sizeof(T);
		cuda_copy_raw(src_ptr, dst_ptr, nbytes);
	} else {
		auto src_strides = src.strides();
		auto dst_strides = dst.strides();
		cuda_copy_raw(src_ptr, dst_ptr, N, src_strides.data(), dst_strides.data(), shape.data(), sizeof(T));
	}
}

template <typename D1, typename D2, typename T1, typename T2, size_t N, MemorySpace S1, MemorySpace S2>
void cuda_copy(const StridedContainer<D1, T1, N, S1>& src, StridedContainer<D2, T2, N, S2>&& dst) {
	cuda_copy(src, dst);
}

template <typename D, typename T, size_t N, MemorySpace S>
CudaArrayND<typename std::remove_const<T>::type, N> cuda_copy(const StridedContainer<D, T, N, S>& src) {
	return CudaArrayND<typename std::remove_const<T>::type, N> {src};
}


// Some nice aliases
template <typename T> using CudaArr1D = CudaArrayND<T, 1>;
template <typename T> using CudaArr2D = CudaArrayND<T, 2>;
template <typename T> using CudaArr3D = CudaArrayND<T, 3>;
template <typename T> using CudaArr4D = CudaArrayND<T, 4>;
template <typename T> using CudaArr5D = CudaArrayND<T, 5>;
template <typename T> using CudaArr6D = CudaArrayND<T, 6>;
template <typename T> using CudaArr7D = CudaArrayND<T, 7>;

template <typename T> using PinnedArr1D = PinnedArrayND<T, 1>;
template <typename T> using PinnedArr2D = PinnedArrayND<T, 2>;
template <typename T> using PinnedArr3D = PinnedArrayND<T, 3>;
template <typename T> using PinnedArr4D = PinnedArrayND<T, 4>;
template <typename T> using PinnedArr5D = PinnedArrayND<T, 5>;
template <typename T> using PinnedArr6D = PinnedArrayND<T, 6>;
template <typename T> using PinnedArr7D = PinnedArrayND<T, 7>;