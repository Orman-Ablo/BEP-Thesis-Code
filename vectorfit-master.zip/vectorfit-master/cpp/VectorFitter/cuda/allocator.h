#include <mutex>
#include <map>
#include <memory>

struct CudaIAllocator {
	virtual ~CudaIAllocator() = default;
	virtual void* allocate(size_t nbytes) const = 0;
	virtual void deallocate(void* ptr) const = 0;
};

struct CudaGlobalAllocator: CudaIAllocator {
	void* allocate(size_t nbytes) const override;
	void deallocate(void* ptr) const override;
};

struct CudaPoolAllocator: CudaIAllocator {
	explicit CudaPoolAllocator(size_t capacity);
	CudaPoolAllocator(const CudaPoolAllocator&) = delete;
	CudaPoolAllocator& operator=(const CudaPoolAllocator&) = delete;

	~CudaPoolAllocator() override;
	void* allocate(size_t nbytes) const override;
	void deallocate(void* ptr) const override;

private:
	mutable std::mutex lock_;
	mutable std::multimap<size_t, void*> pool_ {};
	mutable std::map<void*, size_t> inuse_ {};
	mutable size_t nbytes_pool_ = 0;
	mutable size_t nbytes_inuse_ = 0;
	size_t bytes_capacity_ = 0;
	int device_;
};


struct CudaAllocator: CudaIAllocator {
	explicit CudaAllocator(std::shared_ptr<CudaIAllocator> allocator);
	CudaAllocator(): CudaAllocator(std::make_shared<CudaGlobalAllocator>()) {}

	static CudaAllocator create_pool(size_t capacity = std::numeric_limits<size_t>::max()) {
		return CudaAllocator(std::make_shared<CudaPoolAllocator>(capacity));
	}

	void* allocate(size_t nbytes) const override;
	void deallocate(void* ptr) const override;

private:
	std::shared_ptr<CudaIAllocator> allocator_;
};
