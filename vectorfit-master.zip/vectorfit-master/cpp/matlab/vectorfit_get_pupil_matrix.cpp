/* vectorfit_get_pupil_matrix
 * pupil_matrix = vectorfit_get_pupil_matrix(params, zernike_coeffs);
 * Calculates the pupil matrix, given a model parameter struct and aberration coefficients.
 * - params: struct containing TODO.
 * - zernike_coeffs: the Zernike aberration coefficients.
 *
 * returns the computed pupil matrix
*/

#include "vectorfit_mex.hpp"
#include "vectorfit_fitter.hpp"
#include "array/operators.h"


class MexFunction : public VectorfitMexFunction {
public:
    using Struct = matlab::data::Struct;
    using StructArray = matlab::data::StructArray;

    void execute(ArgumentList outputs, ArgumentList inputs) override {
        // Obtain fitter object handle
        const uint64_t handle = inputs[0][0];
        VectorfitFitter* fitter = VectorfitMemoryManager::get(handle);
        // Obtain zernike coefficients input
        TypedArray<double> input_zernike_coeffs = std::move(inputs[1]);
        matlab::data::buffer_ptr_t<double> zernike_coeffs_buffer = input_zernike_coeffs.release();
        // Compute result
        PupilMatrix pupil_matrix = fitter->fitter().get_pupil_matrix(
            zernike_coeffs_buffer.get()
        );

        // Populate output
        TypedArray<std::complex<double>> output_pupil_matrix = _array_factory.createArray(
            {
                (uint32_t)pupil_matrix.Matrix.size(0),
                (uint32_t)pupil_matrix.Matrix.size(1),
                (uint32_t)pupil_matrix.Matrix.size(2),
                (uint32_t)pupil_matrix.Matrix.size(3)
            },
            pupil_matrix.Matrix.begin(), pupil_matrix.Matrix.end(),
            matlab::data::InputLayout::ROW_MAJOR
        );
        outputs[0] = std::move(output_pupil_matrix);
    }

    void checkArguments(ArgumentList outputs, ArgumentList inputs) {
        // Check array arguments
        // inputs[0]: vectorfit_handle: uint64 scalar
        // inputs[1]: zernike_coeffs: double array
        if (inputs.size() != 2) {
            feval_error("Number of required inputs is 2: (vectorfit_handle, zernike_coefficients)");
        }

        // First input must be a uint64_t scalar
        if (inputs[0].getType() != ArrayType::UINT64 ||
            inputs[0].getNumberOfElements() != 1)
        {
            feval_error("Input 1 must be a vectorfit handle in the form of a uint64 scalar");
        }

        // Check zernike_coefficients
        if (inputs[1].getType() != ArrayType::DOUBLE ||
            inputs[1].getType() == ArrayType::COMPLEX_DOUBLE)
        {
            feval_error(
                "Input 2 'zernike_coefficients' must be a double array"
            );
        }

        // Check number of outputs
        if (outputs.size() > 1) {
            feval_error("Only one output is returned");
        }
    }
};
