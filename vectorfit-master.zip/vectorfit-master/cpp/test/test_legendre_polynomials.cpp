#include "catch.hpp"
#include "compute/legendre_polynomials.h"


TEST_CASE("LegendrePolynomials_1d_input")
{
    std::array<int, 5> orders_data{1, 2, 3, 2, 1};
    Arr1D<int> orders((int)orders_data.size());
    std::copy(orders_data.begin(), orders_data.end(), orders.begin());

    std::array<double, 4> x_data{0.1, -0.1, -0.9, 0.8};
    Arr1D<double> x((int)x_data.size());
    std::copy(x_data.begin(), x_data.end(), x.begin());
    auto result = compute::legendre_polynomials::get(orders, x);

    for (const auto& legpol : result)
    {
        std::cout << legpol << std::endl;
    }
}

TEST_CASE("LegendrePolynomials_2d_input")
{
    std::array<int, 5> orders_data{1, 2, 3, 2, 1};
    Arr1D<int> orders((int)orders_data.size());
    std::copy(orders_data.begin(), orders_data.end(), orders.begin());

    constexpr int dim_1_size = 4;
    constexpr int dim_2_size = 3;
    std::array<std::array<double, dim_1_size>, dim_2_size> x_data{{
        { 0.1, -0.1, -0.9,  0.8},
        { 0.8, -0.9, -0.1,  0.1},
        {-0.9,  0.8,  0.1, -0.1}
    }};
    Arr2D<double> x(dim_2_size, dim_1_size);
    for (int d2=0; d2 < dim_2_size; ++d2)
    {
        std::copy(x_data[d2].begin(), x_data[d2].end(), x.view(d2, placeholder::_).begin());
    }
    auto result = compute::legendre_polynomials::get(orders, x);
    // Output result
    std::cout << "Result:\n";
    for (const auto& legpol : result)
    {
        std::cout << legpol << std::endl;
    }
}

TEST_CASE("LegendrePolynomials2D_2d_input")
{
    constexpr int num_orders = 5;
    std::array<int, num_orders> orders_x_data{1, 2, 3, 2, 1};
    std::array<int, num_orders> orders_y_data{3, 2, 1, 2, 3};
    Arr2D<int> orders(2, num_orders);
    std::copy(orders_x_data.begin(), orders_x_data.end(), orders.view(0, placeholder::_).begin());
    std::copy(orders_y_data.begin(), orders_y_data.end(), orders.view(1, placeholder::_).begin());

    constexpr int dim_1_size = 4;
    constexpr int dim_2_size = 3;
    std::array<std::array<double, dim_1_size>, dim_2_size> x_data{{
        { 0.1, -0.1, -0.9,  0.8},
        { 0.8, -0.9, -0.1,  0.1},
        {-0.9,  0.8,  0.1, -0.1}
    }};
    std::array<std::array<double, dim_1_size>, dim_2_size> y_data{{
        {-0.9,  0.8,  0.1, -0.1},
        { 0.1, -0.1, -0.9,  0.8},
        { 0.8, -0.9, -0.1,  0.1}
    }};
    Arr2D<double> x(dim_2_size, dim_1_size);
    for (int d2=0; d2 < dim_2_size; ++d2)
    {
        std::copy(x_data[d2].begin(), x_data[d2].end(), x.view(d2, placeholder::_).begin());
    }
    Arr2D<double> y(dim_2_size, dim_1_size);
    for (int d2=0; d2 < dim_2_size; ++d2)
    {
        std::copy(y_data[d2].begin(), y_data[d2].end(), y.view(d2, placeholder::_).begin());
    }
    auto result = compute::legendre_polynomials::get2D(orders, x, y);

    // Output result
    std::cout << "Result:\n";
    for (const auto& legpol : result)
    {
        std::cout << legpol << std::endl;
    }
}
