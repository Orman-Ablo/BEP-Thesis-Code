clear all;

% Load data
with_const_aberrations = true;
compare_matlab_cpp = true;
spot_replication_factor = 1; % Set this > 1 to test with more (replicated) spots

% Note: a simulation data set can be created by running
% simulation_NAT_aberration_algorithm.m and storing
% all workspace variables in a sigle file named 'alldata.mat'.
testfolder = 'cpp/test/data/simulation_Mx=9_Npupil=40_Ncfg=1000';
%testfolder = 'cpp/test/data/simulation_Mx=21_Npupil=44_Ncfg=1000';
load(append(testfolder, '/alldata.mat'));
cpp_spots = allspots;

% Create params struct: copy Matlab params and add extra fields
cpp_params = params;

% Spot replication to test with more spots by replicating them
if spot_replication_factor > 1
    cpp_params.Ncfg = cpp_params.Ncfg * spot_replication_factor;
    params.Ncfg = params.Ncfg * spot_replication_factor;
    cpp_spots = repmat(allspots, 1, 1, 1, spot_replication_factor);
    theta_full.local = repmat(theta_full.local, 1, spot_replication_factor, 1);
    roixy = repmat(roixy, 1, spot_replication_factor);
end

% Note: fitmodel has to be selected manually for now
cpp_params.fitmodel = 'xy-gamma';
if with_const_aberrations
    cpp_params.fitmodel = append(cpp_params.fitmodel, '_constaberrations');
end
cpp_params.initialization = 'phasor';
cpp_params.FlagOTF = false;
cpp_params.max_local_iterations = 5;
% OTF parans:
%params.NFourier = ?;
%params.FourierWindow = ?;
%parmas.XRange2 = ?;
%params.YRange2 = ?;
%params.zstage = 0;

cpp_params.pupilsize = cpp_params.NA/cpp_params.lambda;

%cpp_params.ringradius = int64( 1 );
%cpp_params.doelevels = int64( 64 );
%cpp_params.doephasedepth = int64( 593 );

cpp_params.PSFBlur = false;

aberration_orders = [ ...
    2, -2,  0;
    2,  0,  0;
    2,  2,  0;
    3, -1,  0;
    3,  1,  0;
    4,  0,  0;];

% Create vectorfitter object
fitter = vectorfitter(cpp_spots, roixy, cpp_params, "gpu");

% Matlab pupil matrix comparison
if compare_matlab_cpp && size(cpp_spots,4) == params.Ncfg
    pupil_matrix_zernike_coefficients = rand(6,1);
    [wavevector,wavevectorzimm,~,allzernikes,PupilMatrixInit] = get_pupil_matrix(params, pupil_matrix_zernike_coefficients);
    cpp_pupil_matrix = fitter.get_pupil_matrix(pupil_matrix_zernike_coefficients);
    pupil_matrix_max_diff = max(max(max(max(abs(cpp_pupil_matrix - PupilMatrixInit)))))
end

% Set initial zernike coefficients
if with_const_aberrations
    theta_global_init = zeros(13,1);
    cpp_zernike_coeffs = fitter.update_zernike_coefficients(theta_global_init, aberration_orders);
end

% Initialize theta
cpp_theta_init = fitter.theta_init();
if compare_matlab_cpp
    theta_init_max_diff = max(max(abs(cpp_theta_init - thetainit.local)))
end

% Recompute zernike coefficients (should be zeros)
if with_const_aberrations
    cpp_zernike_coeffs = fitter.update_zernike_coefficients(thetastore.global(:,1), aberration_orders);
end

% As test, flip Z-coordinates. Only possible if the model has z.
%theta_fipped_z = fitter.flip_z();

% Perform local update
[cpp_theta_update, cpp_num_iters] = fitter.local_update();
if compare_matlab_cpp
    theta_update1_max_diff = max(max(abs(cpp_theta_update - thetastore.local(:,:,2))))
end

% Get outliers
outliers = fitter.outliers();

% Get Fisher CRLB
crlb = fitter.fisher_crlb();

% Get Mu and dMu/dTheta
mu = fitter.mu();
dmudtheta = fitter.dmudtheta();

% Recompute Zernike coefficients
if with_const_aberrations
    cpp_zernike_coeffs = fitter.update_zernike_coefficients(thetastore.global(:,2), aberration_orders);
    %zernike_coeffs_max_diff = max(max(abs(zernike_coefficients_1 - cpp_zernike_coeffs)))
end

% Perform subsequent local update
[cpp_theta_update, cpp_num_iters] = fitter.local_update();
if compare_matlab_cpp
    theta_update2_max_diff = max(max(abs(cpp_theta_update - thetastore.local(:,:,3))))
end

% Get outliers
outliers = fitter.outliers();

% Explicit cleanup of vectorfitter object
% This is not necessary; it will happen automatically when the variable
% is reassigned, goes out of scope, is cleared or is deleted.
delete(fitter)
