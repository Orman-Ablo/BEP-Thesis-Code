#include "catch.hpp"
#include "compute/zernike_coefficients.h"
#include "array/operators.h"


TEST_CASE("ZernikeCoefficients")
{
    /// This test computes Zernike coefficients for some arbitrarily chosen test data
    /// and compares it with the result computed by the Matlab implementation.

    using Aberration = compute::zernike_coefficients::Aberration;
    std::array<double, 4> x_data{0.1, -0.1, -0.9, 0.8};
    Arr1D<double> x((int)x_data.size());
    std::copy(x_data.begin(), x_data.end(), x.begin());

    std::array<double, 4> y_data{-0.9,  0.8,  0.1, -0.1};
    Arr1D<double> y((int)y_data.size());
    std::copy(y_data.begin(), y_data.end(), y.begin());

    std::array<double, 13> gammas_data{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
    Arr1D<double> gammas((int)gammas_data.size());
    std::copy(gammas_data.begin(), gammas_data.end(), gammas.begin());

    Arr1D<Aberration> aberrations(6);
    aberrations[0] = Aberration{2, -2, 0.0};
    aberrations[1] = Aberration{2,  0, 0.0};
    aberrations[2] = Aberration{2,  2, 0.0};
    aberrations[3] = Aberration{3, -1, 0.0};
    aberrations[4] = Aberration{3,  1, 0.0};
    aberrations[5] = Aberration{4,  0, 0.0};

    Arr2D<double> result(x.size(0), aberrations.size(0));
    compute::zernike_coefficients::compute_xy_gamma_legendre(x, y, gammas, aberrations, result);

    //std::cout << "Zernike coefficients:\n" << result << std::endl;

    // Compare with result from Matlab:
    std::vector<std::vector<double>> matlab_result{
        {-10.816279441628826, -3.0319846219222226, 45.516017109791605, -7.706148721743876, 12.078460969082652, 13},
        {7.8338438763306106, 2.5744437991517413, 13.833281653633986, 27.627687752661224, 7.921539030917347, 13},
        {-12.548330249197702, -1.299933814353345, -34.1303764637365, 13.078460969082652, -8.706148721743876, 13},
        {9.3926896031426, 1.0155980723397517, -5.0457172189322, 8.9215390309173479, 26.627687752661224, 13}
    };

    const double epsilon = 1e-10;
    for (int i=0; i<(int)matlab_result.size(); ++i)
    {
        for (int j=0; j<(int)matlab_result[0].size(); j++)
        {
            INFO("Comparing Zernike coefficient " << i << ", " << j << " with epsilon=" << epsilon);
            INFO("Result:  " << result.access({i, j}) << ", Matlab result: " << matlab_result[i][j]);
            CHECK(std::abs(matlab_result[i][j] - result.access({i, j})) < epsilon);
        }
    }
}
