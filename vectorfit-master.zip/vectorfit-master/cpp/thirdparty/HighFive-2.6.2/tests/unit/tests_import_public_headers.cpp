// This is a compilation test to be sure that public header can be included alone

#include <@PUBLIC_HEADER@>

int main() {
    return 0;
}
