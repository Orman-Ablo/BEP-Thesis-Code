/* vectorfit_get_mu()
 * Returns Mu for all spots from the last local update.
 *
 * returns a 4D array with Mu for all spots.
*/

#include "vectorfit_mex.hpp"
#include "vectorfit_fitter.hpp"
#include "array/operators.h"


class MexFunction : public VectorfitMexFunction {
public:
    using ArgumentList = matlab::mex::ArgumentList;
    using Struct = matlab::data::Struct;
    using StructArray = matlab::data::StructArray;

    void execute(ArgumentList outputs, ArgumentList inputs) {
        // Obtain fitter object handle
        const uint64_t handle = inputs[0][0];
        VectorfitFitter* fitter = VectorfitMemoryManager::get(handle);
        // Obtain Mu.
        // Shape: (num_spots, Mx, My, Mz).
        View4D<double> mu = fitter->fitter().mu();

        // Output Mu for all spots.
        // Shape: (Mx, My, Mz, num_spots).
        TypedArray<double> output_mu = _array_factory.createArray<double>(
            {
                (uint64_t)mu.size(1),
                (uint64_t)mu.size(2),
                (uint64_t)mu.size(3),
                (uint64_t)mu.size(0),
            }
        );

        // Create output iterator and copy data.
        // Since mu is in row-major layout and output_mu in col-major layout,
        // the iterator dimensions are reversed:
        //   output dimensions:   (1, 2, 3, 0)
        //   iterator dimensions: (0, 3, 2, 1)
        auto output_mu_begin = output_mu.begin();
        mu.reorder_axes({0, 3, 2, 1}).for_each(
            [&](const double& value) {*(output_mu_begin++) = value;}
        );
        outputs[0] = output_mu;
    }

    void checkArguments(ArgumentList outputs, ArgumentList inputs) {
        // Check array arguments
        if (inputs.size() != 1) {
            feval_error("Number of required inputs is 1: (vectorfit_handle)");
        }
        // Check array argument: first input must be a uint64_t scalar
        if (inputs[0].getType() != ArrayType::UINT64 ||
            inputs[0].getNumberOfElements() != 1)
        {
            feval_error("Input 1 must be a vectorfit handle in the form of a uint64 scalar");
        }
        if (outputs.size() != 1)
        {
            feval_error("One output is returned: a matrix with Mu per spot");
        }
    }
};
