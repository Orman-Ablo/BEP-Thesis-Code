#pragma once

#include "core.h"
#include "stack_array.h"
#include "host_array.h"

template <typename E>
struct ExpressionNested;

template <typename T, size_t N, MemorySpace space>
struct ExpressionNested<ViewND<T, N, space>> {
	using type = ViewND<const T, N, space>;
};

template <typename T, size_t N>
struct ExpressionNested<ArrayND<T, N>> {
	using type = ViewND<const T, N, MemorySpace::Host>;
};

template <typename T, dim_t... Sizes>
struct ExpressionNested<StackArrayND<T, Sizes...>> {
	using type = ViewND<const T, sizeof...(Sizes), MemorySpace::Host>;
};

template <typename T, size_t N, MemorySpace space = MemorySpace::Host>
struct ScalarOperator: ExpressionOps<ScalarOperator<T, N>, T, N, space> {
	ScalarOperator(T value, shape_t<N> shape): value_(std::move(value)), shape_(shape) {}

	VF_INLINE
	dim_t size(size_t axis) const {
		return shape_[axis];
	}

	VF_INLINE
	T access(ndindex_t<N>) const {
		return value_;
	}

private:
	T value_;
	shape_t<N> shape_;
};

template <typename T, size_t N>
struct ExpressionNested<ScalarOperator<T, N>> {
	using type = ScalarOperator<T, N>;
};

template <typename F, typename L, typename R>
using binary_operator_result_t = decltype(std::declval<F>()(
		std::declval<typename L::value_type>(),
		std::declval<typename R::value_type>()));

template <typename F, typename L, typename R>
struct BinaryOperator: ExpressionOps<BinaryOperator<F, L, R>, binary_operator_result_t<F, L, R>, L::rank, L::space> {
	static_assert(L::rank == R::rank, "Operands have equal rank");
	static_assert(L::space == R::space, "Operands must have equal memory space");
	static constexpr size_t rank = L::rank;

	BinaryOperator(F fun, L lhs, R rhs): fun_(std::move(fun)), lhs_(std::move(lhs)), rhs_(std::move(rhs)) {
		VF_ASSERT(lhs.shape() == rhs.shape());
	}

	BinaryOperator(L lhs, R rhs): BinaryOperator({}, std::move(lhs), std::move(rhs)) {}

	VF_INLINE
	dim_t size(size_t axis) const {
		VF_DEBUG_ASSERT(lhs_.size(axis) == rhs_.size(axis));
		return lhs_.size(axis);
	}

	VF_INLINE
	binary_operator_result_t<F, L, R> access(ndindex_t<rank> ndindex) const {
		return fun_(lhs_.access(ndindex), rhs_.access(ndindex));
	}

private:
	F fun_;
	L lhs_;
	R rhs_;
};

template <typename F, typename L, typename R>
struct ExpressionNested<BinaryOperator<F, L, R>> {
	using type = BinaryOperator<F, L, R>;
};

template <typename F, typename L, typename R>
using binary_expr_t = BinaryOperator<F, typename ExpressionNested<L>::type, typename ExpressionNested<R>::type>;
template <typename D, typename T, size_t N>
D& operator+=(StridedContainerOps<D, T, N, MemorySpace::Host>& lhs, T rhs) {
	iterate_nd(lhs.shape(), [&](auto index) {
		lhs.access(index) += rhs;
	});

	return lhs.derived();
}

template <typename D, typename T, size_t N>
D& operator+=(StridedContainerOps<D, T, N, MemorySpace::Host>&& lhs, T rhs) {
	iterate_nd(lhs.shape(), [&](auto index) {
		lhs.access(index) += rhs;
	});

	return lhs.derived();
}

template <typename D, typename T, size_t N>
D& operator-=(StridedContainerOps<D, T, N, MemorySpace::Host>& lhs, T rhs) {
	iterate_nd(lhs.shape(), [&](auto index) {
		lhs.access(index) -= rhs;
	});

	return lhs.derived();
}

template <typename D, typename T, size_t N>
D& operator-=(StridedContainerOps<D, T, N, MemorySpace::Host>&& lhs, T rhs) {
	iterate_nd(lhs.shape(), [&](auto index) {
		lhs.access(index) -= rhs;
	});

	return lhs.derived();
}

template <typename D, typename T, size_t N>
D& operator*=(StridedContainerOps<D, T, N, MemorySpace::Host>& lhs, T rhs) {
	iterate_nd(lhs.shape(), [&](auto index) {
		lhs.access(index) *= rhs;
	});

	return lhs.derived();
}

template <typename D, typename T, size_t N>
D& operator*=(StridedContainerOps<D, T, N, MemorySpace::Host>&& lhs, T rhs) {
	iterate_nd(lhs.shape(), [&](auto index) {
		lhs.access(index) *= rhs;
	});

	return lhs.derived();
}

template <typename D, typename T, size_t N>
D& operator/=(StridedContainerOps<D, T, N, MemorySpace::Host>& lhs, T rhs) {
	iterate_nd(lhs.shape(), [&](auto index) {
		lhs.access(index) /= rhs;
	});

	return lhs.derived();
}

template <typename D, typename T, size_t N>
D& operator/=(StridedContainerOps<D, T, N, MemorySpace::Host>&& lhs, T rhs) {
	iterate_nd(lhs.shape(), [&](auto index) {
		lhs.access(index) /= rhs;
	});

	return lhs.derived();
}

template <typename D, typename T, typename D2, typename T2, size_t N>
D& operator+=(StridedContainerOps<D, T, N, MemorySpace::Host>& lhs, const Expression<D2, T2, N, MemorySpace::Host>& rhs) {
	VF_ASSERT(lhs.shape() == rhs.shape());
	iterate_nd(lhs.shape(), [&](auto index) {
		lhs.access(index) += rhs.derived().access(index);
	});

	return lhs.derived();
}

template <typename D, typename T, typename D2, typename T2, size_t N>
D& operator-=(StridedContainerOps<D, T, N, MemorySpace::Host>& lhs, const Expression<D2, T2, N, MemorySpace::Host>& rhs) {
	VF_ASSERT(lhs.shape() == rhs.shape());
	iterate_nd(lhs.shape(), [&](auto index) {
		lhs.access(index) -= rhs.derived().access(index);
	});

	return lhs.derived();
}

template <typename D, typename T, typename D2, typename T2, size_t N>
D& operator*=(StridedContainerOps<D, T, N, MemorySpace::Host>& lhs, const Expression<D2, T2, N, MemorySpace::Host>& rhs) {
	VF_ASSERT(lhs.shape() == rhs.shape());
	iterate_nd(lhs.shape(), [&](auto index) {
		lhs.access(index) *= rhs.derived().access(index);
	});

	return lhs.derived();
}

template <typename D, typename T, typename D2, typename T2, size_t N>
D& operator/=(StridedContainerOps<D, T, N, MemorySpace::Host>& lhs, const Expression<D2, T2, N, MemorySpace::Host>& rhs) {
	VF_ASSERT(lhs.shape() == rhs.shape());
	iterate_nd(lhs.shape(), [&](auto index) {
		lhs.access(index) /= rhs.derived().access(index);
	});

	return lhs.derived();
}

template <typename D1, typename T1, typename D2, typename T2, size_t N, MemorySpace space>
binary_expr_t<std::plus<void>, D1, D2>
operator+(const Expression<D1, T1, N, space>& lhs, const Expression<D2, T2, N, space> &rhs) {
	return {lhs.derived(), rhs.derived()};
}

template <typename D, typename T, size_t N, MemorySpace space>
binary_expr_t<std::plus<void>, D, ScalarOperator<T, N>>
operator+(const Expression<D, T, N, space>& lhs, T rhs) {
	return {lhs.derived(), ScalarOperator(rhs, lhs.derived().shape())};
}

template <typename D1, typename T1, typename D2, typename T2, size_t N, MemorySpace space>
binary_expr_t<std::minus<void>, D1, D2>
operator-(const Expression<D1, T1, N, space>& lhs, const Expression<D2, T2, N, space> &rhs) {
	return {lhs.derived(), rhs.derived()};
}

template <typename D, typename T, size_t N, MemorySpace space>
binary_expr_t<std::minus<void>, D, ScalarOperator<T, N>>
operator-(const Expression<D, T, N, space>& lhs, T rhs) {
	return {lhs.derived(), ScalarOperator(rhs, lhs.derived().shape())};
}

template <typename D1, typename T1, typename D2, typename T2, size_t N, MemorySpace space>
binary_expr_t<std::multiplies<void>, D1, D2>
operator*(const Expression<D1, T1, N, space>& lhs, const Expression<D2, T2, N, space> &rhs) {
	return {lhs.derived(), rhs.derived()};
}

template <typename D, typename T, size_t N, MemorySpace space>
binary_expr_t<std::multiplies<void>, D, ScalarOperator<T, N>>
operator*(const Expression<D, T, N, space>& lhs, T rhs) {
	return {lhs.derived(), ScalarOperator(rhs, lhs.derived().shape())};
}

template <typename D1, typename T1, typename D2, typename T2, size_t N, MemorySpace space>
binary_expr_t<std::divides<void>, D1, D2>
operator/(const Expression<D1, T1, N, space>& lhs, const Expression<D2, T2, N, space> &rhs) {
	return {lhs.derived(), rhs.derived()};
}

template <typename D, typename T, size_t N, MemorySpace space>
binary_expr_t<std::divides<void>, D, ScalarOperator<T, N>>
operator/(const Expression<D, T, N, space>& lhs, T rhs) {
	return {lhs.derived(), ScalarOperator(rhs, lhs.derived().shape())};
}

template <typename Derived, typename T>
std::ostream& operator<<(std::ostream& stream, const Expression<Derived, T, 0, MemorySpace::Host>& expr) {
	return stream << expr.derived().access({});
}

template <typename Derived, typename T, size_t N>
std::ostream& operator<<(std::ostream& stream, const Expression<Derived, T, N, MemorySpace::Host>& expr) {
	size_t len = expr.derived().size(0);
	stream << "{";
	if (len < 10) {
		for (size_t i = 0; i < len; i++) {
			if (i != 0) stream << ", ";
			stream << expr.derived().drop_axis(0, i);
		}
	} else {
		for (size_t i = 0; i < 3; i++) {
			if (i != 0) stream << ", ";
			stream << expr.derived().drop_axis(0, i);
		}

		stream << "...";

		for (size_t i = len - 3; i < len; i++) {
			stream << ", " << expr.derived().drop_axis(0, i);
		}
	}

	return stream << "}";
}