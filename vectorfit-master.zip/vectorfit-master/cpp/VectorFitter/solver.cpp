#include "estimator/interface.h"
#include "Parameters.h"
#include "compute/theta.h"

void localize_spots(
		const FitParams& fitParams,
		BaseEstimator& estimator,
		View4D<double> Spots,
		View2D<double> ThetaInit,
		WriteView3D<double> AllTheta,
		WriteView4D<double> Mu,
		WriteView5D<double> dmudtheta,
		WriteView2D<double> AllMerit,
		WriteView1D<int> NumIters
) {
	using namespace placeholder;

	int Ncfg = Spots.size(0);

	double tollim = fitParams.Tollim;
	int Nitermax = fitParams.NiterMax;
	int numparams = fitParams.NumParams;
	FitModelEnum FitModel = fitParams.FitModel;

	Arr2D<double> ThetaCurrent(Ncfg, numparams);
	Arr2D<double> ThetaTry(Ncfg, numparams);
	Arr2D<double> ThetaMin(Ncfg, numparams);
	Arr2D<double> ThetaMax(Ncfg, numparams);
	Arr2D<double> ThetaRetry(Ncfg, numparams);

	Arr1D<double> Merit(Ncfg);
	Arr3D<double> Hessian(Ncfg, numparams, numparams);
	Arr2D<double> gradL(Ncfg, numparams);

	Arr1D<double> MeritTry(Ncfg);
	Arr3D<double> HessianTry(Ncfg, numparams, numparams);
	Arr2D<double> gradTry(Ncfg, numparams);

	ThetaCurrent = ThetaInit;

	for (int cfg = 0; cfg < Ncfg; cfg++) {
		compute::ThetaLimits(
				fitParams,
				ThetaCurrent[cfg],
				ThetaMin[cfg],
				ThetaMax[cfg],
				ThetaRetry[cfg]);
	}

	Arr1D<index_t> ActiveCfg(Ncfg);
	Arr1D<bool> IsConverged(Ncfg);
	Arr1D<double> AllLambda(Ncfg);
	Arr1D<bool> IsActive(Ncfg);

	for (index_t i = 0; i < Ncfg; i++) {
		ActiveCfg(i) = i;
		IsActive(i) = true;
		IsConverged(i) = false;
		AllLambda(i) = 1.0;
	}

	estimator.initialize(Spots);
	estimator.calculate_PSF(
		IsActive,
		ThetaTry,
		Merit,
		gradL,
		Hessian);

	const double alamdafac = 10;
	int iiter = 0;

	for (; iiter < Nitermax; iiter++) {
		int num_active = 0;
		int num_converged = 0;

		for (int cfg = 0; cfg < Ncfg; cfg++) {
			if (IsConverged(cfg)) {
				IsActive(cfg) = false;
				continue;
			}

			NumIters(cfg) = iiter + 1;

			// Update theta
			bool updated = compute::ThetaUpdate(
					fitParams,
					ThetaCurrent[cfg],
					ThetaMax[cfg],
					ThetaMin[cfg],
					ThetaRetry[cfg],
					gradL[cfg],
					Hessian[cfg],
					AllLambda[cfg],
					ThetaTry[cfg]);

			IsActive(cfg) = updated;
		}

		for (int cfg = 0; cfg < Ncfg; cfg++) {
			if (IsActive(cfg)) {
				ActiveCfg(num_active++) = cfg;
			}

			if (IsConverged(cfg)) {
				num_converged++;
			}
		}

		std::cout << "iteration " << iiter << ": " <<
				  num_active << " spots active, " <<
				  num_converged << " spots converged" << std::endl;

		if (num_converged == Ncfg) {
			break;
		}

		estimator.calculate_PSF(
			IsActive,
			ThetaTry,
			MeritTry,
			gradTry,
			HessianTry);

		for (int cfg = 0; cfg < Ncfg; cfg++) {
			if (IsConverged(cfg)) {
				continue;
			}

			double merit = Merit(cfg);
			double meritTry = MeritTry(cfg);
			double dmerit = meritTry - merit;

			// modify Levenberg - Marquardt parameter
			if (IsActive(cfg) && dmerit > 0) {
				AllLambda[cfg] /= alamdafac;
				Merit[cfg] = meritTry;
				gradL[cfg] = gradTry[cfg];
				Hessian[cfg] = HessianTry[cfg];
				ThetaCurrent[cfg] = ThetaTry[cfg];
				ThetaRetry[cfg] = ThetaTry[cfg];
				IsConverged[cfg] = std::abs(dmerit / meritTry) <= tollim;
			} else {
				AllLambda[cfg] *= alamdafac;
			}
		}

		AllTheta.view(_, _, iiter + 1) = ThetaCurrent;
		AllMerit.view(_, iiter + 1) = Merit.view(_);
	}

	for (; iiter < Nitermax; iiter++) {
		AllTheta.view(_, _, iiter + 1) = ThetaCurrent;
		AllMerit.view(_, iiter + 1) = Merit.view(_);
	}

	estimator.retrieve_final_mu(Mu, dmudtheta);

	for (int cfg = 0; cfg < Ncfg; cfg++) {
		compute::AddMeritOffset(fitParams, AllMerit[cfg], Spots[cfg]);
	}
}