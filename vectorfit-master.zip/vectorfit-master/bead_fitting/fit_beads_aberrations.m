% Fit aberrations from beads and plot results
% - First the raw data is segmented in ROIs
% - Then, the aberrations of the ROIs is fitted.
% - The results are plotted.

clear all
close all

%% Settings

% File that contains the raw data

%path_input_data = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Hertenlab\data_analysis\beads\average_stacks\647_beads_10nmSteps_avg_Pos2_647_100_0.tif';
%path_input_data = '/home/idroste/Desktop/TUDelft/Data/Hertenlab/data_analysis/beads/averaged_stacks/647_beads_10nmSteps_avg_Pos4_647_100_0.tif';
%path_input_data = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Hertenlab\data_analysis\beads\average_stacks\647_beads_10nmSteps_avg_Pos2_647_100_0.tif';
%path_input_data = '/home/idroste/Desktop/TUDelft/Data/Hertenlab/data_analysis/beads/averaged_frames/647_beads_10nmSteps_avg_Pos2_647_100_0.tif';
%path_input_data = 'C:\Users\idroste\Desktop\TUDelft\Data\NAT_data\Yutong_nanorulers\raw_data\beads_CMOS\Cali1201_Bead100_Oil100x_Col175_647P300-100_Hama_500ms_*';
%path_input_data = 'U:\NATaberrations\ExperimentalData\Lidke\raw_data\UNM_Data1\DATA1\Bead_data\Without_Astigmatism\combined\zstack_*';
%path_input_data = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\DafeiShechtman\raw_data\beads\separated\stk_0*';
path_input_data = '/home/idroste/Desktop/TUDelft/Data/Lidke/raw_data/DATA1/beads/with_astigmatism/zstack_008.mat';

% Folder where the results will be stored
%path_output_data = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Hertenlab\data_analysis\beads\results\result_';
%path_output_data = '/home/idroste/Desktop/TUDelft/Data/Hertenlab/data_analysis/beads/results/results_tilt_';
%path_output_data = 'C:\Users\idroste\Desktop\TUDelft\Data\NAT_data\Yutong_nanorulers\data_analysis\CMOS\beads\results\results_';
%path_output_data = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Hertenlab\data_analysis\beads\result_tilt\result_';
%path_output_data = '/home/idroste/Desktop/TUDelft/Data/Hertenlab/data_analysis/beads/results/results_all_';
%path_output_data = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Yutong_Nanorulers\data_analysis\CMOS\beads\thr_200\results_';
%path_output_data = 'U:\NATaberrations\ExperimentalData\Lidke\data_analysis\DATA1\beads\Without_Astigmatism\results_';
%path_output_data = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\DafeiShechtman\data_analysis\beads\results_';
path_output_data = '/home/idroste/Desktop/TUDelft/Data/Lidke/data_analysis/beads/With_Astigmatism/results_';

% Set parameters
%%% Some important parameters:
% params.ROI_thr : segmentation threshold. You can check it in the figure
% params.aberrations : here you can set the initial values to help the
% algorithm find the aberrations
% params.beaddiameter
%params = set_parameters_zstack_bead_Cali1031_100bead_Oil100x;
%params = set_parameters_xy_NAT_Herten_beads;
%params = set_parameters_zstack_bead_Cali1201_CMOS;
params = set_parameters_Lidke_beads;
%params = set_parameters_Shechtman_beads;

params.delete_parpool = false;
% Set up parallel pool
if isempty(gcp('nocreate'))
    number_of_parallel_workers = params.nr_of_parallel_workers;
    parpool('Threads', number_of_parallel_workers);
end

all_input_files = dir(path_input_data);
nr_of_files = size(all_input_files,1);
fprintf('Found %i files\n',nr_of_files);

%%
%for file_i=1:nr_of_files
for file_i=1:1
%file_i = 1;
    filename = all_input_files(file_i).name; 
    foldername = all_input_files(file_i).folder;
    path_input_data_full = fullfile(foldername, filename);    
    fprintf('Input bead data = %s\n',path_input_data_full);

    % Segmentation
    segmentation_beads_difference_uniform  
  
    % Ncfg = size(allspots,4);
    % range = randperm(Ncfg,100);
    % allspots = allspots(:,:,:,range);
    % roixy = roixy(:,range);
    % ID = ID(range);
    % framelist = framelist(range);
    % 
    % Aberration fitting   
    Ncfg_total = size(allspots,4);
    params.Ncfg_total = Ncfg_total;
    params.Ncfg_global = Ncfg_total;
    params.Ncfg = Ncfg_total;
    
    fprintf('\nPerform local fit with %i spots\n',Ncfg_total);
    
    max_local_iterations = params.max_local_iterations;
    numparams = params.numparams;
    
    theta_global = zeros(13,1);
    
    theta_local = initialvalues_phasor(allspots,roixy,theta_global,params);
    thetastore_local = zeros(numparams,Ncfg_total,max_local_iterations);
    meritstore = zeros(Ncfg_total,max_local_iterations);
    alambda_local = ones(Ncfg_total,1)*params.alambda0_local;
    alambdastore_local = zeros(Ncfg_total,params.max_local_iterations);
    Niters = zeros(Ncfg_total,1);
    flip_z_net = false;
    iiter_total = 1;
    
    [theta_local,thetastore_local,localizations,localizations_with_outliers,meritstore,alambda_local,mu,dmudtheta,Niters,outliers] = ...
    local_update(theta_local,thetastore_local,theta_global,meritstore,alambda_local,allspots,roixy,iiter_total,Niters,flip_z_net,framelist,ID,params);
    
    theta.local = theta_local;
    theta.global = theta_global;
    
    [~,filename,~] = fileparts(all_input_files(file_i).name); 
    path_output_data_full = strcat(path_output_data,filename,'.mat');
    save(path_output_data_full,'theta','thetastore_local','roixy','mu','allspots','Niters','outliers','params','-v7.3')
    fprintf('Fitting of %i beads finished\n',Ncfg_total);


end

%% Plot results
%clear all
%path_output_data = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Hertenlab\data_analysis\beads\results\results_all_*';
%path_output_data = '/home/idroste/Desktop/TUDelft/Data/Hertenlab/data_analysis/beads/results/results_all_647_beads_10nmSteps_avg_Pos2_647_100_0.mat';
%path_output_data = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Yutong_Nanorulers\data_analysis\beads\Cali1116_100bd_Oil100x1-5_Col200_647P100\results_*';
%path_output_data = 'C:\Users\idroste\Desktop\TUDelft\Data\NAT_data\Yutong_nanorulers\data_analysis\CMOS\beads\results\div_5_error\results_*';
path_output_data = 'U:\NATaberrations\ExperimentalData\Lidke\data_analysis\DATA1\beads\Without_Astigmatism\results_*';
%path_output_data = '/home/idroste/Desktop/TUDelft/Data/Lidke/data_analysis/DATA1/beads/Without_Astigmatism/results_*';
%path_output_data = '/home/idroste/Desktop/TUDelft/Data/Lidke/data_analysis/DATA1/beads/With_Astigmatism/results_*';
%path_output_data = '/home/idroste/Desktop/TUDelft/Data/yutong_nanorulers/data_analysis/CMOS/beads/results_*';
%path_output_data = '/home/idroste/Desktop/TUDelft/Data/Shechtman/data_analysis/beads/results_stk_0*';
%path_output_data = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Yutong_Nanorulers\data_analysis\CMOS\beads\thr_100\results_*';
%path_output_data = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Yutong_Nanorulers\data_analysis\KinetixCMOS\beads\results\results_*';
%path_output_data = '/home/idroste/Desktop/TUDelft/Data/yutong_nanorulers/data_analysis/CMOS/beads/results_*';
%path_output_data = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Hertenlab\data_analysis\beads\result_tilt\result_*';
%path_output_data = '/home/idroste/Desktop/TUDelft/Data/Hertenlab/data_analysis/beads/results/results_tilt_*';
%path_output_data = '/home/idroste/Desktop/TUDelft/Data/Lidke/data_analysis/beads/Without_Astigmatism/results_zstack_00*';

all_output_files = dir(path_output_data);
nr_of_outfiles = size(all_output_files,1);
fprintf('Found %i files\n',nr_of_outfiles);

theta_combined = [];
roixy_combined = [];
mu_combined = [];
allspots_combined = [];

%for file_i=1:nr_of_outfiles
for file_i=1:5

    filename = all_output_files(file_i).name; 
    foldername = all_output_files(file_i).folder;
    path_output_data_full = fullfile(foldername, filename);    
    
    dataout = load(path_output_data_full,'theta','roixy','mu','allspots','outliers','params');
    
    theta_temp = dataout.theta.local;
    roixy_temp = dataout.roixy;
    mu_temp = dataout.mu;
    allspots_temp = dataout.allspots;
    outliers = dataout.outliers;
    %outliers = [];
    no_outliers = setdiff(1:size(theta_temp,2),outliers);
    params = dataout.params;

    theta_combined = cat(2,theta_combined,theta_temp(:,no_outliers));
    roixy_combined = cat(2,roixy_combined,roixy_temp(:,no_outliers));
    mu_combined = cat(4,mu_combined,mu_temp(:,:,:,no_outliers));
    allspots_combined = cat(4,allspots_combined,allspots_temp(:,:,:,no_outliers));

end

%% Remove spots with large fiterror

errM = get_fiterror(mu_combined,allspots_combined,params);

%idx_err = find(errM(1,:)>335 | errM(3,:)>1e6 |...
%    (theta_combined(4,:) < 6e5 & roixy_combined(1,:)>512 & roixy_combined(2,:)>512 & roixy_combined(1,:)<1536 & roixy_combined(2,:)<1536 )); % Yutong
%idx_err = [128];
%idx_err = find(theta_combined(4,:)<4e5);
%idx_err = find(errM(1,:)>250 | errM(3,:)>5); % Shechtman
%idx_err = find(errM(1,:)>40 | errM(2,:)>30 | errM(3,:)>1e4); % Hertenlab
idx_err = find(errM(1,:)>50 | errM(2,:)>50 | errM(3,:)>5e4); % Lidke 2D

small_err = setdiff(1:size(roixy_combined,2),idx_err);

theta_combined = theta_combined(:,small_err);
roixy_combined = roixy_combined(:,small_err);
mu_combined = mu_combined(:,:,:,small_err);
allspots_combined = allspots_combined(:,:,:,small_err);

%Convert to mlambda
zernike_coeffs = theta_combined(6:end,:)*1e3/params.lambda;

%% Plot aberrations of all beads

figure
hold on; box on;
numzers = params.numparams-5;
plot(0:numzers+1,zeros(1,numzers+2),'-','Color',[.85 .85 .85],'LineWidth',0.5)
orders = params.aberrations(:,1:2);
allxticks = 1:numzers;
allxticklabels = cell(numzers,1);
for jzer = 1:numzers
    allxticklabels{jzer} = strcat(num2str(orders(jzer,1)),',',num2str(orders(jzer,2)));
end
plot(1:numzers,zernike_coeffs,'k-*','MarkerSize',5)
xticks(allxticks)
xtickangle(25)
xticklabels(allxticklabels)
xlim([0 numzers+1])
xlabel('zernike mode (n,m)');
ylabel('m\lambda');
title('Aberrations per bead')

% Plot mean and standard deviation
mean_aber = mean(zernike_coeffs,2);
std_aber = std(zernike_coeffs');
figure
hold on; box on;
numzers = params.numparams-5;
plot(0:numzers+1,zeros(1,numzers+2),'-','Color',[.85 .85 .85],'LineWidth',0.5)
errorbar(1:numzers,mean_aber,std_aber,'Color','black','LineWidth',1)
plot(1:numzers,mean_aber,'k-*','MarkerSize',10)
xticks(allxticks)
xtickangle(25)
xticklabels(allxticklabels)
xlim([0 numzers+1])
xlabel('zernike mode (n,m)');
ylabel('m\lambda');
title('Mean and standard deviation aberrations')

%% Crop bead aberrations

pixelsize = params.pixelsize;
xsize_crop = pixelsize*params.imgSizeX/2;
ysize_crop = pixelsize*params.imgSizeY/2;

idx_filter = find(roixy_combined(1,:)>=513 & roixy_combined(1,:)<=1536 ...
    & roixy_combined(2,:)>=513 & roixy_combined(2,:)<=1536);
roixy_crop = roixy_combined(:,idx_filter) - 512;
X = (roixy_crop(1,:)*pixelsize + theta_combined(1,idx_filter))*1e-03;
Y = (roixy_crop(2,:)*pixelsize + theta_combined(2,idx_filter))*1e-03;

[Xq,Yq] = meshgrid(1:params.imgSizeX/2*params.pixelsize*1e-3);

zernike_coeffs = theta_combined(6:end,idx_filter)*1e3/params.lambda;

%% No crop: original size

pixelsize = params.pixelsize;
xsize = pixelsize*params.imgSizeX;
ysize = pixelsize*params.imgSizeY;

[Xq,Yq] = meshgrid(1:xsize*1e-3);

zernike_coeffs = theta_combined(6:end,:)*1e3/params.lambda;%% Plot aberration surfaces

[~,FOV_coordinates] = get_fov_coordinates(roixy_combined,theta_combined(1,:),theta_combined(2,:),params);
X = FOV_coordinates(1,:);
Y = FOV_coordinates(2,:);

%%
labels = ["A(2,-2)" "A(2,2)" "A(3,-1)" "A(3,1)" "A(4,0)"];
figure
for izer = 1:size(params.aberrations,1)
    hsub = subplot(2,3,izer);
    V = zernike_coeffs(izer,:);
    Vq = griddata(X,Y,V,Xq,Yq,"cubic");

    surf(Xq,Yq,Vq,'FaceAlpha',0.7)
    shading interp
    hold on
    plot3(X,Y,V,"o",'LineWidth',3,'MarkerSize',10)
    xlabel('x (\mum)')
    ylabel('y (\mum)')
    zlabel('m\lambda')
    %zlim([-100 100])
    title(labels(izer))
    ax = gca;
    ax.FontSize = 16;

end

%% Lidke beads: file 1-5 vs file 6-9

pixelsize = params.pixelsize;
xsize = pixelsize*params.imgSizeX;
ysize = pixelsize*params.imgSizeY;

[Xq,Yq] = meshgrid(1:xsize*1e-3);

zernike_coeffs_15 = theta_combined(6:end,:)*1e3/params.lambda;%% Plot aberration surfaces
%zernike_coeffs_69 = theta_combined(6:end,:)*1e3/params.lambda;%% Plot aberration surfaces

[~,FOV_coordinates] = get_fov_coordinates(roixy_combined,theta_combined(1,:),theta_combined(2,:),params);
X_15 = FOV_coordinates(1,:);
Y_15 = FOV_coordinates(2,:);

%X_69 = FOV_coordinates(1,:);
%Y_69 = FOV_coordinates(2,:);

% sample tilt
z_15 = theta_combined(3,:);
%z_69 = theta_combined(3,:);

%%
labels = ["A(2,-2)" "A(2,2)" "A(3,-1)" "A(3,1)" "A(4,0)"];
figure
for izer = 3%1:size(params.aberrations,1)
    %hsub = subplot(2,3,izer);
    V_15 = zernike_coeffs_15(izer,:);
    Vq_15 = griddata(X_15,Y_15,V_15,Xq,Yq,"cubic");

    V_69 = zernike_coeffs_69(izer,:);
    Vq_69 = griddata(X_69,Y_69,V_69,Xq,Yq,"cubic");

    surf(Xq,Yq,Vq_15,'FaceAlpha',0.3,'EdgeColor','none','FaceColor','#00F')
    hold on
    surf(Xq,Yq,Vq_69,'FaceAlpha',0.5,'EdgeColor','none','FaceColor','#F80')

    hold on
    plot3(X_15,Y_15,V_15,"o",'LineWidth',3,'MarkerSize',12)
    hold on
    plot3(X_69,Y_69,V_69,"o",'LineWidth',3,'MarkerSize',12)
    xlabel('x (\mum)')
    ylabel('y (\mum)')
    zlabel('m\lambda')
    %zlim([-100 100])
    title(labels(izer))
    ax = gca;
    ax.FontSize = 16;

end
legend('Beads file 1-5','Beads file 6-9','Fontsize',32)
%%
% Plot sample tilt
Zq_15 = griddata(X_15,Y_15,z_15,Xq,Yq,"cubic");
Zq_69 = griddata(X_69,Y_69,z_69,Xq,Yq,"cubic");

figure
%surf(Xq,Yq,Zq_15,'FaceAlpha',0.2,'EdgeColor','none','FaceColor','#00F');
%hold on
%surf(Xq,Yq,Zq_69,'FaceAlpha',0.4,'EdgeColor','none','FaceColor','#F80');
%hold on
plot3(X_15,Y_15,z_15,"o",'LineWidth',2);
hold on
plot3(X_69,Y_69,z_69,"o",'LineWidth',2);
xlabel('x (\mum)')
ylabel('y (\mum)')
zlabel('z (nm)')
title('Sample tilt')
legend('Beads file 1-5','beads file 6-9')
ax = gca;
ax.FontSize = 32;

%% Plot z-dependent tilt coefficients
tilt = theta_combined(6:7,:);

labels = ["\alpha_x" "\alpha_y"];
figure
for izer = 1:size(tilt,1)
    hsub = subplot(1,2,izer);
    V = tilt(izer,:);
    Vq = griddata(X,Y,V,Xq,Yq,"cubic");

    surf(Xq,Yq,Vq,'FaceAlpha',0.6)
    shading interp
    hold on
    plot3(X,Y,V,"o",'LineWidth',1.5,'MarkerSize',4)
    xlabel('x (\mum)')
    ylabel('y (\mum)')
    zlabel('m\lambda')
    zlim([-0.18 0.18])
    title(labels(izer))
    ax = gca;
    ax.FontSize = 16;

end


%% Compare beads and single molecule aberrations

% fitted aberration data
%path_aber = '/home/idroste/Desktop/TUDelft/Data/Hertenlab/data_analysis/LSEC/fitted_aberrations/fitted_aberrations/rand_init_fixedcpp_004/006_fitted_aberrations_segmentation_roi17_thr100_JE_LSEC_100nm-Sections_MMStack_13.ome.mat';
%path_aber = 'N:\tnw\IST\QI\users\idroste\Data\beads_example_for_yutong\Nanoruler\Output\Nanorulers\fitted_aberrations\result_ROI7.mat';
%path_aber = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Yutong_Nanorulers\data_analysis\nanorulers\fitted_aberrations\fitted_aberrations_ROI7_NR80R_1114_Oil100x1-5_Col200_647P200-100_80ms_EM100_10000f_FL001_stk_2_007.mat1_';
%path_aber = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Yutong_Nanorulers\data_analysis\nanorulers\fitted_aberrations\fitted_aberrations_ROI7_NR80R_1114_Oil100x1-5_Col200_647P200-100_80ms_EM100_10000f_FL001_stk_1_coma_1_.mat';
%path_aber = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Yutong_Nanorulers\data_analysis\nanorulers\fitted_aberrations\fitted_aberrations_ROI7_NR80R_1114_Oil100x1-5_Col200_647P200-100_80ms_EM100_10000f_FL001_stk_1_coma_0011_.mat';
%path_aber = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Yutong_Nanorulers\data_analysis\CMOS\nanorulers\fitted_aberrations\003_fitted_aberrations_segmentation_1024_thr25_ROI17_NR80R_1201_Oil100x_Col175_647P300-100_100ms_10000f_FL_Pos1.mat';
%path_aber = 'U:\NATaberrations\ExperimentalData\Lidke\data_analysis\DATA1\Data_w_Astigmatism\fitted_aberrations\001_fitted_aberrations_segmentation_thr30_Data0002.mat';
%path_aber = 'U:\NATaberrations\ExperimentalData\Lidke\data_analysis\DATA1\Data_wo_Astigmatism\fitted_aberrations\rand_init_samespots\002_fitted_aberrations_segmentation_thr60_Data0001.mat';
%path_aber = '/home/idroste/Desktop/TUDelft/Data/Lidke/data_analysis/DATA1/Data_wo_Astigmatism/fitted_aberrations/rand_init_cppbugfixed_xyz/002_fitted_aberrations_segmentation_thr60_Data0001.mat';
%path_aber = '/home/idroste/Desktop/TUDelft/Data/Lidke/data_analysis/DATA1/Data_w_Astigmatism/fitted_aberrations/gamma6_100/007_fitted_aberrations_segmentation_thr30_Data0010.mat';
%path_aber = '/home/idroste/Desktop/TUDelft/Data/yutong_nanorulers/data_analysis/CMOS/nanorulers/fitted_aberrations/rand_init_notilt_002/009_fitted_aberrations_segmentation_1024_thr25_ROI17_NR80R_1201_Oil100x_Col175_647P300-100_100ms_10000f_FL_Pos1.mat';
%path_aber = '/home/idroste/Desktop/TUDelft/Data/Shechtman/data_analysis/fitted_aberrations/001_fitted_aberrations_segmentation_thr40_roi17_mb2_1.mat';
%path_aber = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Yutong_Nanorulers\data_analysis\CMOS\nanorulers\fitted_aberrations\rand_init_notilt_002\006_fitted_aberrations_segmentation_1024_thr25_ROI17_NR80R_1201_Oil100x_Col175_647P300-100_100ms_10000f_FL_Pos1.mat';
%path_aber = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Hertenlab\data_analysis\LSEC\fitted_aberrations\rand_init_fixedcpp_004\009_fitted_aberrations_segmentation_roi17_thr100_JE_LSEC_100nm-Sections_MMStack_13.ome';
%path_aber = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Yutong_Nanorulers\data_analysis\CMOS\nanorulers\fitted_aberrations\rand_init_2048\010_fitted_aberrations_segmentation_2048_thr10_ROI17_NR80R_1201_Oil100x_Col175_647P300-100_100ms_10000f_FL_Pos1.mat';
path_aber = 'U:\NATaberrations\ExperimentalData\Lidke\data_analysis\DATA1\Data_wo_Astigmatism\fitted_aberrations\archive\rand_init_cppbugfixed\highest_likelihood_solution\009_fitted_aberrations_segmentation_thr60_Data0001.mat';

aber_data = load(path_aber);

theta_global = aber_data.theta_full.global;
%theta_global = theta_global.*[-1,-1,-1,-1,-1,-1,-1,-1,-1,1,1,1,-1]';
params_aber = aber_data.params;
theta_global_init = aber_data.thetainit.global;
% theta_global_init = zeros(13,1);
% % 
% theta_global_init(1) = 25;
% theta_global_init(3) = -params_aber.pixelsize*params_aber.imgSizeY*tan(0.5*pi/180)/(2*sqrt(5)); %0.5 degree tilt
% % theta_global_init(5) = 0;
% theta_global_init(6) = 5;
% theta_global_init(7) = 5;
% theta_global_init(9) = 50;
%theta_global_init(11) = 5;
%theta_global_init(12) = -18;
% theta_global_init(13) = -1;

%theta_global_init = [0 0 0 0 -2 4 0 0 2 0 -3 -18 13]; Lidke 2D
%theta_global_init = [-380 0 -170 0 0 0 0 0 -5 5 0 -40 -10];
%theta_global_init = [0 0 0 0 80 100 -5 9 18 14 -17 -15 19]; % Sh%echtman
%theta_global_init = [0 0 0 0 0 0 0 0 -5 5 0 -40 -10]; % Hertenlab
%theta_global_init(1) = -380;
% theta_global_init(2) = 0;
%theta_global_init(3) = -170;
% theta_global_init(4) = 0;
% theta_global_init(5) = 0;
% theta_global_init(6) = 0;
% theta_global_init(7) = 0;
% theta_global_init(8) = 0;
% theta_global_init(9) = -5;
% theta_global_init(10) = 5;
% theta_global_init(11) = 0;
% theta_global_init(12) = -40;
% theta_global_init(13) = -10;

%theta_global_init = zeros(13,1);
% theta_global_init = [-50 0 ...
%     params.pixelsize*params.imgSizeY/2*tan(0.5*pi/180)/(2*sqrt(5))...
%     0 0 10 0 0 -14 0 -15 -15 -20];

x_aber = linspace(-1,1,50);
y_aber = linspace(-1,1,50);
[X_aber,Y_aber] = meshgrid(x_aber,y_aber);

zernikeSurfaces_fitted = get_zernike_coefficients(X_aber,Y_aber,theta_global,params_aber);
zernikeSurfaces_fitted_normalized = 1e3*zernikeSurfaces_fitted/params_aber.lambda;

zernikeSurfaces_init_normalized = 1e3*get_zernike_coefficients(X_aber,Y_aber,theta_global_init,params_aber)/params_aber.lambda;

jzer = [1 0 2 3 4 5];

[Xim,Yim] = normalized_to_physical_fov_coordinates(X_aber,Y_aber,params_aber);

% bead data
%[Xq,Yq] = meshgrid(1:params.imgSizeX*params.pixelsize*1e-3);
%[~,FOV_coordinates] = get_fov_coordinates(roixy_combined,theta_combined(1,:),theta_combined(2,:),params);
%X = FOV_coordinates(1,:);
%Y = FOV_coordinates(2,:);

labels = ["A(2,-2)" "A(2,0)" "A(2,2)" "A(3,-1)" "A(3,1)" "A(4,0)"];
%labels = ["A(2,-2)" "A(2,2)" "A(3,-1)" "A(3,1)" "A(4,0)"];
figure
for izer = [1 2 3 4 5 6]%1:size(params_aber.aberrations,1)
    
    
    % if izer==3
    %     iplot = izer-1;
    % else
    %     iplot = izer;
    % end
    iplot = izer;
    hsub = subplot(2,3,iplot);

    zs = surf(Xim,Yim,zernikeSurfaces_fitted_normalized(:,:,izer),'FaceAlpha',0.5,'FaceColor','#F80');
    shading interp
    hold on
    zs_2 = surf(Xim,Yim,zernikeSurfaces_init_normalized(:,:,izer),'EdgeColor','none','FaceAlpha',0.3,'FaceColor','#00F');
    hold on

    if izer~=2
        V = zernike_coeffs(jzer(izer),:);
        Vq = griddata(X,Y,V,Xq,Yq,"cubic");
        surf(Xq,Yq,Vq,'FaceAlpha',0.7)
        shading interp
        hold on
        plot3(X,Y,V,"o",'LineWidth',1.5,'MarkerSize',3)
        
    %else
        % %X = roixy_combined(1,:)*params.pixelsize*1e-3;
        % %Y = roixy_combined(2,:)*params.pixelsize*1e-3;
        % Zq = griddata(X,Y,theta_combined(3,:)*1e3/params.lambda,Xq,Yq,"cubic");
        % 
        % int_surf = surf(Xq,Yq,Zq,'FaceAlpha',0.7);
        % shading interp
        % hold on
        % beads = plot3(X,Y,theta_combined(3,:)*1e3/params.lambda,"o",'LineWidth',2);
        % xlabel('x (\mum)')
        % ylabel('y (\mum)')
        % zlabel('z (nm)')
    end

    %set(zs,'Facecolor','#F80');
    set(zs_2,'Facecolor','#00F');

    xlabel('x (\mum)')
    ylabel('y (\mum)')
    zlabel('m\lambda')
    % if izer <=3
    %     zlim([0 200])
    % else
    %     zlim([-60 60])
    % end
    zlim([-180 50])
    title(labels(izer))
    ax = gca;
    ax.FontSize = 16;

    %end
end
legend('Aberrations from single molecules','Interpolated surfaces beads','Bead aberrations','Initial values','Location','east','Fontsize',16)
%legend('Aberrations from single molecules','Bead aberrations','Bead aberrations','Initial values','Location','east','Fontsize',18)


%% Plot sample tilt
[Xq,Yq] = meshgrid(1:params.imgSizeX*params.pixelsize*1e-3);
X = roixy_combined(1,:)*params.pixelsize*1e-3;
Y = roixy_combined(2,:)*params.pixelsize*1e-3;
Zq = griddata(X,Y,theta_combined(3,:),Xq,Yq,"cubic");

figure
int_surf = surf(Xq,Yq,Zq,'FaceAlpha',0.5);
shading interp
hold on
beads = plot3(X,Y,theta_combined(3,:),"o",'LineWidth',2);
xlabel('x (\mum)')
ylabel('y (\mum)')
zlabel('z (nm)')
title('Sample tilt')
legend('Interpolated surface','bead z-value')
ax = gca;
ax.FontSize = 16;

%% Plot photon count across FOV
[Xq,Yq] = meshgrid(1:10:params.imgSizeX);
X = roixy_combined(1,:);
Y = roixy_combined(2,:);
Zq = griddata(X,Y,theta_combined(4,:),Xq,Yq,"cubic");

figure
int_surf = surf(Xq,Yq,Zq,'FaceAlpha',0.5);
shading interp
hold on
beads = plot3(X,Y,theta_combined(4,:),"o",'LineWidth',2);
axis square
xlabel('x (\mum)')
ylabel('y (\mum)')
zlabel('Photon count')
title('Photon count')
legend('Interpolated surface','bead z-value')
ax = gca;
ax.FontSize = 16;
%%
small_nph = find(theta_combined(4,:) < 5e4)

%% Show individual bead + fitting
%jcfg = find(roixy_combined(1,:)==56 | roixy_combined(2,:)==1062) 
%jcfg = find(roixy_combined(1,:)==1127 | roixy_combined(2,:)==81) 
jcfg = 27; %3,4,7,10
roixy_combined(:,jcfg)
theta_combined(4,jcfg)
dipshow(cat(2,allspots_combined(:,:,:,jcfg),mu_combined(:,:,:,jcfg)),'lin')
diptruesize(1000)
colormap parula

%% Show individual bead + fitting
jcfg = 1;
roixy(:,jcfg)
theta_local(4,jcfg)
dipshow(cat(2,allspots(:,:,:,jcfg),mu(:,:,:,jcfg)),'lin')
diptruesize(2000)
colormap parula

%% Show bead location in FOV
figure
scatter(roixy_combined(2,:),roixy_combined(1,:),"o",'LineWidth',1.5)
xlabel('y (\mum)')
ylabel('x (\mum)')
axis square
%xlim([0 params.pixelsize*params.imgSizeX/1e3])
%ylim([0 params.pixelsize*params.imgSizeY/1e3])
ax = gca;
ax.FontSize = 16;

%%
figure
scatter(X,Y,"o",'LineWidth',1.5)
xlabel('x (\mum)')
ylabel('y (\mum)')
axis square
xlim([0 params.pixelsize*params.imgSizeX/1e3])
ylim([0 params.pixelsize*params.imgSizeY/1e3])
ax = gca;
ax.FontSize = 16;

%% End parallel pool
if params.delete_parpool
    delete(gcp('nocreate'));
end

%% Bar plot likelihoods different random intial gammas

%path = 'U:\NATaberrations\ExperimentalData\Lidke\data_analysis\DATA1\Data_wo_Astigmatism\fitted_aberrations\rand_init_samespots\0*';
%path = '/home/idroste/Desktop/TUDelft/Data/yutong_nanorulers/data_analysis/CMOS/nanorulers/fitted_aberrations/rand_init_notilt_002/0*';
%path = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Yutong_Nanorulers\data_analysis\CMOS\nanorulers\fitted_aberrations\rand_init_notilt_002\0*';
%path = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Yutong_Nanorulers\data_analysis\CMOS\nanorulers\fitted_aberrations\rand_init_2048\0*';
path = '/home/idroste/Desktop/TUDelft/Data/Lidke/data_analysis/DATA1/Data_wo_Astigmatism/fitted_aberrations/rand_init_cppbugfixed_xyz/0*';

all_solutions = dir(path);

merit_all = zeros(size(all_solutions,1),1);
merit_all_corrected = zeros(size(all_solutions,1),1);
merit_all_outliers = zeros(size(all_solutions,1),1);
merit_all_no_outliers = zeros(size(all_solutions,1),1);
nr_of_no_outliers = zeros(size(all_solutions,1),1);

for i=1:size(all_solutions,1)
    i
    path_full = fullfile(all_solutions(i).folder,all_solutions(i).name);
    load(path_full)
    outliers = outliers_full{1}';
    no_outliers = setdiff(1:params.Ncfg,outliers);
    nr_of_no_outliers(i) = numel(no_outliers);    

    for jcfg = 1:params.Ncfg
        merit_all(i) = merit_all(i) + likelihood(params,allspots(:,:,:,jcfg),mu_full(:,:,:,jcfg),dmudtheta_full.local(:,:,:,:,jcfg),params.varfit);
    end

    meritoffset = meritoffsetcalc(allspots,params.varfit);
    merit_all_corrected(i) = merit_all(i) + sum(meritoffset);

    for jcfg = 1:params.Ncfg
        merit_all(i) = merit_all(i) + likelihood(params,allspots(:,:,:,jcfg),mu_full(:,:,:,jcfg),dmudtheta_full.local(:,:,:,:,jcfg),params.varfit);
    end

    % for jcfg = outliers
    %     merit_all_outliers(i) = merit_all_outliers(i) + likelihood(params,allspots(:,:,:,jcfg),mu_full(:,:,:,jcfg),dmudtheta_full.local(:,:,:,:,jcfg),params.varfit);
    % end
    % 
    % for jcfg = no_outliers
    %     merit_all_no_outliers(i) = merit_all_no_outliers(i) + likelihood(params,allspots(:,:,:,jcfg),mu_full(:,:,:,jcfg),dmudtheta_full.local(:,:,:,:,jcfg),params.varfit);
    % end
    % 
    merit_all(i) = merit_all(i)/params.Ncfg;
    % merit_all_outliers(i) = merit_all_outliers(i)/numel(outliers);
    % merit_all_no_outliers(i) = merit_all_no_outliers(i)/numel(no_outliers);
end



%% Precalculated merit

%path = '/home/idroste/Desktop/TUDelft/Data/Lidke/data_analysis/DATA1/Data_wo_Astigmatism/fitted_aberrations/rand_init_cppbugfixed_xyz/0*';
%path = '/home/idroste/Desktop/TUDelft/Data/Lidke/data_analysis/DATA1/Data_w_Astigmatism/fitted_aberrations/gamma6_100/0*';
%path = '/home/idroste/Desktop/TUDelft/Data/Hertenlab/data_analysis/LSEC/fitted_aberrations/rand_init_fixedcpp_004/0*';
%path = '/home/idroste/Desktop/TUDelft/Data/yutong_nanorulers/data_analysis/CMOS/nanorulers/fitted_aberrations/rand_init_2048/0*';
%path = 'U:\SMLMaberrations\NATaberrations\ExperimentalData\Yutong_Nanorulers\data_analysis\CMOS\nanorulers\fitted_aberrations\rand_init_2048\0*';
%path = '/home/idroste/Desktop/TUDelft/Data/Hertenlab/data_analysis/LSEC/fitted_aberrations/fitted_aberrations/rand_init_fixedcpp_004/0*';
%path = '/home/idroste/Desktop/TUDelft/Data/yutong_nanorulers/data_analysis/CMOS/nanorulers/fitted_aberrations/rand_init_notilt_002/0*';
%path = '/home/idroste/Desktop/TUDelft/Data/Jungmann/data_analysis/fitted_aberrations/0*';
%path = '/home/idroste/Desktop/TUDelft/Data/Fu_fig4/data_analysis/fitted_aberrations/0*';
path = 'U:\NATaberrations\ExperimentalData\Lidke\data_analysis\DATA1\Data_wo_Astigmatism\fitted_aberrations\roi17\fitted_aberrations_*';

all_solutions = dir(path);


merit_all = zeros(size(all_solutions,1),1);
merit_all_outliers = zeros(size(all_solutions,1),1);
merit_all_no_outliers = zeros(size(all_solutions,1),1);
nr_of_no_outliers = zeros(size(all_solutions,1),1);

system_aberration_error = zeros(size(all_solutions,1),1);
theta_global_beads = [0 0 0 0 -2 4 0 0 2 0 -3 -18 13]'; %Lidke 2D
%theta_global_beads = [-65 ...
%    params.pixelsize*params.imgSizeY/2*tan(0.5*pi/180)/(2*sqrt(5)) 0 ...
%     0 0 10 0 0 -14 0 -15 -15 -20]'; %Yutong CMOS beads

for i=1:size(all_solutions,1)
    i
    path_full = fullfile(all_solutions(i).folder,all_solutions(i).name)
    load(path_full)
    outliers = outliers_full{1}';
    no_outliers = setdiff(1:params.Ncfg,outliers);
    nr_of_no_outliers(i) = numel(no_outliers);
    
    merit_all(i) = sum(meritstore_full.local(:,end))/params.Ncfg;
    merit_all_outliers(i) = sum(meritstore_full.local(outliers,end))/numel(outliers);
    merit_all_no_outliers(i) = sum(meritstore_full.local(no_outliers,end))/numel(no_outliers);

    theta_global_temp = theta_full.global;
    theta_global_diff_1 = theta_global_beads - theta_global_temp;
    theta_global_diff_2 = theta_global_beads - theta_global_temp.*[-1,-1,-1,-1,-1,-1,-1,-1,-1,1,1,1,-1]';
    sav_1 = get_system_aberration_value(theta_global_diff_1,params);
    sav_2 = get_system_aberration_value(theta_global_diff_2,params);
    system_aberration_error(i) = min(sav_1,sav_2);
    %theta_global_temp(13)
end

%%
theta_global = [0 0 0 0 0 0 0 0 -5 5 0 -40 -10]';
get_system_aberration_value(theta_global,params_aber)

%%
figure
x = merit_all;
b = bar(x);
%b = bar(nr_of_no_outliers);
%b = bar(cat(2,merit_all_no_outliers,merit_all_outliers),'stacked');
b.FaceColor = 'flat';

% rand_init_samespots
% % green = correct solution
% b.CData(2,:) = [0.4660 0.6740 0.1880];
% b.CData(5,:) = [0.4660 0.6740 0.1880];
% b.CData(6,:) = [0.4660 0.6740 0.1880];
% b.CData(7,:) = [0.4660 0.6740 0.1880];
% b.CData(8,:) = [0.4660 0.6740 0.1880];
% b.CData(9,:) = [0.4660 0.6740 0.1880];
% 
% % red = wrong solution
% b.CData(1,:) = [0.8500 0.3250 0.0980];
% b.CData(3,:) = [0.8500 0.3250 0.0980];
% b.CData(4,:) = [0.8500 0.3250 0.0980];
% b.CData(10,:) = [0.8500 0.3250 0.0980];

% rand_init_samespots_fixed_merit
% green = correct solution
% correctsol = [2 4 7 9 10];
% for i=correctsol
%     i
%     b.CData(i,:) = [0.4660 0.6740 0.1880];
% end
% 
% % red = wrong solution
% wrongsol = setdiff(1:10,correctsol);
% for j=wrongsol
%     b.CData(j,:) = [0.8500 0.3250 0.0980];
% end

ylim([min(x)-0.1*(max(x) - min(x)) max(x)+0.1*(max(x) - min(x))])

xlabel('solution nr')
ylabel('likelihood')

[M,I] = max(x)

%%
figure
x = system_aberration_error;
b = bar(x);
b.FaceColor = 'flat';

% green = correct solution
% correctsol = [2 4 7 9 10];
% for i=correctsol
%     b.CData(i,:) = [0.4660 0.6740 0.1880];
% end
% 
% % % red = wrong solution
% wrongsol = setdiff(1:10,correctsol);
% for j=wrongsol
%     b.CData(j,:) = [0.8500 0.3250 0.0980];
% end

ylim([min(x)-0.1*(max(x) - min(x)) max(x)+0.1*(max(x) - min(x))])

xlabel('solution nr')
ylabel('system aberration error (m\lambda)')

%%
figure
b = bar(nr_of_no_outliers);
ylim([4800 4950])