#pragma once
#include <memory>

#include "array/cuda_array.h"
#include "compute_gpu/czt_plan.cuh"
#include "estimator/cpu_estimator.h"
#include "estimator/interface.h"
#include "cuda/stream.cuh"

class CudaBaseEstimator: public BaseEstimator {
public:
	std::unique_ptr<Estimator> cpu_estimator;
	const FitParams fitParams;
	const int device;
	CudaAllocator allocator;

	CudaBaseEstimator(Estimator estimator, int device);

	virtual void CalculatePsf(
			CudaView1D<index_t> activeCfg,
			CudaView2D<double> Theta,
			CudaWriteView4D<double> Psf,
			CudaWriteView5D<double> PsfDer) = 0;

	void PoissonRate(
			CudaView1D<index_t> activeCfg,
			CudaView2D<double> Theta,
			CudaWriteView4D<double> Mu,
			CudaWriteView5D<double> dMudTheta);

	void Likelihood(
			CudaView1D<index_t>  activeCfg,
			CudaView4D<double> AllSpots,
			CudaView4D<double> AllMu,
			CudaView5D<double> Alldmudtheta,
			CudaWriteView1D<double> Allmerit,
			CudaWriteView2D<double> Allgrad,
			CudaWriteView3D<double> AllHessian);

	void PsfToMu(
			CudaView1D<index_t> activeCfg,
			CudaView2D<double> Theta,
			CudaView4D<double> Psf,
			CudaView5D<double> PsfDer,
			CudaWriteView4D<double> mu,
			CudaWriteView5D<double> dmudtheta);

	void InitializeSpots(
			View4D<double> Spots,
			WriteView2D<double> ThetaInit) override;

	void InitializeSpotsPhasor(
			View4D<double> Spots,
			WriteView2D<double> ThetaInit);

	void LocalizeSpots(
			View4D<double> AllSpots,
			View2D<double> ThetaInit,
			WriteView3D<double> ThetaStore,
			WriteView4D<double> mu,
			WriteView5D<double> dmudtheta,
			WriteView2D<double> Merit,
			WriteView1D<int> NumIters,
			WriteView1D<bool> IsConverged) override;
};

class CudaEstimator: public CudaBaseEstimator {
	CudaArr3D<cdouble> AllZernikesNormalized;
	CudaArr3D<cdouble> WaveVector;
	CudaArr2D<cdouble> WaveVectorZImm;
	CudaArr2D<cdouble> cosThetaImm;
	CudaArr2D<cdouble> cosThetaImmnom;
	CudaArr2D<cdouble> cosThetaMed;
	CudaArr2D<double> ApertureMask;
	CudaArr4D<cdouble> PolarizationVector;
	CudaArr2D<cdouble> Amplitude;
	CudaArr5D<cdouble> PupilMatrix_;

	CudaCztPlan czt_plan;
	std::vector<CudaStream> streams;

public:
	CudaEstimator(Estimator estimator, int device = 0, bool low_accuracy = false);

	void CalculatePsf(
			CudaView1D<index_t> activeCfg,
			CudaView2D<double> Theta,
			CudaWriteView4D<double> Psf,
			CudaWriteView5D<double> PsfDer) override;

	void GetFieldMatrixDerivatives(
			CudaView1D<index_t> activeCfg,
			CudaView2D<double> Theta,
			CudaView5D<cdouble> PupilMatrix,
			CudaWriteView6D<cdouble> FieldMatrix,
			CudaWriteView7D<cdouble> FieldMatrixDer,
			bool fit_aberrations);

	void GetPsfDerivatives(
			CudaView1D<index_t> activeCfg,
			CudaView2D<double> Theta,
			CudaView5D<cdouble> PupilMatrix,
			CudaView6D<cdouble> FieldMatrix,
			CudaView7D<cdouble> FieldMatrixDer,
			CudaWriteView4D<double> Psf,
			CudaWriteView5D<double> PsfDer);

	CudaView5D<cdouble> GetPupilMatrix(
			CudaView1D<index_t> activeCfg,
			CudaView2D<double> Theta);
};

class CudaOTFEstimator: public CudaBaseEstimator {
	CudaArr4D<cdouble> otfs;
	CudaArr1D<int> spot_otf_indices;
	CudaCztPlan czt_otf_to_psf_plan;

public:
	CudaOTFEstimator(Estimator estimator, int device = 0, bool low_accuracy = false);

	void CalculatePsf(
		CudaView1D<index_t> activeCfg,
		CudaView2D<double> Theta,
		CudaWriteView4D<double> Psf,
		CudaWriteView5D<double> PsfDer) override;

	void SetOTFs(View4D<std::complex<double>> OTFs, View1D<int> SpotOTFIndices) override;
};
