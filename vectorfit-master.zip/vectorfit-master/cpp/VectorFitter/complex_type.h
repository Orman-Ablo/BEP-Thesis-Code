#pragma once
#include "cuda/macros.cuh"

#if !CUDA_RTC
#include <complex>
#endif

template <typename T>
struct complex_type_storage;

template <>
struct alignas(2 * sizeof(double)) complex_type_storage<double> {
	double x;
	double y;
};

template <>
struct alignas(2 * sizeof(float)) complex_type_storage<float> {
	float x;
	float y;
};

template <typename T>
struct complex_type: complex_type_storage<T> {
	using storage_type = complex_type_storage<T>;
	using self_type = complex_type<T>;

	constexpr complex_type() = default;

	template <typename S>
	CUDA_HOST_DEVICE
	explicit constexpr complex_type(complex_type<S> that): storage_type {T(that.real()), T(that.imag())} {}

	CUDA_HOST_DEVICE
	constexpr complex_type(T real, T imag): storage_type {real, imag} {};

	CUDA_HOST_DEVICE
	constexpr complex_type(T real): complex_type(real, T{}) {};

#if !CUDA_RTC
//	CUDA_HOST_DEVICE
	constexpr complex_type(std::complex<T> that): complex_type(that.real(), that.imag()) {}

	//CUDA_HOST_DEVICE
	operator std::complex<T>() const {
		return std::complex<T> {real(), imag()};
	}
#endif

	CUDA_HOST_DEVICE
	T real() const {
		return this->x;
	}

	CUDA_HOST_DEVICE
	T imag() const {
		return this->y;
	}

	CUDA_HOST_DEVICE
	T norm() const {
		return real() * real() + imag() * imag();
	}

	CUDA_HOST_DEVICE
	complex_type<T> conj() const {
		return {real(), -imag()};
	}

	CUDA_HOST_DEVICE
	self_type& operator+=(complex_type<T> rhs) {
		return (*this = *this + rhs);
	}

	CUDA_HOST_DEVICE
	self_type& operator-=(complex_type<T> rhs) {
		return (*this = *this - rhs);
	}

	CUDA_HOST_DEVICE
	self_type& operator*=(complex_type<T> rhs) {
		return (*this = *this * rhs);
	}

	CUDA_HOST_DEVICE
	self_type& operator/=(complex_type<T> rhs) {
		return (*this = *this / rhs);
	}

	CUDA_HOST_DEVICE
	self_type& operator+=(T rhs) {
		return (*this = *this + rhs);
	}

	CUDA_HOST_DEVICE
	self_type& operator-=(T rhs) {
		return (*this = *this - rhs);
	}

	CUDA_HOST_DEVICE
	self_type& operator*=(T rhs) {
		return (*this = *this * rhs);
	}

	CUDA_HOST_DEVICE
	self_type& operator/=(T rhs) {
		return (*this = *this / rhs);
	}
};

using cdouble = complex_type<double>;
using cfloat = complex_type<float>;

#if !CUDA_RTC
template <> struct is_copy_compatible<cdouble, std::complex<double>>: std::true_type {};
template <> struct is_copy_compatible<cfloat, std::complex<float>>: std::true_type {};
template <> struct is_copy_compatible<std::complex<double>, cdouble>: std::true_type {};
template <> struct is_copy_compatible<std::complex<float>, cfloat>: std::true_type {};

static_assert(alignof(cdouble) == 2 * sizeof(double), "internal error");
static_assert(sizeof(cdouble) == sizeof(std::complex<double>), "internal error");
static_assert(alignof(cfloat) == 2 * sizeof(float), "internal error");
static_assert(sizeof(cfloat) == sizeof(std::complex<float>), "internal error");
#endif


template <typename T>
CUDA_HOST_DEVICE
complex_type<T> operator+(complex_type<T> v) {
	return v;
}

template <typename T>
CUDA_HOST_DEVICE
complex_type<T> operator-(complex_type<T> v) {
	return {-v.real(), -v.imag()};
}

template <typename T>
CUDA_HOST_DEVICE
complex_type<T> operator+(complex_type<T> lhs, complex_type<T> rhs) {
	return {lhs.real() + rhs.real(), lhs.imag() + rhs.imag()};
}

template <typename T>
CUDA_HOST_DEVICE
complex_type<T> operator+(complex_type<T> lhs, T rhs) {
	return {lhs.real() + rhs, lhs.imag()};
}

template <typename T>
CUDA_HOST_DEVICE
complex_type<T> operator+(T lhs, complex_type<T> rhs) {
	return {lhs + rhs.real(), rhs.imag()};
}

template <typename T>
CUDA_HOST_DEVICE
complex_type<T> operator-(complex_type<T> lhs, complex_type<T> rhs) {
	return {lhs.real() - rhs.real(), lhs.imag() - rhs.imag()};
}

template <typename T>
CUDA_HOST_DEVICE
complex_type<T> operator-(complex_type<T> lhs, T rhs) {
	return {lhs.real() - rhs, lhs.imag()};
}

template <typename T>
CUDA_HOST_DEVICE
complex_type<T> operator-(T lhs, complex_type<T> rhs) {
	return {lhs - rhs.real(), rhs.imag()};
}

template <typename T>
CUDA_HOST_DEVICE
complex_type<T> operator*(complex_type<T> lhs, complex_type<T> rhs) {
	return {
			lhs.real() * rhs.real() - lhs.imag() * rhs.imag(),
			lhs.real() * rhs.imag() + lhs.imag() * rhs.real()
	};
}

template <typename T>
CUDA_HOST_DEVICE
complex_type<T> operator*(complex_type<T> lhs, T rhs) {
	return {lhs.real() * rhs, lhs.imag() * rhs};
}

template <typename T>
CUDA_HOST_DEVICE
complex_type<T> operator*(T lhs, complex_type<T> rhs) {
	return {lhs * rhs.real(), lhs * rhs.imag()};
}

template <typename T>
CUDA_HOST_DEVICE
complex_type<T> operator/(complex_type<T> lhs, complex_type<T> rhs) {
	T normi = 1 / rhs.norm();

	return {
			(lhs.real() * rhs.real() + lhs.imag() * rhs.imag()) * normi,
			(lhs.imag() * rhs.real() - lhs.real() * rhs.imag()) * normi
	};
}

template <typename T>
CUDA_HOST_DEVICE
complex_type<T> operator/(complex_type<T> lhs, T rhs) {
	return {lhs.real() / rhs, lhs.imag() / rhs};
}

template <typename T>
CUDA_HOST_DEVICE
complex_type<T> operator/(T lhs, complex_type<T> rhs) {
	T normi = 1 / rhs.norm();

	return {lhs * rhs.real() * normi, -lhs * rhs.imag() * normi};
}

#if !CUDA_RTC
DEBUG_DEVICE_HELPER_IMPL(complex_type<double>, "(%f, %f)", value.real(), value.imag());
DEBUG_DEVICE_HELPER_IMPL(complex_type<float>, "(%f, %f)", value.real(), value.imag());
#endif

namespace std {
	template <typename T>
	CUDA_HOST_DEVICE
	constexpr T real(complex_type<T> v) {
		return v.real();
	}

	template <typename T>
	CUDA_HOST_DEVICE
	constexpr T imag(complex_type<T> v) {
		return v.imag();
	}

	template <typename T>
	CUDA_HOST_DEVICE
	constexpr T abs(complex_type<T> v) {
		return std::hypot(std::real(v), std::imag(v));
	}

	template <typename T>
	CUDA_HOST_DEVICE
	constexpr T arg(complex_type<T> v) {
		return std::atan2(std::imag(v), std::real(v));
	}

	template <typename T>
	CUDA_HOST_DEVICE
	constexpr complex_type<T> sqrt(complex_type<T> v) {
		double radius = abs(v);
		double cosA = v.real() / radius;
		complex_type<T> out = {
				sqrt(radius * (cosA + 1.0) / 2.0),
				sqrt(radius * (1.0 - cosA) / 2.0)
		};

		// signbit should be false if x.y is negative
		if (v.imag() < 0) {
			out.y *= -1.0;
		}

		return out;
	}

	template <typename T>
	CUDA_HOST_DEVICE
	constexpr T norm(complex_type<T> v) {
		if (isinf(v.real()))
			return abs(v.real());
		if (isinf(v.imag()))
			return abs(v.imag());
		return v.real() * v.real() + v.imag() * v.imag();
	}

	template <typename T>
	CUDA_HOST_DEVICE
	constexpr complex_type<T> conj(complex_type<T> v) {
		return v.conj();
	}

	template <typename T>
	CUDA_HOST_DEVICE
	constexpr complex_type<T> exp(complex_type<T> v) {
		T i = v.imag();
		if (i == 0) {
			return complex_type<T>(exp(v.real()), std::copysign(T(0), v.imag()));
		}

		if (isinf(v.real()))
		{
			if (v.real() < T(0))
			{
				if (!isfinite(i))
					i = T(1);
			}
			else if (i == 0 || !isfinite(i))
			{
				if (isinf(i))
					i = T(NAN);
				return complex_type<T>(v.real(), i);
			}
		}

		T e = std::exp(v.real());
		return complex_type<T>(e * std::cos(i), e * std::sin(i));
	}

	template <typename T>
	CUDA_HOST_DEVICE
	constexpr complex_type<T> log(complex_type<T> v) {
		return complex_type<T>(std::log(std::abs(v)), std::arg(v));
	}

	template <typename T>
	CUDA_HOST_DEVICE
	constexpr complex_type<T> pow(complex_type<T> x, complex_type<T> y) {
		return exp(y * log(x));
	}
}
