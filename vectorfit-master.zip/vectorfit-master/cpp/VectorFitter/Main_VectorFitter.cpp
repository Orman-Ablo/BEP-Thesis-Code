
/* == Vectorial PSF fitter main program ====
* This program uses MLE algorithm and Levenberg Marquat updating algorithm 
* to estimate the following parameters.
* (x,y,z) - emitter location 
* N - photon count 
* bg - bacgroudn
* (theta, phi) - polar and azimuthal angles for orientation estimation
* g2 - orientation constraint parameter
* aberrations - (from zstack)
* 
* By Awoke Negash, a.a.negash@tudelft.nl
*/
#include <cstring>
#include <string>
#include <chrono>
#include <fstream>
#include <algorithm>
#include <iomanip>
#include <argparse/argparse.hpp>

#include "files.h"
#include "MultiDimArray.h"
#include "Parameters.h"
#include "estimator/cpu_estimator.h"
#include "estimator/parallel_estimator.h"
#include "compute/fisher.h"
//#include "highfive/H5File.hpp"

#if USECUDA
#include "estimator/gpu_estimator.h"
#endif

#if USEHDF5
//#include <highfive/H5File.hpp>

template <typename T, size_t N>
void add_hdf5_dataset(HighFive::File& f, const std::string& name, ViewND<const T, N> array) {

	// We must copy to a new array to ensure that the data is in row-major order (C order) since that is
	// the expected layout for HDF5
	if (!array.is_contiguous()) {
		ArrayND<T, N> temp = array;
		add_hdf5_dataset(f, name, temp.cview());
		return;
	}

	auto shape = array.shape();
	auto db = f.template createDataSet<T>(name, HighFive::DataSpace(shape.begin(), shape.end()));
	db.write_raw(array.data());
}

void write_output_hdf5(
		const std::string &output_file,
		View2D<double> ThetaInit,
		View2D<double> ThetaFinal,
		View4D<double> muStore,
		View2D<double> Merit,
		View1D<int> NumIters,
		View2D<double> CRLB,
		View2D<double> FitError
) {
	std::cout << "writing output to HDF5 file: " << output_file << std::endl;

	HighFive::File output(output_file, HighFive::File::Create);
	add_hdf5_dataset(output, "Mu", muStore);
	add_hdf5_dataset(output, "ThetaInit", ThetaInit);
	add_hdf5_dataset(output, "Theta", ThetaFinal);
	add_hdf5_dataset(output, "Merit", Merit);
	add_hdf5_dataset(output, "NumIters", NumIters);
	add_hdf5_dataset(output, "CRLB", CRLB);
	add_hdf5_dataset(output, "chi2", FitError.view(0, placeholder::all()));
}
#endif


void write_output_bin(
		const std::string &output_dir,
		View2D<double> ThetaInit,
		View2D<double> Thetafinal,
		View4D<double> muStore,
		View2D<double> Merit,
		View1D<int> NumIters,
		View2D<double> CRLB,
		View2D<double> FitError
) {
	std::cout << "writing output files to directory: " << output_dir << std::endl;

	// === Writing outputs to file =====================================
	writeBinaryImage(output_dir + "/cppout/initialTheta.bin", ThetaInit);
	writeBinaryImage(output_dir + "/cppout/estimatedTheta.bin", Thetafinal);
	writeBinaryImage(output_dir + "/cppout/merit.bin", Merit);
	writeBinaryImage(output_dir + "/cppout/crlb.bin", CRLB);

	int Ncfg = muStore.size(3);
	for (int mm = 0; mm < Ncfg; mm++)
	{
		std::string filename = output_dir + "/cppout/mu/mu" + std::to_string(mm + 1) + ".bin";
		writeBinaryImage(filename, muStore.view(placeholder::all(), placeholder::all(), placeholder::all(), mm));
	}

	writeBinaryImage(output_dir + "/graphdata/cppchi2.bin", FitError.view(0, placeholder::all()));
	writeBinaryImage(output_dir + "/cppout/chisquare.bin", FitError.view(0, placeholder::all()));

	Arr1D<double> NumItersDouble(Ncfg);
	for (int mm = 0; mm < Ncfg; mm++) {
		NumItersDouble[mm] = NumIters[mm];
	}
	writeBinaryImage(output_dir + "/graphdata/cppniters.bin", NumItersDouble);
}


void write_output(
		const std::string &output_dir,
		const int Ncfg,
		const FitParams& fitParam,
		View2D<double> ThetaInit,
		View4D<double> AllSpots,
		View2D<double> Thetafinal,
		WriteView4D<double> muStore,
		View5D<double> dmudThetaStore,
		View2D<double> Merit,
		View1D<int> NumIters
) {
	using placeholder::all;
	int NumParams = fitParam.FitModel.num_parameters();

	Arr1D<double> rcondStore;
	Arr2D<double> CRLB(NumParams, Ncfg);
	Arr2D<double> FitError(3, Ncfg); //chi2, LLR and SSE

	//Compute CRLB
	compute::getFisherCRLB(fitParam, muStore, dmudThetaStore, CRLB, rcondStore);

	//compute fit errors
	compute::getFitError(fitParam, muStore, AllSpots, FitError);

	if (output_dir.find(".h5") != std::string::npos) {
#if USEHDF5
		write_output_hdf5(
				output_dir,
				ThetaInit,
				Thetafinal,
				muStore,
				Merit,
				NumIters,
				CRLB,
				FitError);
#else
		throw std::runtime_error("HDF5 files are not supported. Compile with `USEHDF5=1`");
#endif
	} else {
		write_output_bin(
				output_dir,
				ThetaInit,
				Thetafinal,
				muStore,
				Merit,
				NumIters,
				CRLB,
				FitError);
	}
}


Arr4D<double> read_spots_exp(const FitParams &fitParam) {// ===read tiff files here -- not completed! =====
	int Ncfg = 1000;
	Arr4D<double> AllSpots(Ncfg, fitParam.Mx, fitParam.My, fitParam.Mz);

	char DataDir[] = " ";
	char FileRootName[] = "image_";
	char FileFormat[] = ".tiff";
	char DataPath[] = " ";

	int mx = fitParam.Mx;
	int my = fitParam.My;

	for (int ii = 0; ii < mx; ii++)
	{
		for (int jj = 0; jj < my; jj++)
		{
			for (int kk = 0; kk < fitParam.Mz; kk++)
			{
				for (int mm = 0; mm < Ncfg; mm++)
				{
					//AllSpots(mm, ii, jj, kk) = spotread(ii, jj);
					VF_PANIC("not completed!");
				}
			}
		}
	}

	return AllSpots;
}

Arr4D<double> read_spots_bead(
		const std::string& input_dir,
		const FitParams& fitParam
) {
	int Ncfg = 1000;
	Arr4D<double> AllSpots(Ncfg, fitParam.Mx, fitParam.My, fitParam.Mz);

	int mx = fitParam.Mx;
	int my = fitParam.My;
	Arr2D<double>spotread(mx, my);

	for (int kk = 0; kk < fitParam.Mz; kk++)
	{
		for (int mm = 0; mm < Ncfg; mm++)
		{
			std::string str = std::to_string(mm + 1);
			std::string filename = input_dir + "/spot" + str + ".bin";
			readBinaryImage(filename, spotread);
		}
	}

	return AllSpots;
}

Arr4D<double> read_spots_simdata(
		const std::string& input_dir,
		const FitParams &fitParam) {
	using namespace placeholder;
	//===reading simulated input images===
	std::string filename;
	int mx = fitParam.Mx;
	int my = fitParam.My;
	int mz = fitParam.Mz;
	std::vector<Arr3D<double>> spots;
	Arr3D<double>spot(mx, my, mz);

	std::cout << "reading spots from directory: " << input_dir << std::endl;

	while (true)
	{
		filename = input_dir + "/spot" + std::to_string(spots.size() + 1) + ".bin";

		if (!fileExists(filename))
		{
			break;
		}

		readBinaryImage(filename, spot);
		spots.push_back(spot);
	}

	int Ncfg = spots.size();
	if (Ncfg == 0)
	{
		throw std::runtime_error("no spots found in directory: " + input_dir);
	}

	std::cout << "total spots found: " << Ncfg << std::endl;
	Arr4D<double> AllSpots(Ncfg, fitParam.Mx, fitParam.My, fitParam.Mz);

	for (int i = 0; i < Ncfg; i++)
	{
		AllSpots.view(i, _, _, _) = spots[i];
	}

	return AllSpots;
}

Arr4D<double> read_spots_simulation(
		const std::string &input_dir,
		FitParams &fitParam) {
	int Ncfg = 1000;
	Arr4D<double> AllSpots(Ncfg, fitParam.Mx, fitParam.My, fitParam.Mz);

	const int NumParams = fitParam.FitModel.num_parameters();
	Arr4D<std::complex<double> > PupilMatrix(fitParam.NPupil, fitParam.NPupil, 2, 3);
	Arr2D<double>objectread(1, NumParams);
	Arr1D<double> object1(NumParams);
	Arr3D<double>allPSF(fitParam.Mx, fitParam.My, fitParam.Mz);
	Arr4D<double>allPSFDer(fitParam.Mx, fitParam.My, fitParam.Mz, NumParams);
	Arr2D<double>object(NumParams, Ncfg);

	Estimator Mle(fitParam);  //estimator
	std::string filename;
	int mx = fitParam.Mx;
	int my = fitParam.My;

	bool flg_nat = 0;
//	fitParam.NatPredictions.resize(Ncfg);
//	for (int mm = 0; mm < fitParam.Naberr; mm++)
//	{
//		fitParam.NatPredictions[mm].resize(fitParam.Naberr);
//		for (int nn = 0; nn < fitParam.Naberr; nn++)
//		{
//			fitParam.NatPredictions[mm][nn] = fitParam.InitialAberrations[nn][2];
//		}
//	}

	VF_ASSERT(false); // TODO

	VF_ASSERT(!fitParam.FitModel.has_aberrations());
	auto spot = SpotParameters();

	for (int jj = 0; jj < Ncfg; jj++)
	{
		// true parameters
		//double dx = (1 - 2 * rand() % 1) * fitParam.PixelSize;
		//double dy = (1 - 2 * rand() % 1) * fitParam.PixelSize;
		double dx = -35.7354;
		double dy = 51.4879;
		double dz = 0;
		int Nphotons = 4000;
		double Nbackground = 10;
		//double dazim = M_PI * rand();
		//double dpola = acos(1 - 2 * rand() % 1);
		double dazim = 0.5713;
		double dpola = 1.0788;
		double dg2 = 0.75;

		object(0, jj) = dx;
		object(1, jj) = dy;
		object(2, jj) = dz;
		object(3, jj) = Nphotons;
		object(4, jj) = Nbackground;
		object(5, jj) = dazim;
		object(6, jj) = dpola;
		object(7, jj) = dg2;

		filename = input_dir + "common/object/object" + std::to_string(jj + 1) + ".bin";
		readBinaryImage(filename, objectread);
		//readTextImage(filename, mx, my, spotread);

		for (int mm = 0; mm < NumParams; mm++)
		{
			object(mm, jj) = objectread(0, mm);
		}

	}

	for (int jj = 0; jj < Ncfg; jj++)
	{
		object1[0] = object(0, jj);
		object1[1] = object(1, jj);
		object1[2] = object(2, jj);
		object1[3] = object(3, jj);
		object1[4] = object(4, jj);
		object1[5] = object(5, jj);
		object1[6] = object(6, jj);
		object1[7] = object(7, jj);

		if (fitParam.FitModel.has_fitted_aberrations())
		{
			for (int i = 0; i < fitParam.FitModel.num_aberrations(); i++)
			{
				int ind = 8 + i;
				object1[ind] = fitParam.InitialAberrations[i][2];
			}
		}
		// generate object and PSFs
		auto spot = SpotParameters::from_theta(fitParam.FitModel, object1);
		Mle.pupil_matrix.update_aberrations(spot.AberrationCoefs);
		Mle.PoissonRate(spot, allPSF, allPSFDer);

		for (int mm = 0; mm < mx; mm++)
		{
			for (int nn = 0; nn < my; nn++)
			{
				AllSpots(jj, mm, nn, 0) = allPSF(mm, nn, 0); //kk=0
			}
		}
	}
	//addinfo = ":     End of simulating forward model! \r\n";
//writeToInfo(InfoFile, addinfo);
}

#if USEHDF5
Arr4D<double> read_spots_hdf5(
		const std::string& input_file,
		const FitParams &fitParam
) {
	std::cout << "reading spots from HDF5 file: " << input_file << std::endl;

	size_t Mx = fitParam.Mx;
	size_t My = fitParam.My;
	size_t Mz = fitParam.Mz;

	HighFive::File file(input_file, HighFive::File::ReadOnly);
	auto db = file.getDataSet("Spots");
	auto dims = db.getDimensions();

	// Shape: [x, y, z, N]
	if (dims == std::vector<size_t>{Mx, My, Mz, dims[3]}) {
		Arr4D<double> spots_transposed(fitParam.Mx, fitParam.My, fitParam.Mz, int(dims[3]));
		db.read(spots_transposed.data());
		return spots_transposed.move_axis(3, 0);
	}

	// Shape: [N, x, y, z]
	else if (dims == std::vector<size_t>{dims[0], Mx, My, Mz}) {
		Arr4D<double> spots(int(dims[0]), fitParam.Mx, fitParam.My, fitParam.Mz);
		db.read(spots.data());
		return spots;
	}

	std::stringstream ss;
	ss << "Dataset `Spots` has invalid dimensions, expecting shape [N, " << Mx << ", " << My  << ", " << Mz << "]";
	throw std::runtime_error(ss.str());
}
#endif

Arr4D<double> read_spots(const std::string &input_dir, FitParams &fitParam, int MaxNum) {
	using namespace placeholder;

	Arr4D<double> AllSpots;
	SampleParams sampleParam;

	if (input_dir.find(".h5") != std::string::npos) {
#if USEHDF5
		AllSpots = read_spots_hdf5(input_dir, fitParam);
#else
		throw std::runtime_error("HDF5 files are not supported. Compile with `USEHDF5=1`");
#endif
	} else if (sampleParam.SampleType == "exp")//bead, sim
	{
		AllSpots = read_spots_exp(fitParam);
	}
	else if (sampleParam.SampleType == "bead")
	{
		AllSpots = read_spots_bead(input_dir + "/common/allspot/binary/", fitParam);
	}
	else if (sampleParam.SampleType == "simdata")
	{
		AllSpots = read_spots_simdata(input_dir + "/allspot", fitParam);
	}
	else
	{
		AllSpots = read_spots_simulation(input_dir, fitParam);
	}

	int Ncfg = AllSpots.size(0);
	VF_ASSERT(AllSpots.shape() == shape(Ncfg, fitParam.Mx, fitParam.My, fitParam.Mz));
	std::cout << "found " << Ncfg << " spots" << std::endl;

	// Repeat spots until reaching MaxNum. This is only useful for benchmarking
	if (MaxNum > 0 && Ncfg > 0) {
		auto old_spots = AllSpots;
		AllSpots.resize(MaxNum, fitParam.Mx, fitParam.My, fitParam.Mz);

		for (int i = 0; i < MaxNum; i++) {
			AllSpots.view(i, _, _, _) = old_spots.view(i % Ncfg, _, _, _);
		}

		std::cout << "processing " << MaxNum << " spots" << std::endl;
	}

	return AllSpots;
}


Arr3D<std::complex<double>> read_center_spot(const std::string &input_dir, const FitParams &fitParam) {
	int Mpsfx = fitParam.Mpsfx;
	int Mpsfy = fitParam.Mpsfy;

	Arr2D<double> centerPSF(Mpsfx, Mpsfy);
	Arr2D<std::complex<double>> tempPSF2(Mpsfx, Mpsfy);
	Arr2D<std::complex<double>> OTF(fitParam.Notfx, fitParam.Notfy);

	std::string filename = input_dir + "testout/centerspot2.bin";
	readBinaryImage(filename, centerPSF);

	// Normalize tempPSF2
	tempPSF2 = centerPSF / centerPSF.sum();
	double FourierWindow = 2.0 * fitParam.NA / fitParam.Lambda;
	CztPlan(Mpsfx, fitParam.Notfx, fitParam.PsfXRange, FourierWindow).execute(tempPSF2, OTF);
	return OTF.insert_axis(2, 1);
}


void parse_arguments(argparse::ArgumentParser& program, int argc, char* argv[]) {
	program
		.add_argument("config")
		.default_value("")
		.help("The configuration yml file.");

	program
		.add_argument("input")
		.default_value(".")
		.help("The directory containing the input spots.");

	program
		.add_argument("output")
		.default_value(".")
		.help("The directory were the output will be written to.");

	program
		.add_argument("--device")
		.default_value("cpu")
		.help("The device to use: `CPU` or `GPU`");

	program
		.add_argument("--threads")
		.default_value(omp_get_max_threads())
		.scan<'i', int>()
		.help("The number of CPU threads to use. Only relevant when '--device cpu' is given.");

	program
		.add_argument("--low-accuracy")
		.default_value(false)
		.implicit_value(true)
		.help("Use lower accuracy operations on the GPU. This is faster, but results of the GPU might not be consistent "
			  "with results of the CPU. Only relevant when '--device gpu' is given.");

	program
		.add_argument("-n", "--nspots")
		.default_value(0)
		.scan<'i', int>()
		.help("Repeat input data such that there are exactly `n` spots. Useful for performance benchmarks.");

	program.parse_args(argc, argv);
}

int main(int argc, char* argv[]) {
	// We cannot return `argparse::ArgumentParser` from `parse_arguments` since its move ctor is buggy.
	// See: https://github.com/p-ranav/argparse/issues/226
	argparse::ArgumentParser args(argv[0]);
	parse_arguments(args, argc, argv);

	// No config given, print the help message
	if (!args.is_used("config")) {
		std::cerr << args << std::endl;
		return EXIT_FAILURE;
	}

	auto config_file = args.get("config");

	std::string input_dir = "D:/0-TUDelft/work/plotdata/";
	if (args.is_used("input")) {
		input_dir = args.get("input");
	}
	std::string output_dir = input_dir;
	if (args.is_used("output")) {
		output_dir = args.get("output");
	}
	std::string info;
	std::string addinfo;
	std::string filename = "";

	//====Set all the parameters==============================
	FitParams fitParam = config_file.empty() ? FitParams() : FitParams::parse_file(config_file);
	//sampleParam.setSampleParams(sampleParam.SampleType);

	bool low_accuracy = args.get<bool>("--low-accuracy");
	std::string device = args.is_used("--device") ? args.get("--device") : "cpu";
	std::transform(device.begin(), device.end(), device.begin(), ::tolower);

	Estimator base_estimator = Estimator(fitParam);
	std::unique_ptr<BaseEstimator> Mle;

	if (device == "cpu" || device.empty()) {
		int num_threads = args.get<int>("--threads");
		fitParam.NumThreads = num_threads;
		Mle = std::make_unique<ParallelEstimator>(base_estimator);  //estimator
	} else if (device == "gpu") {
#if USECUDA
		if (fitParam.FlagOTF) {
			Mle = std::make_unique<CudaOTFEstimator>(base_estimator, 0, low_accuracy);
		} else {
			Mle = std::make_unique<CudaEstimator>(base_estimator, 0, low_accuracy);
		}
#else
		throw std::runtime_error("CUDA is not supported, please compile using `-DUSECUDA=1`");
#endif
	} else {
		throw std::runtime_error("unknown device: " + device);
	}

	//=================================================================
	// ==== Read/simulate data (experimental data, segmented beads, simulate data) ======
	Arr4D<double> AllSpots;
	double input_time = benchmark([&] {
		AllSpots = read_spots(input_dir, fitParam, args.get<int>("-n"));
	});

	int Ncfg = AllSpots.size(0);
	if (Ncfg <= 0) {
		std::cerr << "no spots found" << std::endl;
		return EXIT_FAILURE;
	}

	// Optionally set OTF
	if (fitParam.FlagOTF) {
		Estimator::otf_type OTF = read_center_spot(input_dir, fitParam);
		Arr1D<int> spot_otf_indices(Ncfg);
		spot_otf_indices.fill(0); // All spots use the same OTF
		Mle->SetOTFs(OTF.insert_axis(0, 1), spot_otf_indices);
	}

	//===============================================================
	//===== Maximum Likelihood Estimation routine ====================
	const int NumParams = fitParam.FitModel.num_parameters();
	const int theta_size = fitParam.FitModel.theta_size();
	Arr2D<double>ThetaInit(Ncfg, theta_size);
	Arr3D<double> ThetaStore(Ncfg, theta_size, fitParam.NiterMax + 1); // TODO: theta_size or NumParams?
	Arr4D<double> muStore(Ncfg, fitParam.Mx, fitParam.My, fitParam.Mz);
	Arr5D<double> dmudThetaStore(Ncfg, fitParam.Mx, fitParam.My, fitParam.Mz, NumParams);
	Arr2D<double> Merit(Ncfg, fitParam.NiterMax + 1);
	Arr1D<int> NumIters(Ncfg);
	Arr1D<bool> IsConverged(Ncfg);

	double init_time = benchmark([&] {
		Mle->InitializeSpots(AllSpots, ThetaInit);
	});

	double localize_time = benchmark([&] {
		Mle->LocalizeSpots(AllSpots, ThetaInit, ThetaStore, muStore, dmudThetaStore, Merit, NumIters, IsConverged);
	});

	double NIterAvg = (double) NumIters.sum() / Ncfg;
	double NIterTemp = 0.0;
	for (int ii = 0; ii < Ncfg; ii++)
	{
		NIterTemp += pow((NumIters[ii] - NIterAvg), 2);
	}

	std::cout << "Min Iter: " << NumIters.minimum() << std::endl;
	std::cout << "Max Iter: " << NumIters.maximum() << std::endl;
	std::cout << "Avg Iter: " << NIterAvg << std::endl;
	std::cout << "Dev_std: " << sqrt(NIterTemp / Ncfg) << std::endl;

	int maxiter = fitParam.NiterMax;
	Arr2D<double> Thetafinal = ThetaStore.view(placeholder::all(), placeholder::all(), maxiter);

	std::cout << "Estimated values for spot 0: " << std::endl;
	for (int ii = 0; ii < NumParams; ii++)
	{
		std::cout << Thetafinal(0, ii) << std::endl;
	}
	std::cout << "Merit =" << Merit(0, maxiter) << std::endl;

	double output_time = benchmark([&] {
		write_output(
				output_dir,
				Ncfg,
				fitParam,
				ThetaInit.move_axis(0, 1),
				AllSpots.move_axis(0, 3),
				Thetafinal.move_axis(0, 1),
				muStore.move_axis(0, 3),
				dmudThetaStore.move_axis(0, 4),
				Merit,
				NumIters);
	});

	std::cout << "" << std::endl;
	std::cout << "Read input time: " << input_time << " seconds" << std::endl;
	std::cout << "Initialize time: " << init_time << " seconds" << std::endl;
	std::cout << "Localization time: " << localize_time << " seconds" << std::endl;
	std::cout << "Write output time: " << output_time << " seconds" << std::endl;
	return EXIT_SUCCESS;
}