/* vectorfit_get_fisher_crlb()
 * Computes the Fisher CRLB from the last local update.
 *
 * returns a 2D array with the parameter bounds for all spots.
*/

#include "vectorfit_mex.hpp"
#include "vectorfit_fitter.hpp"
#include "array/operators.h"


class MexFunction : public VectorfitMexFunction {
public:
    using ArgumentList = matlab::mex::ArgumentList;
    using Struct = matlab::data::Struct;
    using StructArray = matlab::data::StructArray;

    void execute(ArgumentList outputs, ArgumentList inputs) {
        // Obtain fitter object handle
        const uint64_t handle = inputs[0][0];
        VectorfitFitter* fitter = VectorfitMemoryManager::get(handle);
        // Obtain the Fisher CRLB.
        int num_params = fitter->fitter().params().FitModel.num_parameters();
        int num_spots = fitter->fitter().num_spots();
        Arr2D<double> crlb(num_params, num_spots);
        fitter->fitter().get_fisher_crlb(crlb);

        // Output the CRLB for all spots.
        outputs[0] = _array_factory.createArray(
            {(uint64_t)crlb.size(0), (uint64_t)crlb.size(1)},
            crlb.begin(),
            crlb.end(),
            matlab::data::InputLayout::ROW_MAJOR
        );
    }

    void checkArguments(ArgumentList outputs, ArgumentList inputs) {
        // Check array arguments
        if (inputs.size() != 1) {
            feval_error("Number of required inputs is 1: (vectorfit_handle)");
        }
        // Check array argument: first input must be a uint64_t scalar
        if (inputs[0].getType() != ArrayType::UINT64 ||
            inputs[0].getNumberOfElements() != 1)
        {
            feval_error("Input 1 must be a vectorfit handle in the form of a uint64 scalar");
        }
        if (outputs.size() != 1)
        {
            feval_error("One output is returned: a matrix with the CRLB values per spot");
        }
    }
};
