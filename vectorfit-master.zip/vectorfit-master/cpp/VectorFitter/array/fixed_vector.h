#pragma once

#include "cuda/macros.cuh"
#include "../utils.h"

#if !CUDA_RTC
#include <utility>
#endif

template <typename T, size_t N> struct fixed_vector {
  constexpr fixed_vector(const fixed_vector &) = default;
  constexpr fixed_vector(fixed_vector &&) noexcept = default;
  constexpr fixed_vector() = default;
	constexpr fixed_vector &
	operator=(const fixed_vector &) = default;
	constexpr fixed_vector &
	operator=(fixed_vector &&) noexcept = default;

  constexpr CUDA_HOST_DEVICE fixed_vector(std::initializer_list<T> input) {
    if (input.size() == 0) {
      for (size_t i = 0; i < N; i++) {
        values_[i] = T{};
      }
    } else if (input.size() == N) {
      for (size_t i = 0; i < N; i++) {
        values_[i] = *(input.begin() + i);
      }
    } else {
      VF_PANIC("invalid initializer_list length");
    }
  }

  size_t CUDA_HOST_DEVICE size() { return N; }

  CUDA_HOST_DEVICE
  T &operator[](size_t i) {
	  VF_DEBUG_ASSERT(i < N);
	  return values_[i];
  }

  CUDA_HOST_DEVICE
  const T &operator[](size_t i) const {
	  VF_DEBUG_ASSERT(i < N);
	  return values_[i];
  }

  CUDA_HOST_DEVICE
  T *data() { return &values_[0]; }

  CUDA_HOST_DEVICE
  T *begin() { return &values_[0]; }

  CUDA_HOST_DEVICE
  T *end() { return &values_[N]; }

  CUDA_HOST_DEVICE
  const T *data() const { return &values_[0]; }

  CUDA_HOST_DEVICE
  const T *begin() const { return &values_[0]; }

  CUDA_HOST_DEVICE
  const T *end() const { return &values_[N]; }

private:
  T values_[N] = {};
};

template <typename T> struct fixed_vector<T, 0> {
  constexpr fixed_vector(const fixed_vector &) = default;
  constexpr fixed_vector(fixed_vector &&) noexcept = default;
  constexpr fixed_vector() = default;

	constexpr fixed_vector &
	operator=(const fixed_vector &) = default;

	constexpr fixed_vector &
	operator=(fixed_vector &&) noexcept = default;

  CUDA_HOST_DEVICE
  constexpr fixed_vector(std::initializer_list<T> input) {
    if (input.size() != 0) {
      VF_PANIC("invalid initializer_list length");
    }
  }

  CUDA_HOST_DEVICE
  size_t size() { return 0; }

  [[noreturn]] CUDA_HOST_DEVICE T &operator[](size_t i) {
    VF_PANIC("index invalid");
  }

  [[noreturn]] CUDA_HOST_DEVICE const T &operator[](size_t i) const {
    VF_PANIC("index invalid");
  }

  CUDA_HOST_DEVICE
  T *data() { return nullptr; }

  CUDA_HOST_DEVICE
  T *begin() { return nullptr; }

  CUDA_HOST_DEVICE
  T *end() { return nullptr; }

  CUDA_HOST_DEVICE
  const T *data() const { return nullptr; }

  CUDA_HOST_DEVICE
  const T *begin() const { return nullptr; }

  CUDA_HOST_DEVICE
  const T *end() const { return nullptr; }
};

template <typename L, typename R, size_t N, size_t M>
CUDA_HOST_DEVICE bool operator==(const fixed_vector<L, N> lhs,
                                 const fixed_vector<R, M> &rhs) {
  if (N != M) {
    return false;
  }

	// int(N) is to silence warning "pointless comparison of unsigned integer with zero"
  for (size_t i = 0; int(i) < int(N); i++) {
	  if (lhs[i] != rhs[i]) {
		  return false;
	  }
  }

  return true;
}

template <typename L, typename R, size_t N, size_t M>
CUDA_HOST_DEVICE bool operator!=(const fixed_vector<L, N> lhs,
                                 const fixed_vector<R, M> &rhs) {
  return !(lhs == rhs);
}

template <typename T, typename F, size_t... Is>
CUDA_HOST_DEVICE auto generate_vector_helper(F fun, std::index_sequence<Is...>)
    -> fixed_vector<T, sizeof...(Is)> {
  return {fun(Is)...};
}

template <size_t N, typename F,
          typename T = typename std::result_of<F(size_t)>::type>
CUDA_HOST_DEVICE auto generate_vector(F fun) -> fixed_vector<T, N> {
  return generate_vector_helper<T, F>(fun, std::make_index_sequence<N>{});
}

#define FIXED_VECTOR_OP_IMPL(op)                                               \
  template <size_t N, typename L, typename R,                                  \
            typename T = decltype(std::declval<L>() op std::declval<R>())>     \
  CUDA_HOST_DEVICE fixed_vector<T, N> operator op(                             \
      const fixed_vector<L, N> &lhs, const fixed_vector<L, N> &rhs) {          \
    return generate_vector([&](size_t i) { return lhs[i] op rhs[i]; });        \
  }                                                                            \
                                                                               \
  template <size_t N, typename L,                                              \
            typename R = decltype(std::declval<L>() op std::declval<L>())>     \
  CUDA_HOST_DEVICE fixed_vector<R, N> operator op(                             \
      const fixed_vector<L, N> &lhs, const L &rhs) {                           \
    return generate_vector([&](size_t i) { return lhs[i] op rhs; });           \
  }                                                                            \
                                                                               \
  template <size_t N, typename L,                                              \
            typename R = decltype(std::declval<L>() op std::declval<L>())>     \
  CUDA_HOST_DEVICE fixed_vector<R, N> operator op(                             \
      const L &lhs, const fixed_vector<L, N> &rhs) {                           \
    return generate_vector([&](size_t i) { return lhs[i] op rhs; });           \
  }

FIXED_VECTOR_OP_IMPL(+)
FIXED_VECTOR_OP_IMPL(-)
FIXED_VECTOR_OP_IMPL(*)
FIXED_VECTOR_OP_IMPL(/)
FIXED_VECTOR_OP_IMPL(%)

#if !CUDA_RTC
template <typename T, size_t N>
struct is_cuda_copyable<fixed_vector<T, N>>: is_cuda_copyable<T> {};

template <typename T, size_t N>
std::ostream &operator<<(std::ostream &stream, const fixed_vector<T, N> &vec) {
  stream << "{";
  for (size_t i = 0; i < N; i++) {
    if (i != 0)
      stream << ", ";
    stream << vec[i];
  }
  return stream << "}";
}
#endif