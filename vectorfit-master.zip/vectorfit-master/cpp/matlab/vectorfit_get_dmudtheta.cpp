/* vectorfit_get_dmudtheta()
 * Returns dMu/dTheta for all spots from the last local update.
 *
 * returns a 5D array with dMu/dTheta for all spots.
*/

#include "vectorfit_mex.hpp"
#include "vectorfit_fitter.hpp"
#include "array/operators.h"


class MexFunction : public VectorfitMexFunction {
public:
    using ArgumentList = matlab::mex::ArgumentList;
    using Struct = matlab::data::Struct;
    using StructArray = matlab::data::StructArray;

    void execute(ArgumentList outputs, ArgumentList inputs) {
        // Obtain fitter object handle
        const uint64_t handle = inputs[0][0];
        VectorfitFitter* fitter = VectorfitMemoryManager::get(handle);
        // Obtain dmudtheta.
        // Shape: (num_spots, Mx, My, Mz, num_params).
        View5D<double> dmudtheta = fitter->fitter().dmudtheta();

        // Output dmudtheta for all spots.
        // Shape: (Mx, My, Mz, num_parmas, num_spots).
        TypedArray<double> output_dmudtheta = _array_factory.createArray<double>(
            {
                (uint64_t)dmudtheta.size(1),
                (uint64_t)dmudtheta.size(2),
                (uint64_t)dmudtheta.size(3),
                (uint64_t)dmudtheta.size(4),
                (uint64_t)dmudtheta.size(0),
            }
        );

        // Create output iterator and copy data.
        // Since dmudtheta is in row-major layout and output_dmudtheta in col-major layout,
        // the iterator dimensions are reversed:
        //   output dimensions:   (1, 2, 3, 4, 0)
        //   iterator dimensions: (0, 4, 3, 2, 1)
        auto output_dmudtheta_begin = output_dmudtheta.begin();
        dmudtheta.reorder_axes({0, 4, 3, 2, 1}).for_each(
            [&](const double& value) {*(output_dmudtheta_begin++) = value;}
        );
        outputs[0] = output_dmudtheta;
    }

    void checkArguments(ArgumentList outputs, ArgumentList inputs) {
        // Check array arguments
        if (inputs.size() != 1) {
            feval_error("Number of required inputs is 1: (vectorfit_handle)");
        }
        // Check array argument: first input must be a uint64_t scalar
        if (inputs[0].getType() != ArrayType::UINT64 ||
            inputs[0].getNumberOfElements() != 1)
        {
            feval_error("Input 1 must be a vectorfit handle in the form of a uint64 scalar");
        }
        if (outputs.size() != 1)
        {
            feval_error("One output is returned: a matrix with dMu/dTheta per spot");
        }
    }
};
