#include "Fitter.h"
#include "estimator/cpu_estimator.h"
#include "estimator/gpu_estimator.h"
#include "array/operators.h"
#include "compute/fisher.h"
#include <thread>
#include <numeric>


Fitter::Fitter(
	Arr4D<double>&& spots,
	Arr2D<double>&& roixy,
	const FitParams& params,
	const std::string& compute_device
)
: _spots(std::move(spots))
, _roixy(std::move(roixy))
, _params(params)
{
	create_estimator(compute_device);
	set_aberrations();
	resize_internals();
}

void Fitter::create_estimator(const std::string& compute_device) {
	// Create main localization estimator
	Estimator base_estimator = Estimator(_params);

	if (compute_device == "cpu" || compute_device.empty()) {
		_estimator = std::make_unique<ParallelEstimator>(base_estimator);  //estimator
		_estimator_type = EstimatorType::CPU_PARALLEL;
		std::cout << "Created parallel CPU estimator with " << _params.NumThreads << " threads!" << std::endl;
	} else if (compute_device.substr(0, 3) == "gpu") {
#if USECUDA
		bool low_accuracy = compute_device.find("lowaccuracy") != std::string::npos;
		if (_params.FlagOTF) {
			_estimator = std::make_unique<CudaOTFEstimator>(base_estimator, 0, low_accuracy);
			_estimator_type = EstimatorType::CUDA_OTF;
			std::cout << "Created CudaOTF GPU estimator!" << std::endl;
		} else {
			_estimator = std::make_unique<CudaEstimator>(base_estimator, 0, low_accuracy);
			_estimator_type = EstimatorType::CUDA;
			std::cout << "Created Cuda GPU estimator!" << std::endl;
		}
		if (low_accuracy) {
			std::cout << "Note: GPU low accuracy mode enabled!" << std::endl;
		}
#else
		throw std::runtime_error("CUDA is not supported, please compile using `-DUSECUDA=1`");
#endif
	} else {
		throw std::runtime_error("Unknown device: " + compute_device);
	}

	// Create OTF estimator if needed
	if (_params.FlagOTF) {
		FitParams params_otf = _params;
		// For 3D OTFs, the 'source' PSF must also be 3D.
		// This requires a couple of fixed settings for the OTF estimator:
		// - excitation set to zstack
		// - zstage set to 0.0
		// - zrange equal to [-PsfZRange, +PsfZRange]
		if (_params.FitModel.has_z())
		{
			params_otf.Excitation = ExcitationEnum::zstack;
			params_otf.zstage = 0.0;
			params_otf.ZRange = {-_params.PsfZRange, _params.PsfZRange};
		}
		Estimator base_estimator_otf = Estimator(params_otf);
		_otfs_estimator = std::make_unique<ParallelEstimator>(base_estimator_otf);
	}
}

void Fitter::set_aberrations() {
	// Set aberrations from pupil params
	_aberration_orders.resize(PupilParams::MaxNaberr);

	for (int i_aberr=0; i_aberr<_aberration_orders.size(0); ++i_aberr)
	{
		_aberration_orders[i_aberr].radial_order = _params.AberrationOrders[i_aberr][0];
		_aberration_orders[i_aberr].azimuthal_order = _params.AberrationOrders[i_aberr][1];
	}
}

void Fitter::resize_internals() {
	// Resize theta and initialize with 0.0
	const int num_params = _params.FitModel.num_parameters();
	const int theta_size = _params.FitModel.theta_size();
	std::cout << "Resizing theta to " << theta_size << " elements; "
		<< num_params << " parameters are fitted" << std::endl;
	_theta.resize({num_spots(), theta_size}, 0.0);
	// Resize Mu
	_mu.resize(num_spots(), _params.Mx, _params.My, _params.Mz);
	// Resize dMudTheta
	_dmudtheta.resize(num_spots(), _params.Mx, _params.My, _params.Mz, num_params);
	// Resize num_iters and initialize with 0
	_num_iters.resize({num_spots()}, 0);
	// Resize convergence and initialize with false
	_convergence.resize({num_spots()}, false);
	// Resize merit array
	_merit.resize(num_spots(), _params.NiterMax + 1);
}

void Fitter::init() {
	if (num_spots() <= 0) {
		std::cerr << "no spots found" << std::endl;
		return;
	}

	std::cout << "Initializing spots.." << std::endl;
	double init_time = benchmark([&] {
		_estimator->InitializeSpots(spots(), _theta);
	});
	std::cout << "Initialize time: " << init_time << " seconds" << std::endl;
}

void Fitter::flip_z() {
	if (_params.FitModel.has_z()) {
		_theta.view(placeholder::_, _params.FitModel.offset_z()) *= -1.0;
	} else {
		throw std::runtime_error(
			"Cannot flip Z: fitmodel '" + _params.FitModel.to_string() + "' has no Z"
		);
	}
}

void Fitter::update() {
	int Ncfg = num_spots();

	// Verify state
	if (Ncfg <= 0) {
		throw std::runtime_error("Spots are not initialized");
	}
	if (_theta.size(0) != Ncfg) {
		throw std::runtime_error("Theta is not initialized");
	}

	// Reset memory for this update
	_merit.fill(0.0);
	_num_iters.fill(0);
	_convergence.fill(false);

	//===============================================================
	//===== Maximum Likelihood Estimation routine ====================
	const int NumParams = _params.FitModel.num_parameters();
	const int theta_size = _params.FitModel.theta_size();
	Arr3D<double> ThetaStore(Ncfg, theta_size, _params.NiterMax + 1); // TODO: theta_size or NumParams?

	double localize_time = benchmark([&] {
		_estimator->LocalizeSpots(
			spots(),
			_theta,
			ThetaStore,
			_mu,
			_dmudtheta,
			_merit,
			_num_iters,
			_convergence
		);
	});

	double NIterAvg = (double) _num_iters.sum() / Ncfg;
	double NIterTemp = 0.0;
	for (int ii = 0; ii < Ncfg; ii++)
	{
		NIterTemp += pow((_num_iters[ii] - NIterAvg), 2);
	}

	std::cout << "Min. num iters: " << _num_iters.minimum() << std::endl;
	std::cout << "Max. num iters: " << _num_iters.maximum() << std::endl;
	std::cout << "Avg. num iters: " << NIterAvg << std::endl;
	std::cout << "Stdev. num iters: " << sqrt(NIterTemp / Ncfg) << std::endl;

	int maxiter = _params.NiterMax;
	_theta = ThetaStore.view(placeholder::all(), placeholder::all(), maxiter);

	std::cout << "Localization time: " << localize_time << " seconds" << std::endl;
}

std::vector<int> Fitter::get_outliers() const {
	std::vector<int> outliers;
	outliers.reserve(num_spots());
	View1D<bool> spot_convergence = convergence();

	// Compute mean and stdev of the final merit of converged spots only.
	// The mean is computed in an incremental manner, which should be numerically
	// more stable if the number of spots becomes very large.
	View1D<double> final_merit = _merit.drop_axis(1, _merit.size(1)-1);
	// .. merit mean
	std::vector<double> converged_spots_final_merit;
	converged_spots_final_merit.reserve(num_spots());
	double final_merit_mean = 0.0;
	for (int i_spot=0; i_spot < num_spots(); ++i_spot) {
		if (spot_convergence(i_spot)) {
			double merit = final_merit(i_spot);
			converged_spots_final_merit.push_back(merit);
			// Keep track of the mean in a numerically stable way
			final_merit_mean += (merit - final_merit_mean) / converged_spots_final_merit.size();
		}
	}
	// .. merit variance
	double final_merit_variance = 0.0;
	size_t variance_counter = 0;
	for (double merit : converged_spots_final_merit) {
		double diff = merit - final_merit_mean;
		// Keep track of the variance in a numerically stable way
		final_merit_variance += (diff*diff - final_merit_variance) / ++variance_counter;
	}
	double final_merit_stdev = sqrt(final_merit_variance);
	double final_merit_outlier_threshold = final_merit_mean - 3.0*final_merit_stdev;
	std::cout << "Final merit: mean: " << final_merit_mean
		<< ", stdev: " << final_merit_stdev
		<< ", outlier threshold: " << final_merit_outlier_threshold
		<< std::endl;

	double xy_box_size = 3.0;
	if (_params.FitModel.has_z()) {
		xy_box_size = 5.0;
	}

	// Evaluate outlier criteria for all spots
	int i_outlier=0;
	for (int i_spot=0; i_spot<num_spots(); ++i_spot) {
		bool is_xy_outlier = (std::abs(_theta(i_spot, _params.FitModel.offset_x())) > xy_box_size*_params.PixelSize)
						|| (std::abs(_theta(i_spot, _params.FitModel.offset_y())) > xy_box_size*_params.PixelSize);
		bool is_merit_outlier = (final_merit(i_spot) < final_merit_outlier_threshold);
		bool is_converged = spot_convergence(i_spot);
		bool outlier = is_xy_outlier || is_merit_outlier || !is_converged;
		if (outlier) {
			outliers.push_back(i_spot);
			i_outlier++;
			/* DEBUG output
			std::ostringstream ss;
			ss << std::setprecision(4);
			ss << "Spot " << i_spot << ": "
				<< " xy outlier: " << (is_xy_outlier ? "YES" : "no") << ","
				<< " merit outlier: " << (is_merit_outlier ? "YES" : "no") << " (merit: " << final_merit(i_spot) << "),"
				<< " convergence issue: " << (is_converged ? "no" : "YES") << ","
			;
			std::cout << ss.str() << std::endl;
			*/
		}
	}
	outliers.resize(i_outlier);
	return outliers;
}

Arr2D<double> Fitter::get_normalized_fov_coordinates(
	const View1D<double>& x, const View1D<double>& y
) const {
	// fov_coordinates_x = -1+2*(roixy(1,:)*pixelsize + x)/xsize;
	// fov_coordinates_y = -1+2*(roixy(2,:)*pixelsize + y)/ysize;
	Arr2D<double> fov_coordinates(_roixy.shape());
	double xsize = _params.PixelSize*_params.imgSizeX;  // in pysical coordinates
	double ysize = _params.PixelSize*_params.imgSizeY;

	// Compute normalized FOV: X and Y
	// TODO: why doesn't this compile?: roixy.view(0, _) * _params.PixelSize;
	Arr1D<double> roixy_x = _roixy.view(0, placeholder::_);
	Arr1D<double> roixy_y = _roixy.view(1, placeholder::_);
	fov_coordinates.view(0, placeholder::_) = (roixy_x*_params.PixelSize + x)*2.0/xsize - 1.0;
	fov_coordinates.view(1, placeholder::_) = (roixy_y*_params.PixelSize + y)*2.0/ysize - 1.0;

	return fov_coordinates;
}

Arr2D<double> Fitter::update_zernike_coefficients(
	View1D<double> gammas, View1D<Aberration> aberrations
) {
	int num_aberr = _params.FitModel.num_aberrations();
	int num_orders = _aberration_orders.numel();
	if (num_aberr != num_orders) {
		throw std::runtime_error(
			"Fitmodel has " + std::to_string(num_aberr) + " aberrations, but "
			+ std::to_string(_aberration_orders.numel()) + " aberration orders provided"
		);
	}
	// Compute the normalized FOV coordinates
    // The X and Y coordinates are taken from the current state of _theta.
	Arr2D<double> fov_coordinates = get_normalized_fov_coordinates(
		_theta.view(placeholder::_, _params.FitModel.offset_x()),
		_theta.view(placeholder::_, _params.FitModel.offset_y())
	);
	// Compute the Zernike coefficients
	Arr2D<double> coeffs(fov_coordinates.size(1), num_aberr);
	compute::zernike_coefficients::compute_xy_gamma_legendre(
		fov_coordinates.view(0, placeholder::_),
		fov_coordinates.view(1, placeholder::_),
		gammas, _aberration_orders, coeffs
	);
	// Store the Zernike coefficients in theta
	_theta.view(
		placeholder::_,
		placeholder::range(
			_params.FitModel.offset_aberrations(),
			_params.FitModel.offset_aberrations()+coeffs.size(1)
		)
	) = coeffs;

	// Update OTF grid if applicable
	if (_params.FlagOTF) {
		Arr1D<int> spot_otf_indices(num_spots());
		Arr4D<std::complex<double>> OTFs(num_otfs(), _params.Notfx,	_params.Notfy, _params.Notfz);
		update_otfs(gammas, aberrations, OTFs, spot_otf_indices);
	}
	// Return the coeffs
	return coeffs;
}

void Fitter::update_otfs(
	View1D<double> gammas,
	View1D<Aberration> aberrations,
	WriteView4D<std::complex<double>> otfs,
	WriteView1D<int> spot_otf_indices
) {
	if (!_params.FlagOTF) {
		throw std::runtime_error("Cannot update OTFs because OTFs are not enabled (FlagOTF is false)");
	}
	int num_aberr = _params.FitModel.num_aberrations();
	Arr2D<double> otf_grid_coeffs(num_otfs(), num_aberr);
	compute_otf_grid_zernike_coefficients(
		_params.OTFGridSizeX,
		_params.OTFGridSizeY,
		gammas,
		otf_grid_coeffs,
		spot_otf_indices
	);
	// Compute OTFs on the parallel CPU estimator
	VF_ASSERT(otfs.shape() == shape(num_otfs(), _params.Notfx, _params.Notfy, _params.Notfz));
	double otf_computation_time = benchmark([&] {
		_otfs_estimator->ComputeOTFs(otf_grid_coeffs, otfs);
	});
	std::cout << "Computed "
		<< _params.OTFGridSizeX << " x " << _params.OTFGridSizeY
		<< " OTFs: " << otf_computation_time << " seconds" << std::endl;
	// Set OTFs and OTF indices per spot in the estimator
	set_otfs(otfs, spot_otf_indices);
}

void Fitter::set_otfs(
	View4D<std::complex<double>> otfs,
	View1D<int> spot_otf_indices
) {
	if (!_params.FlagOTF) {
		throw std::runtime_error("Cannot set OTFs because OTFs are not enabled (FlagOTF is false)");
	}
	// Set OTFs and OTF indices per spot in the estimator
	_estimator->SetOTFs(otfs, spot_otf_indices);
}

int Fitter::num_otfs() const {
	return _params.OTFGridSizeX * _params.OTFGridSizeY;
}

void Fitter::compute_otf_grid_zernike_coefficients(
	int grid_size_x,
	int grid_size_y,
	View1D<double>& gammas,
	WriteView2D<double> coefficients,
	WriteView1D<int> spot_coeff_indices
) const {
	using namespace placeholder;
	int num_aberr = _aberration_orders.size(0);
	VF_ASSERT(coefficients.shape() == shape(grid_size_x * grid_size_y, num_aberr));
	VF_ASSERT(spot_coeff_indices.shape() == shape(num_spots()));
	// Compute grid patch size in number of pixels
	double grid_patch_size_x = _params.imgSizeX / grid_size_x;
	double grid_patch_size_y = _params.imgSizeY / grid_size_y;
	// Compute the grid patch indices per spot
	for (int i_spot=0; i_spot < num_spots(); ++i_spot) {
		// Note: _roixy is 1-based
		int grid_x = floor((_roixy(0, i_spot) - 1) / grid_patch_size_x);
		int grid_y = floor((_roixy(1, i_spot) - 1) / grid_patch_size_y);
		// Compute the index from the fov_coordinates loop order.
		spot_coeff_indices(i_spot) = (grid_x * grid_size_y) + grid_y;
	}
	// Compute normalized fov coordinates for the OTFs
	Arr1D<double> fov_coordinates_x(grid_size_x * grid_size_y);
	Arr1D<double> fov_coordinates_y(grid_size_x * grid_size_y);
	enum OTFGridMethod {otfgridRegular, otfgridCoeffWeighted};
	OTFGridMethod grid_method = otfgridRegular;
	if (grid_method == otfgridRegular) {
		// Compute the normalized fov coordinates for otf grid patch centers.
		// Note: the center of the first pixel is at (2.0/imgSizeX-1.0, 2.0/imgSizeY-1.0)
		//       (see Fitter::get_normalized_fov_coordinates(), where roi values start at 1).
		int i_patch = 0;
		for (int otf_x=0; otf_x < grid_size_x; ++otf_x) {
			for (int otf_y=0; otf_y < grid_size_y; ++otf_y) {
				fov_coordinates_x(i_patch) = (grid_patch_size_x*(0.5 + otf_x) + 0.5)*2.0/_params.imgSizeX - 1.0;
				fov_coordinates_y(i_patch) = (grid_patch_size_y*(0.5 + otf_y) + 0.5)*2.0/_params.imgSizeY - 1.0;
				++i_patch;
			}
		}
		// Compute the Zernike coefficients from the fov_coordinates
		compute::zernike_coefficients::compute_xy_gamma_legendre(
			fov_coordinates_x,
			fov_coordinates_y,
			gammas, _aberration_orders, coefficients
		);
	} else if (grid_method == otfgridCoeffWeighted) {
		Arr1D<double> otf_coeffs_count(grid_size_x * grid_size_y);
		// Compute the avearge coefficients of all spots in each grid patch
		for (int i_spot=0; i_spot<num_spots(); ++i_spot) {
			int otf_index = spot_coeff_indices(i_spot);
			WriteView1D<double> otf_coeffs = coefficients.view(otf_index, _);
			otf_coeffs += _theta.view(
				i_spot,
				range(
					_params.FitModel.offset_aberrations(),
					_params.FitModel.offset_aberrations()+num_aberr
				)
			);
			otf_coeffs_count(otf_index)++;
		}
		// Divide by the spot count per otf. Avoid division by zero.
		for (int i_otf=0; i_otf<grid_size_x * grid_size_y; ++i_otf) {
			coefficients.view(i_otf, _) /= std::max(1.0, otf_coeffs_count(i_otf));
		}
	} else {
		throw std::runtime_error("Unknown OTF grid method");
	}
}

View2D<double> Fitter::theta_params_only() const {
	return _theta.view(
		placeholder::_,
		placeholder::range(0, _params.FitModel.num_parameters())
	);
}

void Fitter::get_fisher_crlb(WriteView2D<double> crlb) const {
	VF_ASSERT(crlb.shape() == shape(_params.FitModel.num_parameters(), num_spots()));
	Arr1D<double> rcond_unused;
	compute::getFisherCRLB(_params, _mu.move_axis(0, 3), _dmudtheta.move_axis(0, 4), crlb, rcond_unused);
}

PupilMatrix Fitter::get_pupil_matrix(const double* zernike_coeffs) const {
	Estimator estimator = Estimator(_params);
	// Update aberrations if the coefficients are provided
	if (zernike_coeffs != nullptr) {
		estimator.pupil_matrix.update_aberrations(zernike_coeffs);
	}
	return std::move(estimator.pupil_matrix);
}

void Fitter::get_modeled_spot(int spot_index, WriteView3D<double> mu, WriteView4D<double> dmudtheta) {
	int nparams = _params.FitModel.num_parameters();

	Arr4D<std::complex<double>> PupilMatrix(_params.NPupil, _params.NPupil, 2, 3);

	if (_estimator_type == EstimatorType::CPU_PARALLEL) {
		auto theta_spot = _theta.view(spot_index, placeholder::_);
		auto spot = SpotParameters::from_theta(_params.FitModel, theta_spot);
		ParallelEstimator *estimator = derived_estimator<ParallelEstimator>();
		estimator->thread_estimator(0).pupil_matrix.update_aberrations(spot.AberrationCoefs);
		estimator->thread_estimator(0).PoissonRate(spot, mu, dmudtheta);
	} else if (_estimator_type == EstimatorType::CUDA) {
		std::cout << "Preparing memory" << std::endl;
		CudaEstimator *estimator = derived_estimator<CudaEstimator>();
		// Create memory for 1 spot and copy _theta(spot_index, ...);
		PinnedArr1D<int> activeCfg(1);
		activeCfg(0) = 0;
		CudaArr1D<index_t> activeCfg_d = cuda_copy(activeCfg);
		CudaArr4D<double> all_mu_d(1, _params.Mx, _params.My, _params.Mz);
		CudaArr5D<double> all_dmudtheta_d(1, _params.Mx, _params.My, _params.Mz, nparams);
		CudaArr2D<double> theta_d = cuda_copy(_theta.limit_axis(0, spot_index, spot_index+1));
		std::cout << "Calling PoissonRate()" << std::endl;
		estimator->PoissonRate(activeCfg_d, theta_d, all_mu_d, all_dmudtheta_d);
		std::cout << "Copying back memory" << std::endl;
		cuda_copy(all_mu_d.drop_axis(0), mu);
		cuda_copy(all_dmudtheta_d.drop_axis(0), dmudtheta);
		std::cout << "Done" << std::endl;
	} else if (_estimator_type == EstimatorType::CUDA_OTF) {
		throw std::runtime_error("No implementation for get_modeled_spot() for CudaOTF estimator");
	} else {
		throw std::runtime_error("Internal error: uninitialized estimator or type unknown");
	}
}
