#pragma once

#include "core.h"
#include "cuda/accessor.cuh"

template <typename T, size_t N, MemorySpace space = MemorySpace::Host>
class ViewND;

namespace placeholder {
	struct all_t {};

	struct range_t {
		CUDA_HOST_DEVICE
		constexpr range_t(index_t start, index_t end) : start(start), end(end) {}

		index_t start = 0;
		index_t end = 0;
	};

	struct new_axis_t {
		CUDA_HOST_DEVICE
		constexpr new_axis_t(dim_t n = 1) : size(n) {}

		dim_t size = 1;
	};

	template <size_t N>
	struct flatten_axes_t {
		CUDA_HOST_DEVICE
		constexpr flatten_axes_t() {}
	};

	CUDA_HOST_DEVICE
	static constexpr all_t all() {
		return {};
	}

	CUDA_HOST_DEVICE
	static constexpr range_t range(index_t start, index_t end) {
		return {start, end};
	}

	CUDA_HOST_DEVICE
	static constexpr new_axis_t newaxis(dim_t length=1) {
		return {length};
	}

	template <size_t N>
	CUDA_HOST_DEVICE
	static constexpr flatten_axes_t<N> flatten() {
		return {};
	}

	static constexpr all_t _ = {};
}

namespace detail {
	template <typename S, typename = void>
	struct SliceHelper;

	template <>
	struct SliceHelper<placeholder::all_t> {
		static constexpr size_t consume_axes = 1;
		static constexpr size_t produce_axes = 1;

		CUDA_HOST_DEVICE
		static ptrdiff_t call(
				placeholder::all_t,
				const stride_t *old_strides,
				const dim_t *old_dims,
				stride_t *new_strides,
				dim_t *new_dims
		) {
			*new_strides = *old_strides;
			*new_dims = *old_dims;
			return 0;
		}
	};

	template <>
	struct SliceHelper<placeholder::range_t> {
		static constexpr size_t consume_axes = 1;
		static constexpr size_t produce_axes = 1;

		CUDA_HOST_DEVICE
		static ptrdiff_t call(
				placeholder::range_t r,
				const stride_t *old_strides,
				const dim_t *old_dims,
				stride_t *new_strides,
				dim_t *new_dims
		) {
			VF_ASSERT(r.start <= r.end && r.end <= *old_dims);
			*new_strides = *old_strides;
			*new_dims = r.end - r.start;
			return r.start * (*old_strides);
		}
	};

	template <>
	struct SliceHelper<placeholder::new_axis_t> {
		static constexpr size_t consume_axes = 0;
		static constexpr size_t produce_axes = 1;

		CUDA_HOST_DEVICE
		static ptrdiff_t call(
				placeholder::new_axis_t r,
				const stride_t *old_strides,
				const dim_t *old_dims,
				stride_t *new_strides,
				dim_t *new_dims
		) {
			VF_ASSERT(r.size >= 0);
			*new_strides = 0;
			*new_dims = r.size;
			return 0;
		}
	};

	template <size_t N>
	struct SliceHelper<placeholder::flatten_axes_t<N>> {
		static constexpr size_t consume_axes = N;
		static constexpr size_t produce_axes = 1;

		CUDA_HOST_DEVICE
		static ptrdiff_t call(
				placeholder::flatten_axes_t<N> r,
				const stride_t *old_strides,
				const dim_t *old_dims,
				stride_t *new_strides,
				dim_t *new_dims
		) {
			stride_t stride = N  > 0 ? old_strides[N - 1] : 0;
			dim_t dim = 1;
			bool is_contiguous = true;

			for (size_t i = 0; cmp_less(i, N); i++) {
				if (old_strides[N - i -1] != dim * stride) {
					is_contiguous = false;
				}

				dim *= old_dims[N - i - 1];
			}

			if (!is_contiguous) {
				VF_PANIC("cannot flatten axes since they are not contiguous");
			}

			new_strides[0] = stride;
			new_dims[0] = dim;
			return 0;
		}
	};

	template <typename I>
	struct SliceHelper<I, typename std::enable_if<std::is_convertible<I, index_t>::value>::type> {
		static constexpr size_t consume_axes = 1;
		static constexpr size_t produce_axes = 0;

		CUDA_HOST_DEVICE
		static ptrdiff_t call(
				index_t index,
				const stride_t *old_strides,
				const dim_t *old_dims,
				stride_t *new_strides,
				dim_t *new_dims
		) {
			VF_ASSERT(index < *old_dims);
			return index * (*old_strides);
		}
	};

	template <size_t Axis, size_t N, typename... Slices>
	struct SlicesHelper {};

	template <size_t N>
	struct SlicesHelper<N, N> {
		static constexpr size_t new_rank = 0;

		CUDA_HOST_DEVICE
		static ptrdiff_t call(
				const stride_t* old_strides,
				const dim_t *old_dims,
				stride_t* new_strides,
				dim_t *new_dims
		) {
			return 0;
		}
	};

	template <size_t Axis, size_t N, typename S, typename... Slices>
	struct SlicesHelper<Axis, N, S, Slices...> {
		using Helper = SliceHelper<S>;
		using Forward = SlicesHelper<Axis + Helper::consume_axes, N, Slices...>;
		static constexpr size_t new_rank = Forward::new_rank + Helper::produce_axes;

		CUDA_HOST_DEVICE
		static ptrdiff_t call(
				const stride_t* old_strides,
				const dim_t *old_dims,
				stride_t* new_strides,
				dim_t *new_dims,
				S first_slice,
				Slices... rest_slices
		) {
			ptrdiff_t offset = Helper::call(first_slice, old_strides, old_dims, new_strides, new_dims);
			offset += Forward::call(
					old_strides + Helper::consume_axes,
					old_dims + Helper::consume_axes,
					new_strides + Helper::produce_axes,
					new_dims + Helper::produce_axes,
					rest_slices...
			);
			return offset;
		}
	};

	template <typename T, size_t N, MemorySpace space>
	struct SubscriptHelper {
		using type = ViewND<T, N - 1, space>;

		CUDA_HOST_DEVICE
		static type call(ViewND<T, N, space> view, index_t index) {
			return view.drop_axis(0, index);
		}
	};

	template <typename T, MemorySpace space>
	struct SubscriptHelper<T, 0, space> {
		using type = ViewND<T, 0, space>;

		CUDA_HOST_DEVICE
		static type call(ViewND<T, 0, space> view, index_t index) {
			VF_PANIC("index out of bounds");
		}
	};

	template <typename T>
	struct SubscriptHelper<T, 1, MemorySpace::Host> {
		using type = T&;

		static type call(ViewND<T, 1, MemorySpace::Host> view, index_t index) {
			return view.access({index});
		}
	};

	template <typename T>
	struct SubscriptHelper<T, 1, MemorySpace::Device> {
		using type = T&;

		CUDA_DEVICE
		static type call(ViewND<T, 1, MemorySpace::Device> view, index_t index) {
			return view.access({index});
		}
	};
}

template <typename Derived, typename T, size_t N, MemorySpace space>
class StridedContainer: public ExpressionOps<Derived, T, N, space> {
public:
	using base_type = ExpressionOps<Derived, T, N, space>;
	using strides_type = fixed_vector<stride_t, N>;

public:
	using base_type::derived;

	CUDA_HOST_DEVICE
	bool is_contiguous() const {
		for (size_t i = 1; cmp_less(i, N); i++) {
			if (derived().stride(i - 1) != derived().stride(i) * derived().size(i)) {
				return false;
			}
		}

		return N == 0 || derived().stride(N - 1) == 1;
	}

	CUDA_HOST_DEVICE
	T* begin() {
		VF_ASSERT(is_contiguous());
		return derived().data();
	}

	CUDA_HOST_DEVICE
	T* end() {
		VF_ASSERT(is_contiguous());
		return derived().data() + derived().numel();
	}

	CUDA_HOST_DEVICE
	const T* begin() const {
		VF_ASSERT(is_contiguous());
		return derived().data();
	}

	CUDA_HOST_DEVICE
	const T* end() const {
		VF_ASSERT(is_contiguous());
		return derived().data() + derived().numel();
	}

	CUDA_HOST_DEVICE
	strides_type strides() const {
		strides_type result;
		for (size_t i = 0; (int) i < (int) N; i++) {
			result[i] = derived().stride(i);
		}
		return result;
	}

	CUDA_HOST_DEVICE
	stride_t ndindex_to_offset(ndindex_t<N> ndindex) const {
		stride_t result = 0;

		for (size_t i = 0; (int) i < (int) N; i++) {
			result += derived().stride(i) * ndindex[i];
		}

		return result;
	}

	CUDA_HOST_DEVICE
	T* offset(ndindex_t<N> ndindex) {
		VF_DEBUG_ASSERT(this->in_bounds(ndindex));
		return derived().data() + ndindex_to_offset(ndindex);
	}

	CUDA_HOST_DEVICE
	const T* offset(ndindex_t<N> ndindex) const {
		VF_DEBUG_ASSERT(this->in_bounds(ndindex));
		return derived().data() + ndindex_to_offset(ndindex);
	}

	CUDA_HOST_DEVICE
	ViewND<T, N, space> view() {
		return {derived().data(), this->shape(), strides()};
	}

	CUDA_HOST_DEVICE
	ViewND<const T, N, space> view() const {
		return cview();
	}

	CUDA_HOST_DEVICE
	ViewND<const T, N, space> cview() const {
		return {derived().data(), this->shape(), strides()};
	}

	template <typename First, typename... Rest>
	CUDA_HOST_DEVICE
	ViewND<T, detail::SlicesHelper<0, N, First, Rest...>::new_rank, space> view(First first, Rest... rest) {
		using Helper = detail::SlicesHelper<0, N, First, Rest...>;
		fixed_vector<stride_t, Helper::new_rank> new_strides;
		fixed_vector<dim_t, Helper::new_rank> new_sizes;

		ptrdiff_t offset = Helper::call(
				derived().strides().begin(),
				derived().shape().begin(),
				new_strides.begin(),
				new_sizes.begin(),
				first,
				rest...
		);

		return ViewND<T, Helper::new_rank, space>(derived().data() + offset, new_sizes, new_strides);
	}

	template <typename First, typename... Rest>
	CUDA_HOST_DEVICE
	ViewND<const T, detail::SlicesHelper<0, N, First, Rest...>::new_rank, space> view(First first, Rest... rest) const {
		return view().view(first, rest...);
	}

	template <typename First, typename... Rest>
	CUDA_HOST_DEVICE
		ViewND<const T, detail::SlicesHelper<0, N, First, Rest...>::rank, space> cview(First first, Rest... rest) const {
		return view();
	}

	CUDA_HOST_DEVICE
	ViewND<T, N, space> limit_axis(size_t axis, index_t begin, index_t end) {
		VF_ASSERT(cmp_less(axis, N) && begin <= end && end <= derived().size(axis));
		fixed_vector<stride_t, N> new_strides = this->strides();
		fixed_vector<dim_t, N> new_dims = this->shape();

		stride_t offset = begin * new_strides[axis];
		new_dims[axis] = end - begin;

		return ViewND<T, N, space>(derived().data() + offset, new_dims, new_strides);
	}

	CUDA_HOST_DEVICE
	ViewND<T, (N > 0 ? N - 1 : 0), space> drop_axis(size_t axis, index_t index = 0) {
		VF_ASSERT(cmp_less(axis, N) && index < derived().size(axis));
		constexpr size_t new_rank = (N > 0 ? N - 1 : 0);
		fixed_vector<stride_t, new_rank> new_strides;
		fixed_vector<dim_t, new_rank> new_sizes;

		for (size_t i = 0; i < axis; i++) {
			new_strides[i] = derived().stride(i);
			new_sizes[i] = derived().size(i);
		}
		for (size_t i = axis + 1; cmp_less(i, N); i++) {
			new_strides[i - 1] = derived().stride(i);
			new_sizes[i - 1] = derived().size(i);
		}

		stride_t offset = index * derived().stride(axis);
		return ViewND<T, new_rank, space>(derived().data() + offset, new_sizes, new_strides);
	}

	CUDA_HOST_DEVICE
	ViewND<T, N + 1, space> insert_axis(size_t axis, index_t length = 1) {
		VF_ASSERT(axis <= N && length >= 0);
		fixed_vector<stride_t, N + 1> new_strides;
		fixed_vector<dim_t, N + 1> new_sizes;

		for (size_t i = 0; i < axis; i++) {
			new_strides[i] = derived().stride(i);
			new_sizes[i] = derived().size(i);
		}

		new_strides[axis] = 0;
		new_sizes[axis] = length;

		for (size_t i = axis; cmp_less(i, N); i++) {
			new_strides[i + 1] = derived().stride(i);
			new_sizes[i + 1] = derived().size(i);
		}

		return ViewND<T, N + 1, space>(derived().data(), new_sizes, new_strides);
	}

	CUDA_HOST_DEVICE
	ViewND<T, N, space> reorder_axes(fixed_vector<size_t, N> permutation) {
		bool is_permutation = true;
		for (size_t i = 0; cmp_less(i, N); i++) {
			is_permutation &= permutation[i] < N;

			for (size_t j = 0; j < i; j++) {
				is_permutation &= permutation[i] != permutation[j];
			}
		}
		VF_ASSERT(is_permutation);

		fixed_vector<stride_t, N> new_strides;
		fixed_vector<dim_t, N> new_sizes;
		for (size_t i = 0; cmp_less(i, N); i++) {
			new_strides[i] = derived().stride(permutation[i]);
			new_sizes[i] = derived().size(permutation[i]);
		}

		return ViewND<T, N, space>(derived().data(), new_sizes, new_strides);
	}

	CUDA_HOST_DEVICE
	ViewND<T, N, space> move_axis(size_t axis, size_t new_position) {
		VF_ASSERT(cmp_less(axis, N) && new_position < N);
		fixed_vector<size_t, N> order;

		for (size_t i = 0; i < N; i++) {
			order[i] = i;
		}

		if (new_position < axis) {
			order[new_position] = axis;

			for (size_t i = new_position; i < axis; i++) {
				order[i + 1] = i;
			}
		} else if (new_position > axis) {
			for (size_t i = axis; i < new_position; i++) {
				order[i] = i + 1;
			}

			order[new_position] = axis;
		}

		return reorder_axes(order);
	}

	CUDA_HOST_DEVICE
	ViewND<T, 1, space> diagonal() {
		VF_ASSERT(derived().is_square());
		index_t diag_size = derived().numel();
		index_t diag_stride = 0;

		for (size_t i = 0; cmp_less(i, N); i++) {
			diag_stride += derived().stride(i);
			diag_size = std::min(diag_size, derived().size(i));
		}

		return ViewND<T, 1, space>(derived().data(), {diag_size}, {diag_stride});
	}

	CUDA_HOST_DEVICE
	ViewND<const T, N, space> limit_axis(size_t axis, index_t begin, index_t end) const {
		return view().limit_axis(axis, begin, end);
	}

	CUDA_HOST_DEVICE
	ViewND<const T, (N > 0 ? N - 1 : 0), space> drop_axis(size_t axis, index_t index = 0) const {
		return view().drop_axis(axis, index);
	}

	CUDA_HOST_DEVICE
	ViewND<const T, N + 1, space> insert_axis(size_t axis, index_t length = 1) const {
		return view().insert_axis(axis, length);
	}

	CUDA_HOST_DEVICE
	ViewND<const T, N, space> reorder_axes(fixed_vector<size_t, N> permutation) const {
		return view().reorder_axes(permutation);
	}

	CUDA_HOST_DEVICE
	ViewND<const T, N, space> move_axis(size_t axis, size_t new_position) const {
		return view().move_axis(axis, new_position);
	}

	CUDA_HOST_DEVICE
	ViewND<const T, 1, space> diagonal() const {
		return view().diagonal();
	}
};


template <typename Derived, typename T, size_t N, MemorySpace space>
class StridedContainerOps: public StridedContainer<Derived, T, N, space> {};

#if !CUDA_RTC
template <typename Derived, typename T, size_t N>
class StridedContainerOps<Derived, T, N, MemorySpace::Host>: public StridedContainer<Derived, T, N, MemorySpace::Host> {
	using base_type = StridedContainer<Derived, T, N, MemorySpace::Host>;

public:
	using base_type::derived;

	VF_INLINE
	T& access(ndindex_t<N> ndindex) {
		return *derived().offset(ndindex);
	}

	VF_INLINE
	const T& access(ndindex_t<N> ndindex) const {
		return *derived().offset(ndindex);
	}

	template <typename... Is>
	VF_INLINE
	typename std::enable_if<is_ndindex<N, Is...>, T&>::type
	operator()(Is... indices) {
		return access({indices...});
	}

	template <typename... Is>
	VF_INLINE
	typename std::enable_if<is_ndindex<N, Is...>, const T&>::type
	operator()(Is... indices) const {
		return access({indices...});
	}

	VF_INLINE
	typename detail::SubscriptHelper<T, N, MemorySpace::Host>::type operator[](index_t index) {
		return detail::SubscriptHelper<T, N, MemorySpace::Host>::call(derived().view(), index);
	}

	VF_INLINE
	typename detail::SubscriptHelper<const T, N, MemorySpace::Host>::type operator[](index_t index) const {
		return detail::SubscriptHelper<const T, N, MemorySpace::Host>::call(derived().view(), index);
	}

	template <typename D2, typename T2>
	CUDA_HOST_DEVICE
	void copy_from(const Expression<D2, T2, N, MemorySpace::Host>& that) {
#if CUDA_IS_HOST
		Derived& lhs = this->derived();
		const D2& rhs = that.derived();
		VF_ASSERT(lhs.shape() == rhs.shape());

		iterate_nd(lhs.shape(), [&](auto ndindex) {
			lhs.access(ndindex) = rhs.access(ndindex);
		});
#else
		VF_PANIC("copy not supported on host");
#endif
	}
};
#endif

template <typename Derived, typename T, size_t N>
class StridedContainerOps<Derived, T, N, MemorySpace::Device>: public StridedContainer<Derived, T, N, MemorySpace::Device> {
	using base_type = StridedContainer<Derived, T, N, MemorySpace::Device>;

public:
	using base_type::derived;

	CUDA_DEVICE
	T& access(ndindex_t<N> ndindex) {
		return *derived().offset(ndindex);
	}

	CUDA_DEVICE
	const T& access(ndindex_t<N> ndindex) const {
		return *derived().offset(ndindex);
	}

	template <typename... Is>
	CUDA_DEVICE
	typename std::enable_if<is_ndindex<N, Is...>, T&>::type
	operator()(Is... indices) {
		return access({indices...});
	}

	template <typename... Is>
	CUDA_DEVICE
	typename std::enable_if<is_ndindex<N, Is...>, const T&>::type
	operator()(Is... indices) const {
		return access({indices...});
	}

	CUDA_DEVICE
	typename detail::SubscriptHelper<T, N, MemorySpace::Device>::type operator[](index_t index) {
		return detail::SubscriptHelper<T, N, MemorySpace::Device>::call(derived().view(), index);
	}

	CUDA_DEVICE
	typename detail::SubscriptHelper<const T, N, MemorySpace::Device>::type operator[](index_t index) const {
		return detail::SubscriptHelper<const T, N, MemorySpace::Device>::call(derived().view(), index);
	}

	CUDA_HOST_DEVICE
	Accessor<T, N> accessor() {
		return {derived().data(), derived().strides().data()};
	}

	CUDA_HOST_DEVICE
	Accessor<const T, N> accessor() const {
		return {derived().data(), derived().strides().data()};
	}

	CUDA_HOST_DEVICE
	Accessor<const T, N> caccessor() const {
		return accessor();
	}

	CUDA_HOST_DEVICE
	operator Accessor<T, N>() {
		return accessor();
	}

	CUDA_HOST_DEVICE
	operator Accessor<const T, N>() const {
		return accessor();
	}

	template <typename D2, typename T2>
	CUDA_HOST_DEVICE
	void copy_from(const Expression<D2, T2, N, MemorySpace::Device>& that) {
#if CUDA_IS_DEVICE
		Derived& lhs = this->derived();
		const D2& rhs = that.derived();
		VF_ASSERT(lhs.shape() == rhs.shape());

		iterate_nd(lhs.shape(), [&](auto ndindex) {
			lhs.access(ndindex) = rhs.access(ndindex);
		});
#else
		VF_PANIC("copy not supported on device");
#endif
	}
};

template <typename T, size_t N, MemorySpace space>
class ViewND: public StridedContainerOps<ViewND<T, N, space>, T, N, space> {
public:
	using base_type = StridedContainerOps<ViewND<T, N, space>, T, N, space>;
	using typename base_type::strides_type;
	using typename base_type::shape_type;

	CUDA_HOST_DEVICE
	ViewND(T* ptr = nullptr): data_(ptr) {
	}

	CUDA_HOST_DEVICE
	ViewND(T* ptr, shape_type shape, strides_type strides):
			data_(ptr), sizes_(shape), strides_(strides) {
	}

	template <typename D, typename T2, typename = typename std::enable_if<std::is_convertible<T2*, T*>::value>::type>
	CUDA_HOST_DEVICE
	ViewND(StridedContainerOps<D, T2, N, space>& base): ViewND(base.view()) {
	}

	template <typename D, typename T2, typename = typename std::enable_if<std::is_convertible<const T2*, T*>::value>::type>
	CUDA_HOST_DEVICE
	ViewND(const StridedContainerOps<D, T2, N, space>& base): ViewND(base.view()) {
	}

	ViewND(const ViewND& base) = default;
	ViewND(ViewND&& base) = default;

	// Assigning a view to another view copies the data.
	CUDA_HOST_DEVICE
	ViewND& operator=(const ViewND& rhs) {
		this->copy_from(rhs);
		return *this;
	}

	template <typename D2, typename T2>
	CUDA_HOST_DEVICE
	ViewND& operator=(const Expression<D2, T2, N, space>& rhs) {
		this->copy_from(rhs.derived());
		return *this;
	}

	CUDA_HOST_DEVICE
	stride_t stride(size_t axis) const {
		VF_ASSERT(cmp_less(axis, N));
		return strides_[axis];
	}

	CUDA_HOST_DEVICE
	dim_t size(size_t axis) const {
		VF_ASSERT(cmp_less(axis, N));
		return sizes_[axis];
	}

	CUDA_HOST_DEVICE
	T* data() const {
		return data_;
	}

private:
	T* const data_ = nullptr;
	shape_type sizes_ {};
	strides_type strides_ {};
};

#define IMPL_VIEW_ALIASES_FOR_RANK(N) \
	template <typename T, MemorySpace space = MemorySpace::Host> using View ## N ## D = ViewND<const T, N, space>; \
	template <typename T, MemorySpace space = MemorySpace::Host> using WriteView ## N ## D = ViewND<T, N, space>; \
	template <typename T> using CudaView ## N ## D = ViewND<const T, N, MemorySpace::Device>; \
	template <typename T> using CudaWriteView ## N ## D = ViewND<T, N, MemorySpace::Device>;

IMPL_VIEW_ALIASES_FOR_RANK(0)
IMPL_VIEW_ALIASES_FOR_RANK(1)
IMPL_VIEW_ALIASES_FOR_RANK(2)
IMPL_VIEW_ALIASES_FOR_RANK(3)
IMPL_VIEW_ALIASES_FOR_RANK(4)
IMPL_VIEW_ALIASES_FOR_RANK(5)
IMPL_VIEW_ALIASES_FOR_RANK(6)
IMPL_VIEW_ALIASES_FOR_RANK(7)
IMPL_VIEW_ALIASES_FOR_RANK(8)
#undef IMPL_VIEW_ALIASES_FOR_RANK
