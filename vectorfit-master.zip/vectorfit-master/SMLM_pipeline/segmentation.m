% Matlab segmentation for single emitters in SMLM data 
% Based on Huanget al. (2011)
% 
% Fang Huang, Samantha L. Schwartz, Jason M. Byars, and Keith A. Lidke, 
% "Simultaneous multiple-emitter fitting for single molecule super-resolution 
% imaging," Biomed. Opt. Express 2, 1377-1393 (2011)
% -------------------------------------------------------------------------

clear all
close all

t_all = tic;

params = set_parameters_microtubules_3D;

input_path = 'data/0_raw_data/microtubules_3D_data0001.tif';

output_path = 'data/1_segmentation/';

gain = params.gain;
offset = params.offset;

sigma_psf = params.lambda/(4*params.NA*params.pixelsize);
segmentation_ROI_thr = params.segmentation_ROI_thr;
unif1=round_odd(2*sigma_psf+1);
unif2=round_odd(2*unif1);
maxf3=round(5*sigma_psf);

roisize = params.Mx;
Mz = params.Mz;
ROI_pad = (roisize-1)/2;
imgsizeX = params.imgSizeX;
imgsizeY = params.imgSizeY;
nr_of_cutoff_frames = params.nr_of_cutoff_frames;

nr_of_parallel_workers = params.nr_of_parallel_workers;

% Set up parallel pool
if isempty(gcp('nocreate'))
    parpool('Threads', nr_of_parallel_workers);
end

switch params.datatype
    case{'tif', 'tifVolume'} % assumes a folder with multiple .tif files
        all_input_files = dir(input_path);
        nr_of_datasets = size(all_input_files,1);
        fprintf('Found %i files\n',nr_of_datasets);
    case('h5') % assumes a single .h5 file with multiple datasets
        info = h5info(input_path);
        all_datasets = info.Groups.Groups.Groups;
        nr_of_datasets = length(all_datasets);
        fprintf('Found %i datasets\n',nr_of_datasets);
    otherwise
        error('params.datatype is not correct')
end

tic;
framecount_global = 0;
jcfg_global = 0; % Counts spots to assign ID

for dataset_i=1:nr_of_datasets

    switch params.datatype
        case('tif') % assumes a folder with multiple .tif files
            dataset_name = all_input_files(dataset_i).name; 
            foldername = all_input_files(dataset_i).folder;
            input_filename = fullfile(foldername, dataset_name);
            fprintf('Input file = %s\n',dataset_name);
            InfoImage = imfinfo(input_filename);
            Nframes = length(InfoImage);
            fprintf('Found %i frames\n',Nframes);
            %Nframes = 200; % To load a smaller fraction of the data
            fprintf('Load %i frames\n',Nframes);
            t_load = tic;
            allframes = double(LoadTiff(input_filename, Nframes));
            fprintf('Finished loading %i frames\n',Nframes)
            toc(t_load)
        case('tifVolume')
            dataset_name = all_input_files(dataset_i).name; 
            foldername = all_input_files(dataset_i).folder;
            input_filename = fullfile(foldername, dataset_name);
            fprintf('Input file = %s\n',dataset_name);
            %start = 18000;
            %Nframes = 2000;
            fprintf('Loading %i frames\n',Nframes);
            allframes = tiffreadVolume(input_filename,'PixelRegion',{[1 params.imgSizeX] [1 params.imgSizeY] [start+1 start+Nframes]});
        case('h5') % assumes a single .h5 file with multiple datasets
            name_path = all_datasets(dataset_i).Name;
            dataset_name = all_datasets(dataset_i).Datasets.Name;
            dataset_name_full = strcat(name_path,'/',dataset_name);
            fprintf('\nLoading dataset %i: %s \n',dataset_i, dataset_name)
            t_load = tic;
            allframes = h5read(input_path,dataset_name_full);
            Nframes = size(allframes,3);
            fprintf('Finished loading %i frames\n',Nframes);
            toc(t_load)

        otherwise
            error('params.datatype is not correct')
    end

    t_parfor = tic;
    allspots_cell = cell(Nframes,1);
    roixy_cell = cell(Nframes,1);
    framelist_cell = cell(Nframes,1);

    f_add = 0;
    if dataset_i == 1
        fprintf('Skip first %i frames\n',nr_of_cutoff_frames)
        f_add = nr_of_cutoff_frames;
    end

    allframes = cast(allframes,'double');
    allframes = (allframes - offset)./gain;
    allframes(allframes<=0) = 1e-3;

    
    parfor f = 1+f_add:Nframes
    %for f = 1+f_add:Nframes
        frame = allframes(:,:,f);
       
        box_width_x = size(frame,1);
        box_width_y = size(frame,2);
        A1 = imboxfilt(frame,unif1) - imboxfilt(frame,unif2);
        A2 = imdilate(A1,ones(maxf3,maxf3));
        A3 = (A1 == A2) & (A1 > segmentation_ROI_thr); 
        ind_uf = find(A3);

        % Find roixy
        nrois_all = length(ind_uf);
        roixy_frame_unfiltered = zeros(2,nrois_all);
        for ii = 1:nrois_all
            [idx_uf, idy_uf] = ind2sub(size(frame), ind_uf(ii));
            roixy_frame_unfiltered(:,ii) = [idx_uf idy_uf]';
        end

        % Remove overlapping ROIs
        mindist = ceil(roisize/2);
        distances = squareform(pdist(roixy_frame_unfiltered'));
        [distances_small_x,distances_small_y] = ind2sub([nrois_all nrois_all],find(distances<=mindist & distances>0));
        
        remove_indices = [-1];
        for i = 1:numel(distances_small_y)
            idy = distances_small_y(i);
            idx = distances_small_x(i);
            if ~ismember(remove_indices,idy)
                remove_indices = cat(1,remove_indices,idx);
            end
        end

        %%%% For microtubule data, discard hot pixels in first and last rows:
        remove_extra = find(roixy_frame_unfiltered(2,:)<=floor(params.My/2)+1 | roixy_frame_unfiltered(2,:) > params.imgSizeY-floor(params.My/2)-1)';
        remove_indices = cat(1,remove_indices,remove_extra);
        %%%%

        remove_indices = unique(remove_indices(2:end));
        indices_keep = setdiff(1:nrois_all,remove_indices);
        ind = ind_uf(indices_keep);
        roixy_frame = roixy_frame_unfiltered(:,indices_keep);

        % Cut out filtered ROIs
        nrois = length(ind);
        allspots_frame = zeros(roisize,roisize,1,nrois);
        framelist_temp = (framecount_global+f)*ones(1,nrois);
        for ii = 1:nrois
            [idx, idy] = ind2sub(size(frame), ind(ii));
            roixy_frame(:,ii) = [idx idy]';
            [idx_ROI, idy_ROI] = ROI_coords(idx, idy, box_width_x,box_width_y, ROI_pad);

            ROI = frame(min(idx_ROI) : max(idx_ROI), min(idy_ROI) : max(idy_ROI));
            allspots_frame(:,:,:,ii) = ROI;
        end

        allspots_cell{f} = allspots_frame;
        roixy_cell{f} = roixy_frame;
        framelist_cell{f} = framelist_temp; 
    end

    % create full lists
    allspots = cat(4,allspots_cell{:});
    roixy = cat(2,roixy_cell{:});
    framelist = cat(2,framelist_cell{:});

    % Create list of IDs
    Ncfg_total = size(roixy,2);
    ID = 1+jcfg_global:Ncfg_total+jcfg_global;
    jcfg_global = jcfg_global + Ncfg_total;
    
    framecount_global = framecount_global + Nframes;
    params.Ncfg_total = size(allspots,4);
    fprintf('Found %i ROIs in file %i\n',Ncfg_total, dataset_i);   
    [~,filename,~]=fileparts(dataset_name); 
    output_filename = strcat(output_path,'segmentation_',filename,'.mat');
    save(output_filename,'allspots','ID','roixy','framelist','params','-v7.3');
    fprintf('Saved segmentation in %s\n',output_filename);   
    toc(t_parfor)
end

fprintf('\nFinished segmentation\n');
toc(t_all)

% delete parpool
delete(gcp('nocreate'));

if params.show_plots

    % Show frames
    dipshow(allframes,'lin')
    diptruesize(6e4/params.imgSizeX)

    % Can be used to determine threshold: selected points are A1 > segmentation_ROI_thr
    % use for instead of parfor to access A1
    % acces A1 of one frame for plot
    frame = allframes(:,3:end-2,floor(Nframes/2));  
    box_width_x = size(frame,1);
    box_width_y = size(frame,2);
    A1 = imboxfilt(frame,unif1) - imboxfilt(frame,unif2);
    
    figure
    surf(A1);
    ax = gca;
    ax.FontSize = 16;
    xlabel('x (pixels)')
    ylabel('y (pixels)')
    zlabel('segmentation threshold')
    title('Determine segmentation threshold')
    shading interp;

    % Show all ROI centers
    allroi_centers = zeros(imgsizeX,imgsizeY);
    for i = 1:size(roixy,2)
        allroi_centers(roixy(1,i),roixy(2,i)) = 1;
    end
    dipshow(allroi_centers,'lin')
    diptruesize(6e4/params.imgSizeX)

    % Show all spots
    dipshow(allspots,'lin')
    diptruesize(4e4/params.Mx)
    colormap parula


end