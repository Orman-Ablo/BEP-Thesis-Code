//This function sets all parameters for vectorial PSF calculations

#pragma once

#include <complex>
#include <tgmath.h>
#include <cstring>
#include <vector>

#include "cuda/macros.cuh"
#include "array/fixed_vector.h"
#include "array/host_array.h"
#include <thread>


#define EPS	 std::numeric_limits<double>::epsilon();

struct FitModelEnum {
	using value_type = uint8_t;
	static constexpr value_type HAS_Z = 1 << 0;
	static constexpr value_type HAS_AZIM = 1 << 1;
	static constexpr value_type HAS_POLA = 1 << 2;
	static constexpr value_type HAS_AZIM_POLA = HAS_AZIM | HAS_POLA;
	static constexpr value_type HAS_DIFFUSION = 1 << 3;
	static constexpr value_type HAS_ABERR = 1 << 4;
	static constexpr value_type HAS_CONST_ABERR = 1 << 5;

	enum Types: uint8_t {
		xy = 0,
		xy_constaberrations = xy | HAS_CONST_ABERR,
		xy_azim = xy | HAS_AZIM,
		xy_azim_pola = xy | HAS_AZIM_POLA,
		xy_azim_diffusion = xy_azim | HAS_DIFFUSION,
		xy_azim_pola_diffusion = xy_azim_pola | HAS_DIFFUSION,
		xyz = HAS_Z,
		xyz_constaberrations = xyz | HAS_CONST_ABERR,
		xyz_aberrations = xyz | HAS_ABERR,
		xyz_azim_pola = xyz | HAS_AZIM_POLA,
		xyz_azim_pola_aberrations = xyz_azim_pola | HAS_ABERR,
		xyz_azim_pola_diffusion = xyz_azim_pola | HAS_DIFFUSION,
		xyz_azim_pola_diffusion_aberrations = xyz_azim_pola_diffusion | HAS_ABERR,
	};

	CUDA_HOST_DEVICE
	constexpr FitModelEnum(value_type v = 0, int naberr = 0): value_(v), naberr_(naberr) {}

	CUDA_HOST_DEVICE
	constexpr bool has_xy() const {
		return true;
	}

	CUDA_HOST_DEVICE
	constexpr bool has_z() const {
		return (value_ & HAS_Z) == HAS_Z;
	}

	CUDA_HOST_DEVICE
	constexpr bool has_azim() const {
		return (value_ & HAS_AZIM) == HAS_AZIM;
	}

	CUDA_HOST_DEVICE
	constexpr bool has_pola() const {
		return (value_ & HAS_POLA) == HAS_POLA;
	}

	CUDA_HOST_DEVICE
	constexpr bool has_azim_pola() const {
		return (value_ & HAS_AZIM_POLA) == HAS_AZIM_POLA;
	}

	CUDA_HOST_DEVICE
	constexpr bool has_diffusion() const {
		return (value_ & HAS_DIFFUSION) == HAS_DIFFUSION;
	}

	// Returns whether the model must take aberrations
	// into account, either fitted or constant (externally computed).
	CUDA_HOST_DEVICE
	constexpr bool has_aberrations() const {
		return (value_ & (HAS_ABERR | HAS_CONST_ABERR));
	}

	// Returns whether the model must take aberrations
	// into account that are computed externally and are
	// kept constant between model interations.
	CUDA_HOST_DEVICE
	constexpr bool has_const_aberrations() const {
		return (value_ & (HAS_CONST_ABERR));
	}

	// Returns whether the model must fit aberrations.
	CUDA_HOST_DEVICE
	constexpr bool has_fitted_aberrations() const {
		return (value_ & (HAS_ABERR));
	}

	CUDA_HOST_DEVICE
	constexpr int offset_x() const {
		return 0;
	}

	CUDA_HOST_DEVICE
	constexpr int offset_y() const {
		return 1;
	}

	CUDA_HOST_DEVICE
	constexpr int offset_z() const {
		return 2;
	}

	CUDA_HOST_DEVICE
	constexpr int offset_nph() const {
		return offset_z() + has_z();
	}

	CUDA_HOST_DEVICE
	constexpr int offset_nbg() const {
		return offset_nph() + 1;
	}

	CUDA_HOST_DEVICE
	constexpr int offset_azim() const {
		return offset_nbg() + 1;
	}

	CUDA_HOST_DEVICE
	constexpr int offset_pola() const {
		return offset_azim() + has_azim();
	}

	CUDA_HOST_DEVICE
	constexpr int offset_diffusion() const {
		return offset_pola() + has_pola();
	}

	CUDA_HOST_DEVICE
	constexpr int offset_aberrations() const {
		return offset_diffusion() + has_diffusion();
	}

	CUDA_HOST_DEVICE
	constexpr int num_aberrations() const {
		return has_aberrations() ? naberr_ : 0;
	}

	CUDA_HOST_DEVICE
	constexpr int num_fitted_aberrations() const {
		return has_fitted_aberrations() ? num_aberrations() : 0;
	}

	CUDA_HOST_DEVICE
	constexpr operator value_type() const {
		return value_;
	}

	// Number of parameter that are fitted
	CUDA_HOST_DEVICE
	constexpr int num_parameters() const {
		// always: x, y, Nph, Nbg
		return 4 + has_z() + has_azim() + has_pola() + has_diffusion()
			+ num_fitted_aberrations();
	}

	// Size of theta vector:
	// fitted parameters + possible const aberration coefficients
	CUDA_HOST_DEVICE
	constexpr int theta_size() const {
		return num_parameters() +
			+ (has_const_aberrations() ? num_aberrations() : 0);
	}

/*
	bool operator==(const value_type& that) const {
		return value_ == that;
	}

	bool operator!=(const value_type& that) const {
		return !(*this == that);
	}

	bool operator==(const FitModelEnum& that) const {
		return this.value_ == that.value_;
	}

	bool operator!=(const FitModelEnum& that) const {
		return !(*this == that);
	}
*/

	std::string to_string() const {
		std::string v = "xy";
		if (has_z()) v += "z";
		if (has_azim()) v += "_azim";
		if (has_pola()) v += "_pola";
		if (has_diffusion()) v += "_diffusion";

		if (has_const_aberrations()) v += "_constaberrations";
		else if (has_aberrations()) v += "_aberrations";

		return v;
	}

public:
	value_type value_ = 0;
	int naberr_;
};

CUDA_DEFINE_COPYABLE(FitModelEnum)

enum struct DoeTypeEnum {
	vortex,
	none
};

enum struct DipoleTypeEnum {
	free,
	fixed,
	diffusion
};

enum struct ExcitationEnum {
	constant,
	zstack
};

enum struct ZTypeEnum {
	stage,
	medium
};

enum struct InitializationMethod {
	phasor,
	centroid,
};

struct SampleParams {
	const std::string SampleType = "simdata";//exp,bead,simdata,simulate
};

struct PupilParams {
	//optical parameters
	double NA = 1.33;//1.47
	double RefMed = 1.33;
	double RefCov = 1.52;//1.523
	double RefImm = 1.52;//1.518
	double RefImmNom = RefCov;
	double Lambda = 550;//597.5
	double LambdaCentral = 550; //597.5
	fixed_vector<double, 2> LambdaSpread = { 550, 550 };
	double default_pupil_size() const { return NA / Lambda; }
	double PupilSize = default_pupil_size();

	int NPupil = 56;
	double PixelSize = 80.0; //65.0
	double SamplingDistance = PixelSize;
	double Fwd = 140000.0; //120000
	double Depth = 0;
	fixed_vector<double, 2> ZSpread = { -1000,1000 };
	double zstage = 0.0; //for aberrations

	//parameters needed for fixed dipole PSF only : emitter / absorber dipole orientation
	//(characterized by angles pola and azim)
	//Diffusion coeffecient parameter
	//SLM (DOE) parameters
	int RingRadius = 1;
	DoeTypeEnum DoeType = DoeTypeEnum::none;// "vortex","none", ..
	int DoeLevels = 64;
	int DoePhaseDepth = 593;
	int DoeVortexFlip = 1;

	static constexpr int MaxNaberr = 6;
	double ZoneFunction[MaxNaberr][3] = {};

	double AberrationOrders[MaxNaberr][2] = {
			{2,-2},
			{2, 0},
			{2, 2},
			{3,-1},
			{3, 1},
			{4, 0} };// n + | m|<=6

	double InitialAberrations[MaxNaberr][3] = {
			{2,-2, 0},
			{2, 0, 0},
			{2, 2, 0},
			{3,-1, 0},
			{3, 1, 0},
			{4, 0, 0} };// n + | m|<=6
};

struct FitParams: PupilParams {
	// initialization
	InitializationMethod initialization = InitializationMethod::centroid;

	// Global image parameters
	//int imgSizeX = 2048;
	//int imgSizeY = 2048;
    int imgSizeX = 1024;
	int imgSizeY = 1024;

	//Fitting Parameters
	int NiterMax = 30;
	double Tollim = 1.0e-6;
	double Varfit = 0.0;

	int Mx = 9;
	int default_my() const { return Mx; }
	int My = default_my();
	int Mz = 1;
	fixed_vector<double, 2> ZRange = { -1000,1000 };

	double default_x_range() const { return PixelSize * Mx / 2; }
	double XRange = default_x_range();
	double default_y_range() const { return PixelSize * My / 2; }
	double YRange = default_y_range();

	const FitModelEnum FitModel;// xyz_azim_pola_diffusion;
	ZTypeEnum ZType = ZTypeEnum::stage;
	DipoleTypeEnum DipoleType = DipoleTypeEnum::free; //"free", "fixed","diffusion"
	ExcitationEnum Excitation = ExcitationEnum::constant;
	bool psf_blur = false;

	//Fit model parameters : signal photon count, background photons / pixel,
	//read noise variance for sCMOS camera's, fit model parameters depending on model
	double ReadNoiseStd = 0.0;
	double ReadNoiseVariance = 0.0;
	double Alpha = 0.0;
	double Beta = 0.0;

	// FIXME: Can this be removed?
	std::vector< std::vector<double> > NatPredictions;  //[Ncfg]

	static FitModelEnum get_fitmodel_from_string(const std::string& model);

	static FitParams parse_file(const std::string& file_path);

	FitParams(FitModelEnum f = FitModelEnum::xy):
		FitModel(f) {
		//Sanity check on position of emitter with respect to the coverslip
		if (ZType == ZTypeEnum::stage)
		{
			// FIXME: These appear to be unused?
//			ZCheck = Depth + ZEmit;

			if (ZType == ZTypeEnum::medium)
			{
//				Zmin = ZRange[0];
//				ZCheck = Zmin + Depth + ZEmit;
			}
		}

		//void setZoneFunandAberrations()
		for (int ii = 0; ii < MaxNaberr; ii++ )
		{
			InitialAberrations[ii][2] *= LambdaCentral;
		}

		memcpy(&ZoneFunction, &InitialAberrations, sizeof(InitialAberrations));
	}

	int Notfx = 64;
	int Notfy = Notfx;
	int Notfz = FitModel.has_z() ? 48 : 1;
	int Mpsfx = 129;
	int Mpsfy = Mpsfx;
	int Mpsfz = FitModel.has_z() ? Mpsfx : 1;
	double default_psf_sampling_distance() const { return 0.25*(Lambda/NA/4); }
	double default_psf_sampling_distance_z() const { return 0.1*(Lambda/NA/4); }
	double default_psf_x_range() const { return default_psf_sampling_distance()*Mpsfx/2; }
	double PsfXRange = default_psf_x_range();
	double default_psf_y_range() const { return default_psf_sampling_distance()*Mpsfy/2; }
	double PsfYRange = default_psf_y_range();
	double default_psf_z_range() const { return default_psf_sampling_distance_z()*Mpsfz/2; }
	double PsfZRange = default_psf_z_range();

	bool FlagOTF = false;
	int OTFGridSizeX = 10;
	int OTFGridSizeY = 10;

	// Number of threads for parallel computations on the CPU.
	int NumThreads = std::thread::hardware_concurrency(); // Or omp_get_max_threads()?
};


struct SpotParameters {
	constexpr static double default_pola = 45.0 * M_PI / 180;
	constexpr static double default_azim = 0;

	CUDA_HOST_DEVICE
	static double default_g2()
	{
		constexpr static double WellDepth = 2.2204460492503131e-16;// 1.0/numeric_limits<double>::epsilon();  //machine epsilon
		return (3 + pow(WellDepth, 2) - 3 * (WellDepth / tanh(WellDepth))) / pow(WellDepth, 2);
	}

	static SpotParameters from_theta(const FitModelEnum& fitmodel, View1D<double> Theta) {
		VF_ASSERT(Theta.size(0) == fitmodel.theta_size());

		SpotParameters spot;

		spot.XEmit = Theta[fitmodel.offset_x()];
		spot.YEmit = Theta[fitmodel.offset_y()];

		if (fitmodel.has_z()) {
			spot.ZEmit = Theta[fitmodel.offset_z()];
		}

		spot.Nph = Theta[fitmodel.offset_nph()];
		spot.Nbg = Theta[fitmodel.offset_nbg()];

		if (fitmodel.has_azim()) {
			spot.Azim = Theta[fitmodel.offset_azim()];
		}

		if (fitmodel.has_pola()) {
			spot.Pola = Theta[fitmodel.offset_pola()];
		}

		if (fitmodel.has_diffusion()) {
			spot.G2 = Theta[fitmodel.offset_diffusion()];
		}

		if (fitmodel.has_aberrations()) {
			VF_ASSERT(fitmodel.num_aberrations() <= FitParams::MaxNaberr);

			for (int ii = 0; ii < fitmodel.num_aberrations(); ii++) {
				spot.AberrationCoefs[ii] = Theta[fitmodel.offset_aberrations() + ii];
			}
		}

		return spot;
	}


	double AberrationCoefs[FitParams::MaxNaberr] = {0};
	double Nph = 0;  // Number of photons
	double Nbg = 0;  // Background photons

	double XEmit = 0.0;
	double YEmit = 0.0;
	double ZEmit = 0.0;

	double Pola = default_pola;
	double Azim = default_azim;
	double G2 = default_g2(); //coth(x)=1/tanh(x);
};
