#pragma once

#include "Parameters.h"
#include "MultiDimArray.h"

namespace compute {

void getFisherCRLB(
		const FitParams& AllParams,
		View4D<double> muStore,
		View5D<double> dmudthetaStore,
		WriteView2D<double> CRLB,
		WriteView1D<double> rcondStore);

void getFitError(
		const FitParams& AllParams,
		WriteView4D<double> mu,
		View4D<double> AllSpots,
		WriteView2D<double> FitError);

}