#include "fisher.h"
#include "Parameters.h"
#include "MultiDimArray.h"
#include "common.h"
#include <Eigen/Dense>
#include <limits>

namespace compute {

void getFisherCRLB(
		const FitParams& AllParams,
		View4D<double> muStore,
		View5D<double> dmudthetaStore,
		WriteView2D<double> CRLB,
		WriteView1D<double> rcondStore)
{
	using namespace placeholder;

	// This function calculates the Fisher - matrix and the Cramer - Rao Lower Bound for the parameters found.
	double keps = 1000 * EPS;
	int Ncfg = muStore.size(3);
	int numparams = AllParams.FitModel.num_parameters();
	int Mx = AllParams.Mx;
	int My = AllParams.My;
	int K = AllParams.Mz;

	VF_ASSERT(muStore.shape() == shape(Mx, My, K, Ncfg));
	VF_ASSERT(dmudthetaStore.shape() == shape(Mx, My, K, numparams, Ncfg));
	VF_ASSERT(CRLB.shape() == shape(numparams, Ncfg));
//	VF_ASSERT(rcondStore.shape() == shape(Ncfg, Mx, My, K));

	Arr3D<double> weight(Mx, My, K);
	Arr2D<double> Fisher(numparams, numparams); //Arr2D

	for (int jcfg = 0; jcfg < Ncfg; jcfg++)
	{
		View3D<double> mu = muStore.view(_, _, _, jcfg); //copy from Arr4D to Arr3D
		View4D<double> dmudTheta = dmudthetaStore.view(_, _, _, _, jcfg);

		//Calculation of Poisson rates
		for (int ii = 0; ii < Mx; ii++)
		{
			for (int jj = 0; jj < My; jj++)
			{
				for (int kk = 0; kk < K; kk++)
				{
					double m = mu(ii, jj, kk) + AllParams.ReadNoiseVariance;
					double mupos = std::max(m, keps);
					weight(ii, jj, kk) = 1.0 / mupos;
				}
			}
		}

		//Calculation of Fisher matrix
		for (int mm = 0; mm < numparams; mm++)
		{
			for (int nn = 0; nn < numparams; nn++)
			{
				double tempsum = 0.0;

				for (int ii = 0; ii < Mx; ii++)
				{
					for (int jj = 0; jj < My; jj++)
					{
						for (int kk = 0; kk < K; kk++)
						{
							tempsum += weight(ii, jj, kk) * dmudTheta(ii, jj, kk, mm) * dmudTheta(ii, jj, kk, nn);
						}
					}
				}

				Fisher(mm, nn) = tempsum;
				Fisher(nn, mm) = Fisher(mm, nn);
			}
		}

		// regularization Fisher - matrix in order to circumvent possibility for inverting ill - conditioned matrix
		Arr2D<double> FisherInverse(numparams, numparams);
		Arr2D<double> Fishertemp(numparams, numparams);
		Arr2D<double> Fishertemp2(numparams, numparams);

		Fishertemp = Fisher;
		Fishertemp.diagonal() += keps;

		Eigen::MatrixXd A(numparams, numparams);
		Eigen::MatrixXd Ainverse(numparams, numparams);
		for (int mm = 0; mm < numparams; mm++)
		{
			for (int nn = 0; nn < numparams; nn++)
			{
				A(mm, nn) = Fishertemp(mm, nn);
			}
		}
		// Compute inverse with check
		const auto qr = A.colPivHouseholderQr();
		if (qr.isInvertible()) {
			Ainverse = qr.inverse();
			//Fishertemp.matInverse(FisherInverse);
			for (int mm = 0; mm < numparams; mm++)
			{
				for (int nn = 0; nn < numparams; nn++)
				{
					FisherInverse(mm, nn) = Ainverse(mm, nn);
				}
			}

			//compute condition number for checking wether the Fisher matrix is well/ill conditioned.
			//if (cond(Fisher) ^ -1 > keps) compute CRLB!
			for (int mm = 0; mm < numparams; mm++)
			{
				CRLB(mm, jcfg) = sqrt(FisherInverse(mm, mm));
			}

			//compute the reciprocal condition number of the Fisher matrix;
		    // rcondStore(jcfg) = rcond(Fisher);
		} else {
			// Output NaNs to indicate a problem with the matrix inversion
			for (int mm = 0; mm < numparams; mm++)
			{
				CRLB(mm, jcfg) = std::numeric_limits<double>::quiet_NaN();
			}
		}
	}
}

void getFitError(
		const FitParams& AllParams,
		WriteView4D<double> mu,
		View4D<double> AllSpots,
		WriteView2D<double> FitError
) { //chi2,LLR, and SSE
	// This function calculates the normalized chisquare value
	const int Ncfg = mu.size(3);
	int Mx = AllParams.Mx;
	int My = AllParams.My;
	int Mz = AllParams.Mz;

	VF_ASSERT(mu.shape() == shape(Mx, My, Mz, Ncfg));
	VF_ASSERT(AllSpots.shape() == shape(Mx, My, Mz, Ncfg));
	VF_ASSERT(FitError.shape() == shape(3, Ncfg));

	double normalize = Mx * My * Mz;
	double keps = 1000 * EPS;

	for (int jcfg = 0; jcfg < Ncfg; jcfg++)
	{
		double sumchi2 = 0.0;
		double sumLLR = 0.0;
		double sumSSE = 0.0;

		for (int ii = 0; ii < Mx; ii++)
		{
			for (int jj = 0; jj < My; jj++)
			{
				for (int kk = 0; kk < Mz; kk++)
				{
					double m = double(mu(ii, jj, kk, jcfg) > 0) * mu(ii, jj, kk, jcfg) + double(mu(ii, jj, kk, jcfg) < 0) * keps;
					mu(ii, jj, kk, jcfg) = m;

					double a = AllSpots(ii, jj, kk, jcfg);
					sumchi2 += pow2((m - a)) / m;
					sumLLR += m - a + a * log(a) - a * log(m);
					sumSSE += m - a;
				}
			}
		}

		FitError(0, jcfg) = sumchi2 / normalize;
		FitError(1, jcfg) = 2 * sumLLR / normalize;
		FitError(2, jcfg) = pow2(sumSSE) / normalize;
	}
}

}