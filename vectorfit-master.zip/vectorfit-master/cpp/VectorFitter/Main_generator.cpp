#include <iostream>
#include <random>

#include "array/operators.h"
#include "estimator/cpu_estimator.h"
#include "files.h"

template <typename Rng>
double rand_double(Rng& rng, double lbnd, double ubnd) {
	return std::uniform_real_distribution<double>(lbnd, ubnd)(rng);
}

Arr1D<double> random_theta(int seed, const FitParams& params) {
	std::default_random_engine rng(seed);
	FitModelEnum fitModel = params.FitModel;
	Arr1D<double> theta(fitModel.theta_size());

	theta[fitModel.offset_x()] = rand_double(rng, params.PixelSize, -params.PixelSize);
	theta[fitModel.offset_y()] = rand_double(rng, params.PixelSize, -params.PixelSize);

	if (fitModel.has_z()) {
		theta[fitModel.offset_z()] = rand_double(rng, params.ZRange[0], params.ZRange[1]);
	}

	// Are these ranges ok?
	theta[fitModel.offset_nph()] = rand_double(rng, 500, 20000);
	theta[fitModel.offset_nbg()] = rand_double(rng, 0, 10);

	if (fitModel.has_pola()) {
		theta[fitModel.offset_pola()] = rand_double(rng, 0, M_PI);
	}

	if (fitModel.has_azim()) {
		theta[fitModel.offset_azim()] = rand_double(rng, 0, 2 * M_PI);
	}

	if (fitModel.has_diffusion()) {
		theta[fitModel.offset_diffusion()] = rand_double(rng, 0, 1);
	}

	if (fitModel.has_fitted_aberrations()) {
		for (int i = 0; i < fitModel.num_aberrations(); i++) {
			double v = 0.01 * params.Lambda;
			theta[fitModel.offset_aberrations() + i] = rand_double(rng, -v, v);
		}
	}

	return theta;
}

Arr3D<double> theta_to_spot(View1D<double> theta, Estimator& estimator) {
	const FitParams& params = estimator.AllParams;
	int NPupil = params.NPupil;
	int nparams = params.FitModel.num_parameters();

	Arr4D<std::complex<double>> PupilMatrix(NPupil, NPupil, 2, 3);
	Arr3D<double> mu(params.Mx, params.My, params.Mz);
	Arr4D<double> dmudtheta(params.Mx, params.My, params.Mz, nparams);

	auto spot = SpotParameters::from_theta(params.FitModel, theta);
	estimator.pupil_matrix.update_aberrations(spot.AberrationCoefs);
	estimator.PoissonRate(spot, mu, dmudtheta);

	return mu;
}


int main(int argc, char* argv[]) {
	using namespace placeholder;

	if (argc < 4) {
		std::cerr << "usage: " << argv[0] << " [config file] [output directory] [number of spots]\n";
		return EXIT_FAILURE;
	}

	std::string config_file = argv[1];
	std::string output_dir = argv[2];
	int N = int(strtol(argv[3], nullptr, 10));

	FitParams params = FitParams::parse_file(config_file);
	Estimator estimator(params);

	for (int i = 0; i < N; i++) {
		Arr1D<double> theta = random_theta(i, params);
		Arr3D<double> spot = theta_to_spot(theta, estimator);

		std::string file_name = output_dir + "/spot" + std::to_string(i + 1) + ".bin";
		writeBinaryImage(file_name, spot);

		std::cout << "writing " << file_name << std::endl;
	}

}