/* vectorfit_get_modeled_spot
 * mu, dmudtheta = vectorfit_get_modeled_spot(spot_index);
 * Calculates the modeled spot in the form of mu and dmudtheta
 * for the given spot index, based on the current state of theta.
 *
 * returns mu and dmudtheta of the modeled spot
*/

#include "vectorfit_mex.hpp"
#include "vectorfit_fitter.hpp"
#include "array/operators.h"


class MexFunction : public VectorfitMexFunction {
public:
    using Struct = matlab::data::Struct;
    using StructArray = matlab::data::StructArray;

    void execute(ArgumentList outputs, ArgumentList inputs) override {
        // Obtain fitter object handle
        const uint64_t handle = inputs[0][0];
        VectorfitFitter* fitter = VectorfitMemoryManager::get(handle);
        // Obtain spot index
        const uint64_t spot_index = inputs[1][0];
        // Compute modeled spot
        const FitParams& params = fitter->fitter().params();
        Arr3D<double> mu(params.Mx, params.My, params.Mz);
        Arr4D<double> dmudtheta(params.Mx, params.My, params.Mz, params.FitModel.num_parameters());
        fitter->fitter().get_modeled_spot((int)spot_index, mu, dmudtheta);

        // Populate output
        // Output mu
        TypedArray<double> output_mu = _array_factory.createArray(
            {
                (uint32_t)mu.size(0),
                (uint32_t)mu.size(1),
                (uint32_t)mu.size(2)
            },
            mu.begin(), mu.end(),
            matlab::data::InputLayout::ROW_MAJOR
        );
        outputs[0] = std::move(output_mu);
        // Output dmudtheta
        TypedArray<double> output_dmudtheta = _array_factory.createArray(
            {
                (uint32_t)dmudtheta.size(0),
                (uint32_t)dmudtheta.size(1),
                (uint32_t)dmudtheta.size(2),
                (uint32_t)dmudtheta.size(3)
            },
            dmudtheta.begin(), dmudtheta.end(),
            matlab::data::InputLayout::ROW_MAJOR
        );
        outputs[1] = std::move(output_dmudtheta);
    }

    void checkArguments(ArgumentList outputs, ArgumentList inputs) {
        // Check array arguments
        // inputs[0]: vectorfit_handle: uint64 scalar
        // inputs[1]: spot_index: uint64 vector
        if (inputs.size() != 2) {
            feval_error("Number of required inputs is 2: (vectorfit_handle, spot_index)");
        }

        // Input 1: vectorfit handle, uint64 scalar
        if (inputs[0].getType() != ArrayType::UINT64 ||
            inputs[0].getNumberOfElements() != 1) {
            feval_error("Input 1 must be a vectorfit handle in the form of a uint64 scalar");
        }

        // Input 2: spot index, uint64 or int64 scalar
        if (!(inputs[1].getType() == ArrayType::UINT64 ||
            inputs[1].getType() == ArrayType::INT64) ||
            inputs[1].getNumberOfElements() != 1) {
            feval_error(
                "Input 2 'spot_index' must be a uint64 or int64 scalar"
            );
        }

        // Check number of outputs
        if (outputs.size() != 2) {
            feval_error("Two outputs are returned: mu, dmudtheta");
        }
    }
};
