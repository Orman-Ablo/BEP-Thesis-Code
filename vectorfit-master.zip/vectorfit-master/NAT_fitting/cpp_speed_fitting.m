 
% Script for timing fitting of large simulated dataset

clear all
close all

testcase = 'xyz'; %'xyz';

switch testcase
    case 'xy'
        params = set_parameters_xy_NAT;
    case 'xyz'
        params = set_parameters_xyz_NAT;
    otherwise
        error('testcase not correct: choose ''xy'' or ''xyz''')
end

% Generate data
params.generate_new_data = true;
params.add_newnoise = false;
params.simulated_data = true;
params.groundtruth_exists = true;
plot_data = true;
final_local_update = false;

params.Ncfg_total = 1e3;
Ncfg = params.Ncfg_total;
xy_range = 2;

params.N_level = 2500; 
params.b_level = 10;

%[groundtruth,allspots,allspots_withoutnoise,roixy,theta_global] = generate_synthetic_spots(Ncfg,xy_range,N_level,b_level,params);
get_NAT_data

theta_global = groundtruth.global;

%% Repeat data to create many spots
Mfac = 10; % total nr op spots = Ncfg * Mfac
groundtruth_multi = repmat(groundtruth.local,[1 Mfac]);
allspots_multi = repmat(allspots_withoutnoise,[1 1 1 Mfac]);
allspots_multi = poissrnd(allspots_multi);
roixy_multi = repmat(roixy,[1 Mfac]);
Ncfg_multi = Ncfg*Mfac;

%%
fprintf('\nPerform local fit with %i spots\n',Ncfg_multi);

switch testcase
    case 'xy'
        params.fitmodel = 'xy_constaberrations';
    case 'xyz'
        params.fitmodel = 'xyz_constaberrations';
    otherwise
        error('testcase not correct: choose ''xy'' or ''xyz''')
end

params.initialization = 'phasor';
params.FlagOTF = true;
params.Mpsfx = 129;
params.Mpsfy = 129;
params.Mpsfz = 129;
params.Notfx = 48;
params.Notfy = 48;
params.Notfz = 20;
params.OTFGridSizeX = 10;
params.OTFGridSizeY = 10;
spots_per_batch = 1000;%2e4;%4e5;
params.NumThreads = 24;
Nbatch = ceil(Ncfg_multi/spots_per_batch);

theta_update = zeros(params.numparams,Ncfg_multi);
crlb = zeros(params.numparams,Ncfg_multi);
fitmodel = "gpu-lowaccuracy";%"cpu"

%% Compare to Matlab

% Set up parallel pool
if isempty(gcp('nocreate'))
    number_of_parallel_workers = params.nr_of_parallel_workers;
    parpool('Threads', number_of_parallel_workers);
end

max_local_iterations = params.max_local_iterations;
numparams = params.numparams;
params.fitmodel = 'xyz';

t_matlab = tic;
for batch = 1:Nbatch
    start = (batch-1)*spots_per_batch;
    stop = min(start+spots_per_batch,Ncfg_multi);
    Ncfg_batch = stop-start;
    params.Ncfg = Ncfg_batch;
    spots_batch = allspots_multi(:,:,:,start+1:stop);
    roixy_batch = roixy_multi(:,start+1:stop);
    theta_init_matlab = initialvalues_phasor(spots_batch,roixy_batch,theta_global,params);
    theta_local = theta_init_matlab;
    thetastore_local = zeros(numparams,Ncfg_batch,max_local_iterations);
    meritstore = zeros(Ncfg_batch,max_local_iterations);
    alambda_local = ones(Ncfg_batch,1)*params.alambda0_local;
    Niters = zeros(Ncfg_batch,1);
    framelist = ones(Ncfg_batch,1);
    ID = 1:Ncfg_batch;
    flip_z_net = false;
    iiter_total = 1;
    
    [theta_local,thetastore_local,localizations,localizations_with_outliers,meritstore,alambda_local,mu,dmudtheta_local,Niters,outliers] = ...
    local_update(theta_local,thetastore_local,theta_global,meritstore,alambda_local,spots_batch,roixy_batch,iiter_total,Niters,flip_z_net,framelist,ID,params);
end

t_final_matlab = toc(t_matlab)
locs_per_second_matlab = Ncfg_multi/t_final_matlab
mean_iters = mean(Niters)
std_iters = std(Niters)

%% Start up round (first time is usually slower)
t_startup = tic;
for batch = 1:Nbatch
    batch
    start = (batch-1)*spots_per_batch;
    cpp_spots = allspots_multi(:,:,:,start+1:min(start+spots_per_batch,Ncfg_multi));
    cpp_roixy = roixy_multi(:,start+1:min(start+spots_per_batch,Ncfg_multi));
    fitter = vectorfitter(cpp_spots,cpp_roixy, params,fitmodel);
    cpp_zernike_coeffs = fitter.update_zernike_coefficients(theta_global, params.aberrations);
    cpp_theta_init = fitter.theta_init();
    [cpp_theta_update, cpp_num_iters] = fitter.local_update();
    theta_update(:,start+1:min(start+spots_per_batch,Ncfg_multi)) = cpp_theta_update;
    outliers = fitter.outliers;
    delete(fitter)
end

t_final_startup = toc(t_startup)
locs_per_second_startup = Ncfg_multi/t_final_startup
mean_iters_cpp = mean(cpp_num_iters)
std_num_iters = std(double(cpp_num_iters))

%% Precalculate OTFs and reuse in batches

t_timing = tic;
if params.FlagOTF
    fitter_all = vectorfitter(allspots_multi,roixy_multi,params,fitmodel);
    [otfs,spot_otf_indices] = fitter_all.update_otfs(theta_global,params.aberrations);
    delete(fitter_all)
end

for batch = 1:Nbatch
    start = (batch-1)*spots_per_batch;
    stop = min(start+spots_per_batch,Ncfg_multi);
    spots_batch = allspots_multi(:,:,:,start+1:stop);
    roixy_batch = roixy_multi(:,start+1:stop);
    fitter = vectorfitter(spots_batch,roixy_batch, params,fitmodel);
    if params.FlagOTF
        spot_otf_indices_batch = spot_otf_indices(start+1:stop);
        fitter.set_otfs(otfs,spot_otf_indices_batch);
    else
        cpp_zernike_coeffs = fitter.update_zernike_coefficients(theta_global, params.aberrations);
    end
    cpp_theta_init = fitter.theta_init();
    [cpp_theta_update, cpp_num_iters] = fitter.local_update();
    % outliers = fitter.outliers;
    % crlb_batch = fitter.fisher_crlb;
    % theta_update(:,start+1:min(start+spots_per_batch,Ncfg_multi)) = cpp_theta_update;
    % crlb(:,start+1:min(start+spots_per_batch,Ncfg_multi)) =crlb_batch;
    delete(fitter)
end

t_final = toc(t_timing)
locs_per_second = Ncfg_multi/t_final

%% Time round with precalculated otfs (only use when params.FlagOTF)

% First calculate OTFs
batch = 1;
start = (batch-1)*spots_per_batch;
cpp_spots = allspots_multi(:,:,:,start+1:min(start+spots_per_batch,Ncfg_multi));
cpp_roixy = roixy_multi(:,start+1:min(start+spots_per_batch,Ncfg_multi));
fitter = vectorfitter(cpp_spots,cpp_roixy, params,fitmodel);
[otfs,spot_otf_indices] = fitter.update_otfs(theta_global,params.aberrations);
delete(fitter)
%%
% Then do the timing
t_timing = tic;
for batch = 1:Nbatch
    batch
    start = (batch-1)*spots_per_batch;
    cpp_spots = allspots_multi(:,:,:,start+1:min(start+spots_per_batch,Ncfg_multi));
    cpp_roixy = roixy_multi(:,start+1:min(start+spots_per_batch,Ncfg_multi));
    fitter = vectorfitter(cpp_spots,cpp_roixy, params,fitmodel);
    fitter.set_otfs(otfs,spot_otf_indices); 
    cpp_theta_init = fitter.theta_init();
    [cpp_theta_update, cpp_num_iters] = fitter.local_update();
    theta_update(:,start+1:min(start+spots_per_batch,Ncfg_multi)) = cpp_theta_update;
    outliers = fitter.outliers;
    crlb = fitter.fisher_crlb;
    theta_update(:,start+1:min(start+spots_per_batch,Ncfg_multi)) = cpp_theta_update;

    delete(fitter)
end

t_final = toc(t_timing);
locs_per_second = Ncfg_multi/t_final

%%
fprintf('\nLocalization completed\n')
fprintf('Nr of spots: %i\n',Ncfg_multi);
fprintf('Spots per batch: %i\n',spots_per_batch);
fprintf('Fitmodel: %s\n',fitmodel);
fprintf('FlagOTF: %i\n',params.FlagOTF);
fprintf('Mpsfx: %i\n',params.Mpsfx);
fprintf('Mpsfy: %i\n',params.Mpsfy);
fprintf('Notf: %i\n',params.Notfx);
fprintf('Mx: %i\n',params.Mx);
fprintf('My: %i\n',params.My);
fprintf('OTFGridSizeX: %i\n',params.OTFGridSizeX)
fprintf('OTFGridSizeY: %i\n',params.OTFGridSizeY);

if exist('locs_per_second_startup','var')
    fprintf('\nStart up round\n');
    fprintf('Time to fit %i spots: %d seconds\n',Ncfg_multi,t_final_startup);
    fprintf('Localizations per second: %d\n',locs_per_second_startup);
end

fprintf('\nTiming round\n');
fprintf('Total time: %d\n',t_final);
fprintf('Localizations per second: %d\n',locs_per_second);


%% Compare to groundtruth
error_loc = (groundtruth_multi - theta_update);
%no_outliers = setdiff(1:spots_per_batch,outliers);
%error_loc = (groundtruth_multi(:,no_outliers) - theta_update(:,no_outliers));
bias = mean(error_loc,2)
std_loc = std(error_loc,1,2)
crlb_mean = mean(crlb,2)
%%
dipshow(allspots_multi,'lin')
diptruesize(4000)
colormap parula

%%
