#include "Parameters.h"
#include <algorithm>

namespace compute {
	inline double findMedian(std::vector<double> a)
	{
		size_t n = a.size();
		VF_ASSERT(n != 0);
		std::sort(&a[0], &a[n]);

		if (n % 2 != 0)
			return a[n / 2];
		else
			return (a[(n - 1) / 2] + a[n / 2]) / 2.0;
	}

	inline double getBorderBackground(View2D<double> fxy) {
		index_t Mx = fxy.size(0);
		index_t My = fxy.size(1);
		std::vector<double> rimpx(2 * (Mx + My) - 4);

		//get the median of the background (from borders of fxy)
		// Get rims for x=0 and x=Mx-1 for y in [0, My-1]
		for (int ii = 0; ii < My; ii++)
		{
			rimpx[ii] = fxy(0, ii);
			rimpx[My + ii] = fxy(Mx - 1, ii);
		}
		// Get rims for y=0 and y=My-1 for x in [1, Mx-2]
		for (int ii = 1; ii < Mx-1; ii++)
		{
			rimpx[2 * My + (ii-1)] = fxy(ii, 0);
			rimpx[2 * My + (Mx-2) + (ii-1)] = fxy(ii, My - 1);
		}

		return std::min(std::max(findMedian(rimpx), 1.0), 50.0);
	}

	void getSpotFxy(View3D<double> OneSpot, ExcitationEnum excitation, WriteView2D<double> fxy);
	void getPhasorThetaStart(const FitParams& AllParams, View3D<double> OneSpot, View2D<double> fxy, WriteView1D<double> ThetaStart);
	void InitialValues(const FitParams& AllParams, View3D<double> OneSpot, WriteView1D<double> ThetaInit);
	void InitialValuesCentroid(const FitParams& AllParams, View3D<double> OneSpot, WriteView1D<double> ThetaInit);
	void InitialValuesPhasor(const FitParams& AllParams, View3D<double> OneSpot, WriteView1D<double> ThetaInit);
 	void InitialValues_aberr(const FitParams& AllParams, View3D<double> OneSpot, WriteView1D<double> ThetaInit);
}
