#pragma once

#include "Parameters.h"
#include "MultiDimArray.h"

class PupilMatrix {
public:

	PupilParams AllParams;
	int NAberr;
	Arr2D<double> XPupil;
	Arr2D<double> YPupil;
	Arr2D<double> ApertureMask;
	Arr3D<double> AllZernikes;
	Arr3D<double> AllZernikesNormalized;
//
	Arr4D<std::complex<double>> PolarizationVector;
	Arr2D<std::complex<double>> Amplitude;
	Arr2D<std::complex<double>> cosThetaImm;
	Arr2D<std::complex<double>> cosThetaImmnom;
	Arr2D<std::complex<double>> cosThetaMed;
	Arr2D<std::complex<double>> cosThetaCov;
	Arr3D<std::complex<double>> WaveVector;
	Arr2D<std::complex<double>> WaveVectorZImm;
	Arr4D<std::complex<double>> Matrix;
	Arr2D<double> zonefun;
	SmallArr<double, 3, 3> intensity;

	//SAF check parameters
	fixed_vector<double, 3> ZVals;

	PupilMatrix(const PupilParams& params, int NAberr);
	void update_aberrations(const double* AberrationCoefs);

	void compute_normalization(
			double pola,
			double azim,
			double& normint_free,
			double& normint_fixed); //Define get normalization

	View4D<std::complex<double>> get() {
		return Matrix;
	}
};


