#pragma once

#include <iostream>

#include "MultiDimArray.h"
#include "Parameters.h"
#include "estimator/interface.h"
#include "estimator/parallel_estimator.h"
#include "compute/zernike_coefficients.h"
#include "compute/pupil_matrix.h"


class Fitter
{
public:
	using Aberration = compute::zernike_coefficients::Aberration;

	// Constructor. Takes spot data and fit params.
	Fitter(
		Arr4D<double>&& spots,
		Arr2D<double>&& roixy,
		const FitParams& params,
		const std::string& compute_device
	);
	virtual ~Fitter() {}

	// Get the fit params.
	const FitParams& params() const { return _params; }

	// Get the spot data.
	View4D<double> spots() {return _spots.view(); }

	// Get the number of spots.
	int num_spots() const { return _spots.size(0); }

	// Initialize the fitter. This must be done before calling
	// other functions like update() or flip_z().
	void init();

	// Flip all Z-coordinates in theta, i.e., multiply by -1.
	void flip_z();

	// Perform an update to localize the spots.
	void update();

	// Computes the outlier indices. Only valid after update().
	std::vector<int> get_outliers() const;

	// Recompute the zernike coefficients for the given gamma values and aberrations
	// and store them in theta.
	Arr2D<double> update_zernike_coefficients(
		View1D<double> gammas, View1D<Aberration> aberrations
	);

	// Get the current theta.
	View2D<double> theta() const { return _theta.view(); }

	// Get the current theta, parameters only, excluding potential constant aberrations.
	View2D<double> theta_params_only() const;

	// Get the number of iterations. Only valid after update().
	View1D<int> num_iters() const { return _num_iters.view(); }

	// Get mu for all spots. Only valid after update().
	View4D<double> mu() const { return _mu.view(); }

	// Get dMu/dTheta for all spots. Only valid after update().
	View5D<double> dmudtheta() const { return _dmudtheta.view(); }

	// Get convergence status of all spots. Only valid after update().
	View1D<bool> convergence() const { return _convergence.view(); }

	// Computes the Fisher CRLB. Only valid after update().
	void get_fisher_crlb(WriteView2D<double> crlb) const;

	// Obtain a copy of the pupil matrix for specific zernike coefficients.
	// This function exists for debugging and data comparison purposes.
	PupilMatrix get_pupil_matrix(const double* AberrationCoefs = nullptr) const;

	// Debug function. Note: crashes when using the gpu!
	void get_modeled_spot(int spot_index, WriteView3D<double> mu, WriteView4D<double> dmudtheta);

	// Update the OTFs by computing them from the provided aberrations
	void update_otfs(
		View1D<double> gammas,
		View1D<Aberration> aberrations,
		WriteView4D<std::complex<double>> otfs,
		WriteView1D<int> spot_otf_indices
	);

	// Set the OTFs from externally computed values
	void set_otfs(View4D<std::complex<double>> otfs, View1D<int> spot_otf_indices);

	// Get the number of OTFs.
	// Note: independent of whether OTFs are actually used (_params.FlagOTF).
	int num_otfs() const;

protected:
	enum EstimatorType {
		CPU_PARALLEL,
		CUDA,
		CUDA_OTF,
	};

	Arr4D<double> _spots; // Spot data
	Arr2D<double> _roixy; // Location of the spots in the global image (2, num_spots)
	FitParams _params; // Fit model parameters
	Arr2D<double> _theta; // Theta for all spots
	Arr4D<double> _mu; // Mu for all spots
	Arr5D<double> _dmudtheta; // dMudTheta for all spots
	Arr1D<int> _num_iters; // Number of iterations for all spots
	Arr1D<bool> _convergence; // Convergence for all spots
	Arr2D<double> _merit; // Merit for all spots: _merit(i_spot, N) contains the merit after the Nth iteration.
	std::unique_ptr<BaseEstimator> _estimator; // Main localization estimator
	std::unique_ptr<ParallelEstimator> _otfs_estimator; // OTF computer (optional)
	EstimatorType _estimator_type;
	Arr1D<compute::zernike_coefficients::Aberration> _aberration_orders;
	void set_aberrations();

	void create_estimator(const std::string& compute_device);
	// Derived estimator type accessors that can be used until
	// BaseEstimator has the proper abstractions.
	// They return nullptr if _estimator_type does not match the accessor.
	template<class TEstimator>
	TEstimator* derived_estimator() const {
		return dynamic_cast<TEstimator*>(_estimator.get());
	}

	// Resize internal memory arrays
	void resize_internals();

	// Compute the normalized FOV coordinates
	// in the square interval [-1,1] x [-1,1].
	Arr2D<double> get_normalized_fov_coordinates(
		const View1D<double>& x, const View1D<double>& y
	) const;

	// Divide the image into a grid of patches and compute
	// representative Zernike coefficients for each grid patch.
	// The grid patch indices for all spots are also returned.
	// The output can serve as input for the OTF grid computation.
	void compute_otf_grid_zernike_coefficients(
		int grid_size_x,
		int grid_size_y,
		View1D<double>& gammas,
		WriteView2D<double> coefficients,
		WriteView1D<int> spot_grid_xy
	) const;
};
