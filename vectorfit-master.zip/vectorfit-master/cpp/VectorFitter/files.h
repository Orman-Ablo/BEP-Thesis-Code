#include <chrono>
#include <iostream>
#include <fstream>
#include <iomanip>

#include "MultiDimArray.h"

bool fileExists(const std::string& filename);

void readBinaryImage(const std::string& filename, WriteView2D<double> x);
void readBinaryImage(const std::string& filename, WriteView3D<double> x);

void writeBinaryImage(const std::string& filename, View1D<double> x);
void writeBinaryImage(const std::string& filename, View2D<double> x);
void writeBinaryImage(const std::string& filename, View3D<double> x);
