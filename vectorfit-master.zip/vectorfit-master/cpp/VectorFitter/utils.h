#pragma once
#include <stdexcept>
#include <sstream>
#include <iostream>
#include <chrono>

#include "cuda/macros.cuh"

#if defined(_MSC_VER)
#define VF_ALWAYS_INLINE __declspec (inline)
#define VF_NOINLINE __declspec (noinline)
#define VF_LIKELY(expr) expr
#define VF_UNLIKELY(expr) expr
#else
#define VF_ALWAYS_INLINE __attribute__ ((always_inline))
#define VF_NOINLINE __attribute__ ((noinline))
#define VF_LIKELY(expr) (__builtin_expect(!!expr, 1))
#define VF_UNLIKELY(expr) (__builtin_expect(!!expr, 0))
#endif

#define VF_PANIC(msg, ...) \
	do { ::assert_failed(msg, __FILE__, __LINE__, __FUNCTION__, ## __VA_ARGS__); } while (0)

#define VF_ASSERT(expr, ...) \
	do { if (VF_UNLIKELY(!(expr))) VF_PANIC(#expr, ## __VA_ARGS__); } while (0)

#if defined(NDEBUG)
#define VF_INLINE VF_ALWAYS_INLINE
#define VF_DEBUG_ASSERT(...) \
	do { } while (0)
#else
#define VF_INLINE
#define VF_DEBUG_ASSERT(...) \
	VF_ASSERT(__VA_ARGS__)
#endif

#define VF_DEBUG_IMPL(expr) \
	::log_debug((expr), #expr, __FILE__, __LINE__, __FUNCTION__)

#define M_NARGS(...) M_NARGS_(__VA_ARGS__, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0)
#define M_NARGS_(_10, _9, _8, _7, _6, _5, _4, _3, _2, _1, N, ...) N

#define M_CONC(A, B) M_CONC_(A, B)
#define M_CONC_(A, B) A##B
#define M_ID(...) __VA_ARGS__
#define M_FOR_EACH(...)

#define VF_DEBUG_1(a) VF_DEBUG_IMPL(a)
#define VF_DEBUG_2(a, ...) do { VF_DEBUG_IMPL(a); VF_DEBUG_1(__VA_ARGS__); } while (0)
#define VF_DEBUG_3(a, ...) do { VF_DEBUG_IMPL(a); VF_DEBUG_2(__VA_ARGS__); } while (0)
#define VF_DEBUG_4(a, ...) do { VF_DEBUG_IMPL(a); VF_DEBUG_3(__VA_ARGS__); } while (0)
#define VF_DEBUG_5(a, ...) do { VF_DEBUG_IMPL(a); VF_DEBUG_4(__VA_ARGS__); } while (0)
#define VF_DEBUG_6(a, ...) do { VF_DEBUG_IMPL(a); VF_DEBUG_5(__VA_ARGS__); } while (0)
#define VF_DEBUG_7(a, ...) do { VF_DEBUG_IMPL(a); VF_DEBUG_6(__VA_ARGS__); } while (0)
#define VF_DEBUG_8(a, ...) do { VF_DEBUG_IMPL(a); VF_DEBUG_7(__VA_ARGS__); } while (0)

#define VF_DEBUG(...) M_CONC(VF_DEBUG_, M_NARGS(__VA_ARGS__)) (__VA_ARGS__)


[[noreturn]]
CUDA_HOST_DEVICE_NOINLINE
inline void assert_failed(const char* expr, const char* file, int line, const char* function) {
#if CUDA_IS_DEVICE
	printf("[CUDA thread %d,%d,%d:%d,%d,%d] assertion failed: %s (%s:%d:%s)\n",
		   blockIdx.x, blockIdx.y, blockIdx.z,
		   threadIdx.y, threadIdx.y, threadIdx.z,
		   expr, file, line, function);
	asm("trap;");
	while(1);
#else
	std::stringstream s;
	s << "assertion failed: " << expr << " (" << file << ":" << line << ":" << function << ")";
	throw std::runtime_error(s.str());
#endif
}

[[noreturn]]
CUDA_HOST_DEVICE_NOINLINE
inline void assert_failed(const char* expr, const char* file, int line, const char* function, const char* message) {
#if CUDA_IS_DEVICE
	printf("[CUDA %d,%d,%d:%d,%d,%d] assertion failed: %s (%s:%d:%s): %s\n",
		   blockIdx.x, blockIdx.y, blockIdx.z,
		   threadIdx.y, threadIdx.y, threadIdx.z,
		   expr, file, line, function, message);
	asm("trap;");
	while(1);
#else
	std::stringstream s;
	s << "assertion failed: " << expr << " (" << file << ":" << line << ":" << function << "): " << message;
	throw std::runtime_error(s.str());
#endif
}

#if CUDA_IS_DEVICE
template <typename T>
CUDA_DEVICE
void log_debug_device_helper(T value, const char* expr, const char* file, int line, const char* function) {
	printf("[CUDA %d,%d,%d:%d,%d,%d][%s:%d:%s] debug: %s=???\n",
		   blockIdx.x, blockIdx.y, blockIdx.z,
		   threadIdx.x, threadIdx.y, threadIdx.z,
		   file, line, function, expr);
}

template <typename T>
CUDA_DEVICE
void log_debug_device_helper(T* value, const char* expr, const char* file, int line, const char* function) {
	printf("[CUDA %d,%d,%d:%d,%d,%d][%s:%d:%s] debug: %s=%p\n",
		   blockIdx.x, blockIdx.y, blockIdx.z,
		   threadIdx.x, threadIdx.y, threadIdx.z,
		   file, line, function, expr, value);
}

#define DEBUG_DEVICE_HELPER_IMPL(T, format, ...) \
	CUDA_DEVICE  \
	void log_debug_device_helper(T value, const char* expr, const char* file, int line, const char* function) { \
		printf("[CUDA %d,%d,%d:%d,%d,%d][%s:%d:%s] debug: %s=" format "\n", \
			   blockIdx.x, blockIdx.y, blockIdx.z, \
			   threadIdx.x, threadIdx.y, threadIdx.z, \
			   file, line, function, expr, __VA_ARGS__); \
	}                                          \

#define DEBUG_DEVICE_HELPER_SCALAR_IMPL(T, format) DEBUG_DEVICE_HELPER_IMPL(T, format, value);
DEBUG_DEVICE_HELPER_SCALAR_IMPL(signed int, "%d");
DEBUG_DEVICE_HELPER_SCALAR_IMPL(unsigned int, "%u");
DEBUG_DEVICE_HELPER_SCALAR_IMPL(signed long int, "%ld");
DEBUG_DEVICE_HELPER_SCALAR_IMPL(signed long long int, "%lld");
DEBUG_DEVICE_HELPER_SCALAR_IMPL(unsigned long int, "%lu");
DEBUG_DEVICE_HELPER_SCALAR_IMPL(unsigned long long int, "%llu");
DEBUG_DEVICE_HELPER_SCALAR_IMPL(float, "%f");
DEBUG_DEVICE_HELPER_SCALAR_IMPL(double, "%f");
#else
#define DEBUG_DEVICE_HELPER_IMPL(T, format, ...)
#endif

template <typename T>
VF_NOINLINE
CUDA_HOST_DEVICE_NOINLINE
inline void log_debug(T&& value, const char* expr, const char* file, int line, const char* function) {
	for (size_t i = 0; file[i]; i++) {
		if (file[i] == '/') {
			file += i + 1;
			i = 0;
		}
	}

#if CUDA_IS_DEVICE
	log_debug_device_helper(value, expr, file, line, function);
#else
	std::cerr << "[" << file << ":" << line << ":" << function << "] debug: " << expr << "=" << value << std::endl;
#endif
}


template <typename F>
double benchmark(F fun) {
	auto before = std::chrono::high_resolution_clock::now();
	fun();
	auto after = std::chrono::high_resolution_clock::now();
	return std::chrono::duration_cast<std::chrono::duration<double>>(after - before).count();
}

inline double timer() {
	static double first_time = 0.0;
	auto t = std::chrono::high_resolution_clock::now().time_since_epoch();
	double this_time = double(std::chrono::duration_cast<std::chrono::nanoseconds>(t).count()) * 1e-9;

	if (first_time == 0.0) first_time = this_time;
	return first_time - this_time;
}