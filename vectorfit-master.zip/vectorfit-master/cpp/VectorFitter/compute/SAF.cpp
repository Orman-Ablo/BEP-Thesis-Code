#include <algorithm>
#include <complex>

#include "Parameters.h"
#include "SAF.h"
#include "common.h"

using namespace std;

fixed_vector<double, 3> setSAF(const PupilParams& AllParams) //a good polyfit cpp code has to be used for this function. (needs to be optimized)
{
	using namespace std::literals::complex_literals;

/*
 This function finds the stage positions for optimal focus in SAF
 conditions by optimizing the Strehl ratio.
 The Strehl ratio is computed for 10 z - planes around an initial estimate of
 the stage position(-1.25 * refimm / refmed * depth).Then a second order
 polynomial fit is performed near the maximum to achieve subsampling
 z - precision.
 The Wrms due to the refractive index mismatch is then computed by
 Wrms = lambda / (2 * pi) * log(1 / S(Wab + Wri | Wab)), with S(Wab | Wab + Wri) the ratio
 of the maximum intensity of PSF with aberration Wab and the maximum intensity
 of PSF with additional aberration Wab ? nd refrective index mismatch Wri.

 Note : for depth = 0 (at the coverslip) the Wrms becomes negative as
 maximum intensity is no longer at z - stage position = 0;

 relevant z - positions:
 zvals = [nominal stage position, free working distance, -image depth from cover slip]
*/
	// This function calculates the pupil matrix Q_{ jk }, which gives the j - the electric field component proportional to the k - th dipole vector component.

	double  NA = AllParams.NA;
	double refmed = AllParams.RefMed;
	double  refcov = AllParams.RefCov;
	double refimm = AllParams.RefImm;
	double refimmnom = AllParams.RefImmNom;
	double lambda = AllParams.Lambda;
	int Npupil = AllParams.NPupil;

	fixed_vector<double, 3> zvals;
	zvals[0] = 0.0;
	zvals[1] = AllParams.Fwd;
	zvals[2] = -AllParams.Depth;


	//pupil radius(in diffraction units) and pupil coordinate sampling
	// double DxyPupil = 2 * PupilSize / Npupil;

	double PupilSize = 1.0;
	double DxyPupil = 2 * PupilSize / Npupil;

	Arr2D<double>XPupil(Npupil, Npupil);
	Arr2D<double>YPupil(Npupil, Npupil);

	//Create meshgrid, Pupil coordinate sampling
	for (int i = 0; i < Npupil; i++)
	{
		double xpupillin = -PupilSize + PupilSize / Npupil + i * 2 * PupilSize / Npupil;

		for (int j = 0; j < Npupil; j++)
		{
			XPupil(i, j) = xpupillin;
		}
	}
	for (int j = 0; j < Npupil; j++)
	{
		double ypupillin = -PupilSize + PupilSize / Npupil + j * 2 * PupilSize / Npupil;
		for (int i = 0; i < Npupil; i++)
		{
			YPupil(i, j) = ypupillin;
		}
	}
	////////////////////////////////


	// calculation of relevant Fresnel - coefficients for the interfaces
	// between the mediumand the cover slipand between the cover slip
	//and the immersion fluid
	// The Fresnel - coefficients should be divided by the wavevector z - component
	// of the incident medium, this factor originates from the
	// Weyl - representation of the emitted vector spherical wave of the dipole.

	// CosThetaMed = sqrt(1 - (XPupil. ^ 2 + YPupil. ^ 2) * NA ^ 2 / refmed ^ 2);

	Arr2D<double>argMed(Npupil, Npupil);
	Arr2D<double>phiMed(Npupil, Npupil);


	Arr2D<std::complex<double> >cosThetaMed(Npupil, Npupil);
	Arr2D<std::complex<double> >cosThetaCov(Npupil, Npupil);
	Arr2D<std::complex<double> >cosThetaImm(Npupil, Npupil);
	Arr2D<std::complex<double> >cosThetaImmnom(Npupil, Npupil);

	Arr2D<std::complex<double> >FresnelPmedcov(Npupil, Npupil);
	Arr2D<std::complex<double> >FresnelSmedcov(Npupil, Npupil);
	Arr2D<std::complex<double> >FresnelPcovimm(Npupil, Npupil);
	Arr2D<std::complex<double> >FresnelScovimm(Npupil, Npupil);

	Arr2D<std::complex<double> >FresnelP(Npupil, Npupil);
	Arr2D<std::complex<double> >FresnelS(Npupil, Npupil);
	Arr2D<std::complex<double> >ApertureMask(Npupil, Npupil);
	Arr2D<std::complex<double> >Amplitude(Npupil, Npupil);

	Arr2D<double>Phi(Npupil, Npupil);
	Arr2D<double>CosPhi(Npupil, Npupil);
	Arr2D<double>SinPhi(Npupil, Npupil);
	Arr2D<std::complex<double> >CosTheta(Npupil, Npupil);
	Arr2D<std::complex<double> >SinTheta(Npupil, Npupil);

	Arr3D<std::complex<double> >pvec(Npupil, Npupil, 3);
	Arr3D<std::complex<double> >svec(Npupil, Npupil, 3);
	Arr4D<std::complex<double> >PolarizationVector(Npupil, Npupil, 2, 3);
	double tempvar;
	std::complex<double> ctempvar;

	for (int nn = 0; nn < Npupil; nn++)
	{
		for (int mm = 0; mm < Npupil; mm++)
		{
			argMed(nn, mm) = 1.0 - (pow2(YPupil(nn, mm)) + pow2(XPupil(nn, mm))) * pow2(NA) / pow2(refmed);
			phiMed(nn, mm) = atan2(0, argMed(nn, mm));
			cosThetaMed(nn, mm) = sqrt(abs(argMed(nn, mm))) * (cos(phiMed(nn, mm) / 2.0) - 1i * sin(phiMed(nn, mm) / 2.0));

			tempvar = 1.0 - (pow2(YPupil(nn, mm)) + pow2(XPupil(nn, mm))) * pow2(NA) / pow2(refcov);
			cosThetaCov(nn, mm) = sqrt(tempvar * (1.0 + 1i * 0.0));

			tempvar = 1.0 - (pow2(YPupil(nn, mm)) + pow2(XPupil(nn, mm))) * pow2(NA) / pow2(refimm);
			cosThetaImm(nn, mm) = sqrt(tempvar * (1.0 + 1i * 0.0));

			tempvar = 1.0 - (pow2(YPupil(nn, mm)) + pow2(XPupil(nn, mm))) * pow2(NA) / pow2(refimmnom);
			cosThetaImmnom(nn, mm) = sqrt(tempvar * (1.0 + 1i * 0.0));

			ctempvar = (cosThetaCov(nn, mm) * refmed) + (cosThetaMed(nn, mm) * refcov);
			FresnelPmedcov(nn, mm) = (cosThetaMed(nn, mm) * (2.0 * refmed) * conj(ctempvar)) / (ctempvar * conj(ctempvar));
			ctempvar = (cosThetaMed(nn, mm) * refmed) + (cosThetaCov(nn, mm) * refcov);
			FresnelSmedcov(nn, mm) = (cosThetaMed(nn, mm) * (2.0 * refmed) * conj(ctempvar)) / (ctempvar * conj(ctempvar));
			ctempvar = (cosThetaImm(nn, mm) * refcov) + (cosThetaCov(nn, mm) * refimm);
			FresnelPcovimm(nn, mm) = (cosThetaCov(nn, mm) * (2.0 * refcov) * conj(ctempvar)) / (ctempvar * conj(ctempvar));
			ctempvar = (cosThetaCov(nn, mm) * refcov) + (cosThetaImm(nn, mm) * refimm);
			FresnelScovimm(nn, mm) = (cosThetaCov(nn, mm) * (2.0 * refcov) * conj(ctempvar)) / (ctempvar * conj(ctempvar));

			FresnelP(nn, mm) = FresnelPmedcov(nn, mm) * FresnelPcovimm(nn, mm);
			FresnelS(nn, mm) = FresnelSmedcov(nn, mm) * FresnelScovimm(nn, mm);

			Phi(nn, mm) = atan2(YPupil(nn, mm), XPupil(nn, mm));
			CosPhi(nn, mm) = cos(Phi(nn, mm));
			SinPhi(nn, mm) = sin(Phi(nn, mm));
			CosTheta(nn, mm) = cosThetaMed(nn, mm);
			SinTheta(nn, mm) = sqrt(1.0 - pow2(CosTheta(nn, mm)));

			pvec(nn, mm, 0) = FresnelP(nn, mm) * CosTheta(nn, mm) * CosPhi(nn, mm);
			pvec(nn, mm, 1) = FresnelP(nn, mm) * CosTheta(nn, mm) * SinPhi(nn, mm);
			pvec(nn, mm, 2) = -1.0 * FresnelP(nn, mm) * SinTheta(nn, mm);
			svec(nn, mm, 0) = -1.0 * FresnelS(nn, mm) * SinPhi(nn, mm);
			svec(nn, mm, 1) = FresnelS(nn, mm) * CosPhi(nn, mm);
			svec(nn, mm, 2) = 0.0;

			for (int kk = 0; kk < 3; kk++)
			{
				PolarizationVector(nn, mm, 0, kk) = CosPhi(nn, mm) * pvec(nn, mm, kk) - SinPhi(nn, mm) * svec(nn, mm, kk);
				PolarizationVector(nn, mm, 1, kk) = SinPhi(nn, mm) * pvec(nn, mm, kk) + CosPhi(nn, mm) * svec(nn, mm, kk);
			}

			// definition aperture
			tempvar = pow2(XPupil(nn, mm)) + pow2(YPupil(nn, mm));
			if (tempvar < 1.0)
				ApertureMask(nn, mm) = 1.0 + 1i * 0.0;
			else
				ApertureMask(nn, mm) = 0.0 + 1i * 0.0;


			// combining this factor with the Fresnel - coefficient factors T_{ p } and T_{ s }
			//		 the amplitude scales as[sqrt(cos(theta_imm)) / cos(theta_med)] x T_{ p,s }
			//		 where T_{ p } = T_{ p,med->cov } x T_{ p,cov->imm }
			//		 andT_{ s } = T_{ s,med->cov } x T_{ s,cov->imm }
			//		 with T_{ p,med->cov } = 2 * ref_med * cos(theta_med) / [ref_med * cos(theta_cov) + ref_cov * cos(theta_med)]
			//		 andT_{ s,med->cov } = 2 * ref_med * cos(theta_med) / [ref_med * cos(theta_med) + ref_cov * cos(theta_cov)]
			//		 in case of index matching the overall amplitude scaling is with
			//		 [1 / sqrt(cos(theta_med))] x T_{ p,s }

			Amplitude(nn, mm) = (ApertureMask(nn, mm) * sqrt(cosThetaImm(nn, mm)) * conj(cosThetaMed(nn, mm)));
			Amplitude(nn, mm) = Amplitude(nn, mm) / (refmed * cosThetaMed(nn, mm) * conj(cosThetaMed(nn, mm)));
		}
	}

	double Strehlnorm = 0.0;
	for (int jj = 0; jj < 2; jj++) {
		for (int kk = 0; kk < 3; kk++)
		{
			complex<double>csumtemp (0.0, 0.0);
			for (int nn = 0; nn < Npupil; nn++)
			{
				for (int mm = 0; mm < Npupil; mm++)
				{
					csumtemp = csumtemp + Amplitude(nn, mm) * exp(2.0 * 1i * M_PI) * PolarizationVector(nn, mm, jj, kk);
				}
			}
			Strehlnorm += pow2(abs(csumtemp));
		}
	}

	const int Nz = 101;
	double linspace = (double)(AllParams.ZSpread[1] - AllParams.ZSpread[0]) / double(Nz - 1);

	std::vector<double> zpos(Nz);
	std::vector<double>Strehl(Nz);
	Arr2D<std::complex<double> >Wzpos(Npupil, Npupil);
	for (int jz = 0; jz < Nz; jz++)
	{
		zpos[jz] = 3.0 / 2.0 * (AllParams.ZSpread[0] + jz * linspace);

		zvals[0] = AllParams.Fwd - 1.25 * (refimm / refmed) * AllParams.Depth + zpos[jz];
		Wzpos = cosThetaImm * complex<double>(zvals[0] * refimm)
				- cosThetaImmnom * complex<double>(zvals[1] * refimmnom)
				-cosThetaMed * complex<double>(zvals[2] * refmed);
		Wzpos = Wzpos*ApertureMask;
		for (int itel = 0; itel < 2; itel++)
		{
			for (int jtel = 0; jtel < 3; jtel++)
			{

				complex<double> csumtemp (0.0);
				for (int nn = 0; nn < Npupil; nn++)
				{
					for (int mm = 0; mm < Npupil; mm++)
					{
						csumtemp = csumtemp + Amplitude(nn, mm) * exp(2.0 * 1i * M_PI*Wzpos(nn,mm)/lambda)
											  * PolarizationVector(nn, mm, itel, jtel);
					}
				}
				Strehl[jz] = Strehl[jz] + pow2(abs(csumtemp))/ Strehlnorm;

			}
		}
	}


	int indz;
	indz = std::max_element(Strehl.begin(), Strehl.end()) - Strehl.begin();
	//double maxvlalue = *std::max_element(Strehl.begin(), Strehl.end());
	if (indz <= 2)
	{
		indz = 2;
	}
	else if (indz > (Nz - 4))
	{
		indz = Nz - 4;
	}
	std::vector<double>zfit(3);
	std::vector<double>x(5);
	std::vector<double>y(5);
	for (int ii = 0; ii < 5; ii++)
	{
		x[ii] = zpos[indz - 2 + ii];
		y[ii] = Strehl[indz - 2 + ii];

	}

	//the following code computes the polynomial fitting.
	int i, j, k, N, n;
	N = x.size();
	n = 2;

	//Array that will store the values of sigma(xi),sigma(xi^2),sigma(xi^3)....sigma(xi^2n)
	std::vector<double>X(2 * n + 1, 0);
	std::vector<double> a(n + 1, 0);
	Arr2D<double> B(n + 1, n + 2); //B is the Normal matrix(augmented) that will store the equations, 'a' is for value of the final coefficients
	for (i = 0; i < 2 * n + 1; i++)
	{
		X[i] = 0;
		for (j = 0; j < N; j++)
		{
			X[i] = X[i] + pow(x[j], i);        //consecutive positions of the array will store N,sigma(xi),sigma(xi^2),sigma(xi^3)....sigma(xi^2n)
		}
	}
	for (i = 0; i <= n; i++)
	{
		for (j = 0; j <= n; j++)
		{
			B(i, j) = X[i + j];
		}
	}

	std::vector<double> Y(n + 1, 0);                    //Array to store the values of sigma(yi),sigma(xi*yi),sigma(xi^2*yi)...sigma(xi^n*yi)
	for (i = 0; i < n + 1; i++)
	{
		Y[i] = 0;
		for (j = 0; j < N; j++) {
			Y[i] = Y[i] + pow(x[j], i) * y[j];        //consecutive positions will store sigma(yi),sigma(xi*yi),sigma(xi^2*yi)...sigma(xi^n*yi)
		}
	}

	for (i = 0; i <= n; i++) {
		B(i, n + 1) = Y[i];                //load the values of Y as the last column of B(Normal Matrix but augmented)
	}


	double temp;
	n = n + 1;                //n is made n+1 because the Gaussian Elimination part below was for n equations, but here n is the degree of polynomial and for n degree we get n+1 equations
	for (i = 0; i < n; i++) {                    //From now Gaussian Elimination starts(can be ignored) to solve the set of linear equations (Pivotisation)
		for (k = i + 1; k < n; k++) {
			//if (fabs(B(i, i)) < fabs(B(k, i))) {
			if (B(i, i) < B(k, i)) {
				for (j = 0; j <= n; j++)
				{
					temp = B(i, j);
					B(i, j) = B(k, j);
					B(k, j) = temp;
				}
			}
		}
	}
	double t;
	for (i = 0; i < n - 1; i++) {        //From now Gaussian Elimination starts(can be ignored) to solve the set of linear equations (Pivotisation)
		for (k = i + 1; k < n; k++)
		{
			t = B(k, i) / B(i, i);
			for (j = 0; j <= n; j++)
			{
				B(k, j) = B(k, j) - t * B(i, j);    //make the elements below the pivot element
			}

		}
	}
	for (i = n - 1; i >= 0; i--)         //back-substitution
	{									//x is an array whose values correspond to the values of x,y,z..
		a[i] = B(i, n);                //make the variable to be calculated equal to the rhs of the last equation
		for (j = 0; j < n; j++)
		{
			if (j != i)
			{
				a[i] = a[i] - B(i, j) * a[j];
			}
		}
		a[i] = a[i] / B(i, i);            //now finally divide the rhs by the coefficient of the variable to be calculated
	}

	for (i = 0; i < n; i++) {
		zfit[i] = a[n - 1 - i];
	}

	zvals[0] = AllParams.Fwd - 1.25 * (refimm / refmed) * AllParams.Depth - zfit[1] / (2.0 * zfit[0]);
	return zvals;
}

fixed_vector<double, 3> GetSafFocus(
		const PupilParams& AllParams,
		const Arr4D<std::complex<double>>& PolarizationVector,
		const Arr2D<std::complex<double>>& Amplitude,
		const Arr2D<std::complex<double>>& Waberration,
		const Arr2D<double>& XPupil,
		const Arr2D<double>& YPupil,
		Arr2D<std::complex<double>> cosThetaMed,
		Arr2D<std::complex<double>> cosThetaImm,
		Arr2D<std::complex<double>> cosThetaImmnom,
		Arr2D<std::complex<double>> ApertureMask)
{
	// This function calculates the pupil matrix Q_{ jk }, which gives the j - the electric field component proportional to the k - th dipole vector component.
	double NA = AllParams.NA;
	double refmed = AllParams.RefMed;
	double refcov = AllParams.RefCov;
	double refimm = AllParams.RefImm;
	double refimmnom = AllParams.RefImmNom;
	double lambda = AllParams.Lambda;
	int Npupil = AllParams.NPupil;

	fixed_vector<double, 3> zvals;
	zvals[0] = 0.0;
	zvals[1] = AllParams.Fwd;
	zvals[2] = -AllParams.Depth;

	double PupilSize = 1.0;
	double DxyPupil = 2 * PupilSize / (double)Npupil;

	double Strehlnorm = 0.0;
	for (int jj = 0; jj < 2; jj++)
	{
		for (int kk = 0; kk < 3; kk++)
		{
			complex<double>csumtemp (0.0);
			for (int nn = 0; nn < Npupil; nn++)
			{
				for (int mm = 0; mm < Npupil; mm++)
				{
					csumtemp += Amplitude(nn, mm) * exp(2.0 * 1i * M_PI*Waberration(nn,mm)/lambda) * PolarizationVector(nn, mm, jj, kk);
				}
			}

			Strehlnorm += pow2(abs(csumtemp));
		}
	}

	const int Nz = 15;
	double minzpos = -250;
	double maxzpos = 250;
	double linspace= (double)(maxzpos - minzpos) / double(Nz - 1);
	std::vector<double> zpos(Nz);
	std::vector<double>Strehl(Nz);
	Arr2D<std::complex<double>> Wzpos(Npupil, Npupil);
	for (int jz = 0; jz < Nz; jz++)
	{
		zpos[jz] = minzpos + jz * linspace;
		zvals[0] = AllParams.Fwd - 1.25 * (refimm / refmed) * AllParams.Depth + zpos[jz];

		Wzpos = cosThetaImm * std::complex<double>(zvals[0] * refimm)
				- cosThetaImmnom * std::complex<double>(zvals[1] * refimmnom)
				- cosThetaMed * std::complex<double>(zvals[2] * refmed);
		Wzpos = Wzpos * ApertureMask;

		for (int itel = 0; itel < 2; itel++)
		{
			for (int jtel = 0; jtel < 3; jtel++)
			{
				std::complex<double>csumtemp (0.0);
				for (int nn = 0; nn < Npupil; nn++)
				{
					for (int mm = 0; mm < Npupil; mm++)
					{
						csumtemp += Amplitude(nn, mm) * exp(2.0 * 1i * M_PI * (Wzpos(nn, mm)+ Waberration(nn, mm)) / lambda)
											  * PolarizationVector(nn, mm, itel, jtel);
					}
				}

				Strehl[jz] += pow2(abs(csumtemp)) / Strehlnorm;
			}
		}
	}

	int indz;
	indz = std::max_element(Strehl.begin(), Strehl.end()) - Strehl.begin();
	//double maxvlalue = *std::max_element(Strehl.begin(), Strehl.end());
	if (indz <= 2)
	{
		indz = 2;
	}
	else if (indz > (Nz - 4))
	{
		indz = Nz - 4;
	}

	std::vector<double>zfit(3);
	std::vector<double>x(5);
	std::vector<double>y(5);
	for (int ii = 0; ii < 5; ii++)
	{
		x[ii] = zpos[indz - 2 + ii];
		y[ii] = Strehl[indz - 2 + ii];
	}


	//the following code computes the polynomial fitting.
	int i, j, k, N, n;
	N = x.size();
	n = 2;

	//Array that will store the values of sigma(xi),sigma(xi^2),sigma(xi^3)....sigma(xi^2n)
	std::vector<double>X(2 * n + 1, 0);
	std::vector<double> a(n + 1, 0);
	Arr2D<double> B(n + 1, n + 2); //B is the Normal matrix(augmented) that will store the equations, 'a' is for value of the final coefficients
	for (i = 0; i < 2 * n + 1; i++)
	{
		X[i] = 0;
		for (j = 0; j < N; j++)
		{
			X[i] = X[i] + pow(x[j], i);        //consecutive positions of the array will store N,sigma(xi),sigma(xi^2),sigma(xi^3)....sigma(xi^2n)
		}
	}
	for (i = 0; i <= n; i++)
	{
		for (j = 0; j <= n; j++)
		{
			B(i,j) = X[i + j];
		}
	}

	std::vector<double> Y(n + 1, 0);                    //Array to store the values of sigma(yi),sigma(xi*yi),sigma(xi^2*yi)...sigma(xi^n*yi)
	for (i = 0; i < n + 1; i++)
	{
		Y[i] = 0;
		for (j = 0; j < N; j++) {
			Y[i] = Y[i] + pow(x[j], i) * y[j];        //consecutive positions will store sigma(yi),sigma(xi*yi),sigma(xi^2*yi)...sigma(xi^n*yi)
		}
	}

	for (i = 0; i <= n; i++) {
		B(i, n + 1) = Y[i];                //load the values of Y as the last column of B(Normal Matrix but augmented)
	}


	double temp;
	n = n + 1;                //n is made n+1 because the Gaussian Elimination part below was for n equations, but here n is the degree of polynomial and for n degree we get n+1 equations
	for (i = 0; i < n; i++) {                    //From now Gaussian Elimination starts(can be ignored) to solve the set of linear equations (Pivotisation)
		for (k = i + 1; k < n; k++) {
			//if (fabs(B(i, i)) < fabs(B(k, i))) {
			if (B(i, i) < B(k, i)) {
				for (j = 0; j <= n; j++)
				{
					temp = B(i, j);
					B(i, j) = B(k, j);
					B(k, j) = temp;
				}
			}
		}
	}
	double t;
	for (i = 0; i < n-1; i++) {                    //From now Gaussian Elimination starts(can be ignored) to solve the set of linear equations (Pivotisation)
		for (k = i + 1; k < n; k++)
		{
			t = B(k, i) / B(i, i);
			for (j = 0; j <= n; j++)
			{
				B(k, j) = B(k, j) - t * B(i, j);    //make the elements below the pivot element
			}

		}
	}
	for (i = n - 1; i >= 0; i--)               //back-substitution
	{                        //x is an array whose values correspond to the values of x,y,z..
		a[i] = B(i, n);                //make the variable to be calculated equal to the rhs of the last equation
		for (j = 0; j < n; j++)
		{
			if (j != i)
			{
				a[i] = a[i] - B(i, j) * a[j];
			}
		}
		a[i] = a[i] / B(i, i);            //now finally divide the rhs by the coefficient of the variable to be calculated
	}

	for (i = 0; i <n; i++) {
		zfit[i] = a[n-1-i];
	}

	zvals[0] = AllParams.Fwd - 1.25 * (refimm / refmed) * AllParams.Depth - zfit[1] / (2.0 * zfit[0]);
	return zvals;
}


fixed_vector<double, 3> getRIMismatchPars(const PupilParams& AllParams)
{
	/*
		 This function computes relevant parameters for the aberration function
		 pertaining to refractive index mismatch. In particular, the routine computes the optimum z-stage position, given the nominal free working
		 distance and imaging depth from the cover slip and the different
		 refractive index values.

		 relevant z-positions:
		 zvals = [nominal stage position, free working distance, -image depth from cover slip]

		 overall aberration function
		 W = zvals_1*W_1 - zvals_2*W_2 - zvals_3*W_3
		 W_1 = sqrt(refimm^2-rho^2*NA^2)
		 W_2 = sqrt(refimmnom^2-rho^2*NA^2)
		 W_3 = sqrt(refmed^2-rho^2*NA^2)

		 The unknown parameter zvals_1 is computed by minimizing the variance in W
		 across the pupil plane W_rms^2 = <W^2> - <W>^2, this is evaluated
		 analyticaly with Mathematica, involving:

		 Amat_{ij} = <W_i*W_j> - <W_i>*<W_j>

		 minimizing W_rms^2 w.r.t. zvals_1 gives:
		%
		 zvals_1 = (Amat_{12}/Amat_{11})*zvals_2 + (Amat_{13}/Amat_{11})*zvals_3

		 and a minimum/optimum rms wavefront aberration

		 W_rms^2 = (Amat_{22} - Amat_{12}^2/Amat_{11})*zvals_2^2
				 + (Amat_{33} - Amat_{13}^2/Amat_{11})*zvals_3^2
				 + 2*(Amat_{23} - Amat_{12}*Amat_{13}/Amat_{11})*zvals_2*zvals_3

		 The resulting expression are numerically unstable in the paraxial regime,
		 there a Taylor-series in NA is used. So far, it is assumed that all waves
		 are propagating, i.e. NA < refmed in particular, so the outcome should be
		 applied with caution to TIRF situations.

		*/

	static constexpr int K = 3;

	double refins[K];
	refins[0] = AllParams.RefImm;
	refins[1] = AllParams.RefImmNom;
	refins[2] = AllParams.RefMed;

	fixed_vector<double, K> zvals;
	zvals[0] = 0.0;
	zvals[1] = AllParams.Fwd;
	zvals[2] = -AllParams.Depth;

	double NA = AllParams.NA;
	// reduce NA in case of TIRF conditions
	if (NA > AllParams.RefMed)
	{
		NA = AllParams.RefMed;
	}

	double paraxiallimit = 0.2;

	//Arr2D<double>Wrmsratio(K, K);
	double zvalsratio[K] = {0.0};
	if (NA > paraxiallimit)
	{
		double fsqav[K] = {0.0};
		double fav[K] = {0.0};
		Arr2D<double>Amat(K, K);

		for (int jj = 0; jj < K; jj++)
		{
			fsqav[jj] = pow2(refins[jj]) - (1.0 / 2.0) * pow2(NA);
			fav[jj] = (2.0 / 3.0 / pow2(NA)) * (pow(refins[jj], 3) - pow((pow2(refins[jj]) - pow2(NA)), 1.5));
			// fav(jj) = (2 / 3) * (3 * refins[jj] ^ 4 - 3 * refins[jj] ^ 2 * NA ^ 2 + NA ^ 4) / (refins[jj] ^ 3 + (refins[jj] ^ 2 - NA ^ 2) ^ (3 / 2));
			Amat(jj, jj) = fsqav[jj] - pow(fav[jj], 2);

			if (jj > 0)
			{
				for (int kk = 0; kk < jj; kk++)
				{
					Amat(jj, kk) = (1.0 / 4.0 / pow2(NA)) * (refins[jj] * refins[kk] * (pow2(refins[jj]) +
								pow2(refins[kk])) - (pow2(refins[jj]) + pow2(refins[kk]) - 2.0 * pow2(NA)) *
								sqrt(pow2(refins[jj]) - pow2(NA)) * sqrt(pow2(refins[kk]) - pow2(NA)) +
								pow(pow2(refins[jj]) - pow2(refins[kk]), 2) * log((sqrt(pow2(refins[jj]) - pow2(NA)) +
								sqrt(pow2(refins[kk]) - pow2(NA))) / (refins[jj] + refins[kk])));
					double AmatTemp = Amat(jj, kk) - fav[jj] * fav[kk];
					Amat(kk, jj) = AmatTemp;
					Amat(jj, kk) = AmatTemp;
				}
			}
		}

		for (int jv = 1; jv < K; jv++)
		{
			zvalsratio[jv] = Amat(0, jv) / Amat(0, 0);
			/*
			for (int kv = 1; kv < K; kv++)
			{
				Wrmsratio(jv, kv) = Amat(jv, kv) - Amat(0, jv) * Amat(0, kv) / Amat(0, 0);
			}
			*/
		}
	}
	else
	{
		// paraxial limit, Taylor - series in NA
		for (int jv = 1; jv < K; jv++)
		{
			zvalsratio[jv] = refins[0] / refins[jv] + pow2(NA) * (pow(refins[0], 2) - pow(refins[jv], 2))
													  / (4 * refins[0] * pow(refins[jv], 3));
			/*
			for (int kv = 1; kv < K; kv++)
			{
				Wrmsratio(jv, kv) = pow(NA, 8) * (pow(refins[0], 2) - pow(refins[jv], 2)) * (pow(refins[0], 2) -
					pow(refins[kv], 2)) / (11520 * pow(refins[0], 4) * pow(refins[jv], 3) * pow(refins[kv], 3));
			}
			*/
		}
	}

	zvals[0] = zvalsratio[1] * zvals[1] + zvalsratio[2] * zvals[2];
	return zvals;
	//Wrms = Wrmsratio(1, 1) * pow(zvals[1],2) + Wrmsratio(2, 2) * pow(zvals(2),2) + 2 * Wrmsratio(1, 2) * zvals[1] * zvals[2];
	//Wrms = sqrt(Wrms); //compute Wrms if passed by the function
}
