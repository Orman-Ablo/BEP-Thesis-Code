#pragma once

#include <memory>

#include "container.h"

template <typename T, size_t N>
class ArrayND: public StridedContainerOps<ArrayND<T, N>, T, N, MemorySpace::Host> {
public:
	using base_type = StridedContainerOps<ArrayND<T, N>, T, N, MemorySpace::Host>;
	using typename base_type::shape_type;

	explicit ArrayND(shape_type shape) {
		resize(shape);
	}

	template <typename... Is, typename = typename std::enable_if<is_ndindex<N, Is...>>::type>
	explicit ArrayND(Is... sizes): ArrayND(shape_type{sizes...}) {
	}

	ArrayND(): ArrayND(shape_type {}) {
	}

	template <typename D2, typename T2>
	ArrayND(const Expression<D2, T2, N, MemorySpace::Host> &that) {
		*this = that;
	}

	ArrayND(const ArrayND& that) {
		*this = that;
	}

	ArrayND(ArrayND&&) noexcept = default;
	ArrayND& operator=(ArrayND&& rhs) noexcept = default;

	ArrayND& operator=(const ArrayND &rhs) {
		resize(rhs.shape());
		this->copy_from(rhs.derived());
		return *this;
	}

	template <typename D2, typename T2>
	ArrayND& operator=(const Expression<D2, T2, N, MemorySpace::Host> &rhs) {
		resize(rhs.shape());
		this->copy_from(rhs.derived());
		return *this;
	}

	CUDA_HOST_DEVICE
	stride_t stride(size_t axis) const {
		VF_ASSERT(N > 0 && axis < N);
		stride_t result = 1;

		for (size_t i = axis + 1; i < N; i++) {
			result *= sizes_[i];
		}

		return result;
	}

	CUDA_HOST_DEVICE
	dim_t size(size_t axis) const {
		VF_ASSERT(N > 0 && axis < N);
		return sizes_[axis];
	}

	CUDA_HOST_DEVICE
	T* data() {
#if CUDA_IS_HOST
		return &data_[0];
#else
		VF_PANIC("data() is not supported on device");
		return nullptr;
#endif
	}

	CUDA_HOST_DEVICE
	const T* data() const {
#if CUDA_IS_HOST
		return &data_[0];
#else
		VF_PANIC("data() is not supported on device");
		return nullptr;
#endif
	}

	VF_INLINE
	void resize(shape_type shape, T initial = {}) {
		if (shape == sizes_ && N != 0) {
			return;
		}

		size_t total = 1;
		for (size_t i = 0; i < N; i++) {
			total *= shape[i];
		}

		data_.reset(new T[total]);
		for (size_t i = 0; i < total; i++) {
			data_[i] = initial;
		}

		sizes_ = shape;
	}

	template <typename... Is, typename = typename std::enable_if<is_ndindex<N, Is...>>::type>
	VF_INLINE
	void resize(Is... sizes) {
		resize(shape_type{sizes...});
	}


private:
	std::unique_ptr<T[]> data_;
	shape_type sizes_ {};
};

template <typename T> using Arr1D = ArrayND<T, 1>;
template <typename T> using Arr2D = ArrayND<T, 2>;
template <typename T> using Arr3D = ArrayND<T, 3>;
template <typename T> using Arr4D = ArrayND<T, 4>;
template <typename T> using Arr5D = ArrayND<T, 5>;
template <typename T> using Arr6D = ArrayND<T, 6>;
template <typename T> using Arr7D = ArrayND<T, 7>;