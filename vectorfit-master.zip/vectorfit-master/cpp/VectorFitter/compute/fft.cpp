#include <mutex>

#include "compute/fft.h"

// FFTW is not threads-safe (except for fftw_execute). This lock wraps every call to `fftw_plan`
static std::mutex global_fftw_lock;

FFT1DPlan::FFT1DPlan(int n) {
	resize(n);
}

FFT1DPlan::FFT1DPlan(FFT1DPlan&& rhs) noexcept {
	*this = std::move(rhs);
}

FFT1DPlan &FFT1DPlan::operator=(FFT1DPlan&& rhs) noexcept {
	std::swap(size_, rhs.size_);
	std::swap(input_, rhs.input_);
	std::swap(output_, rhs.output_);
	std::swap(plan_forward_, rhs.plan_forward_);
	std::swap(plan_backward_, rhs.plan_backward_);
	return *this;
}

FFT1DPlan::~FFT1DPlan() {
	resize(0);
}

int FFT1DPlan::size() const {
	return size_;
}

void FFT1DPlan::resize(int n) {
	std::lock_guard<std::mutex> guard{global_fftw_lock};

	if (n == size_) return;
	if (size_ > 0) {
		fftw_free(input_);
		fftw_free(output_);
		fftw_destroy_plan(plan_backward_);
		fftw_destroy_plan(plan_forward_);

		size_ = 0;
		input_ = nullptr;
		output_ = nullptr;
	}

	if (n > 0) {
		input_ = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * n);
		output_ = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * n);
		plan_forward_ = fftw_plan_dft_1d(n, input_, output_, FFTW_FORWARD, FFTW_MEASURE);
		plan_backward_ = fftw_plan_dft_1d(n, input_, output_, FFTW_BACKWARD, FFTW_MEASURE);

		// Check if they are all non-null
		VF_ASSERT(input_ && output_ && plan_forward_ && plan_backward_);

		size_ = n;
	}
}

void FFT1DPlan::execute_forward() {
	fftw_execute(plan_forward_);
}

void FFT1DPlan::execute_backward() {
	fftw_execute(plan_backward_);
}

FFT2DPlan::FFT2DPlan(int nrows, int ncols) {
	resize(nrows, ncols);
}

FFT2DPlan::FFT2DPlan(FFT2DPlan&& rhs) noexcept {
	*this = std::move(rhs);
}

FFT2DPlan& FFT2DPlan::operator=(FFT2DPlan&& rhs) noexcept {
	std::swap(nrows_, rhs.nrows_);
	std::swap(ncols_, rhs.ncols_);
	std::swap(input_, rhs.input_);
	std::swap(output_, rhs.output_);
	std::swap(plan_forward_, rhs.plan_forward_);
	std::swap(plan_backward_, rhs.plan_backward_);
	return *this;
}

FFT2DPlan::~FFT2DPlan() {
	resize(0, 0);
}

int FFT2DPlan::nrows() const {
	return nrows_;
}

int FFT2DPlan::ncols() const {
	return ncols_;
}

void FFT2DPlan::resize(int nrows, int ncols) {
	std::lock_guard<std::mutex> guard{global_fftw_lock};

	if (nrows_ > 0 || ncols_ > 0) {
		fftw_free(input_);
		fftw_free(output_);
		fftw_destroy_plan(plan_backward_);
		fftw_destroy_plan(plan_forward_);

		nrows_ = 0;
		ncols_ = 0;
		input_ = nullptr;
		output_ = nullptr;
	}

	if (nrows > 0 || ncols > 0) {
		input_ = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * nrows * ncols);
		output_ = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * nrows * ncols);
		plan_forward_ = fftw_plan_dft_2d(nrows, ncols, input_, output_, FFTW_FORWARD, FFTW_MEASURE);
		plan_backward_ = fftw_plan_dft_2d(nrows, ncols, input_, output_, FFTW_BACKWARD, FFTW_MEASURE);

		// Check if they are all non-null
		VF_ASSERT(input_ && output_ && plan_forward_ && plan_backward_);

		nrows_ = nrows;
		ncols_ = ncols;
	}
}

void FFT2DPlan::execute_forward() {
	fftw_execute(plan_forward_);
}

void FFT2DPlan::execute_backward() {
	fftw_execute(plan_backward_);
}