/* vectorfit_destroy
 * vectorfit_create(fitter);
 * Destroys a VectorFitter object and releases its memory.
*/

#include "vectorfit_mex.hpp"
#include "vectorfit_fitter.hpp"


class MexFunction : public VectorfitMexFunction {
public:

    void execute(ArgumentList outputs, ArgumentList inputs) {
        const uint64_t handle = inputs[0][0];
        VectorfitMemoryManager::destroy(handle);
    }

    void checkArguments(ArgumentList outputs, ArgumentList inputs) {
        // Check array argument: first input must be an uint64_t scalar
        if (inputs[0].getType() != ArrayType::UINT64 ||
            inputs[0].getNumberOfElements() != 1)
        {
            feval_error("Input must be a vectorit handle in the form of a uint64 scalar");
        }

        // Check number of outputs
        if (outputs.size() != 0) {
            feval_error("No outputs are returned");
        }
    }
};
