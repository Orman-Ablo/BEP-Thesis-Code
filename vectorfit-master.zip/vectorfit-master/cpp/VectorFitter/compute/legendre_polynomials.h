#pragma once

#include "array/host_array.h"
#include "array/container.h"
#include "array/operators.h"

#include <algorithm>
#include <numeric>
#include <vector>

namespace compute {

namespace legendre_polynomials
{

template<size_t XDims>
std::vector<ArrayND<double, XDims>> get(const View1D<const int>& orders, const ArrayND<double, XDims>& x)
{
    /* Ported from Matlab implementation:

    function alllegendres = get_legendrepolynomials(orders,x)
    % This function computes the Legendre polynomials for the given orders for
    % an array of x-values (must be in the range [-1,1].
    %
    % copyright Sjoerd Stallinga, TU Delft, 2023

    */
    using placeholder::_;

    const size_t Nleg = orders.size(0);
    const int ordmax = *std::max_element(orders.begin(), orders.end());
    auto xdims = x.shape();
    int Nx = x.numel();

    // Compute for all orders up to the largest requested order.
    // Treat as flattened array regardless of the shape of x.
    // Note: order (jord) N is stored in legpols[N].
    std::vector<Arr1D<double>> legpols(ordmax+1);
    legpols[0].resize(Nx);
    legpols[0].fill(1.0);
    if (ordmax >= 1)
    {
        legpols[1].resize(Nx);
        std::copy(x.data(), x.data() + Nx, legpols[1].data());
        if (ordmax >= 2)
        {
            // Note: jord indexing is shifted by 1, compared to Matlab
            for (int jord=2; jord <= ordmax; ++jord)
            {
                int n = jord-1;
                legpols[jord].resize(Nx);
                // Compute element wise product between x and legpols[jord-1]
                Arr1D<double> prod(Nx);
                std::transform(x.data(), x.data() + x.numel(), legpols[jord-1].begin(), prod.data(), [](double a, double b){return a*b;});
                // Compute final polynomial
                legpols[jord] = (prod*(2.0*n+1) - legpols[jord-2]*(double)n) / (n+1.0);
            }
        }
    }

    // Reorder and reformat output
    std::vector<ArrayND<double, XDims>> result(orders.size(0), ArrayND<double, XDims>(x.shape()));
    for (size_t i_result=0; i_result < result.size(); ++i_result)
    {
        // Copy the flattened array of the requested order to the output array with shape equal to x.shape()
        int order = orders[i_result];
        std::copy(legpols[order].data(), legpols[order].data() + Nx, result[i_result].data());
    }

    return result;
}

template<size_t XYDims>
std::vector<ArrayND<double, XYDims>> get2D(const Arr2D<int>& orders, const ArrayND<double, XYDims>& x, const ArrayND<double, XYDims>& y)
{
    /* Ported from Matlab implementation:

    function alllegendres2D = get_legendrepolynomials2D(orders,x,y)
    % This function computes products of Legendre polynomials in x and y for
    % the given set of order combinations. We use products
    %
    %   P2D(n,m,x,y) = P(n,x)*P(m,y)
    %
    % where the input is expected as [n1 m1; n2 m2; ....], and where
    %   n,m = 0,1,2,...
    %
    % copyright Sjoerd Stallinga, TU Delft, 2023

    */
    using placeholder::_;

    View1D<int> xorders = orders.view(0, _);
    View1D<int> yorders = orders.view(1, _);
    int Nxy = x.numel();
    std::vector<ArrayND<double, XYDims>> alllegsx = get(xorders, x);
    std::vector<ArrayND<double, XYDims>> alllegsy = get(yorders, y);

    std::vector<ArrayND<double, XYDims>> result(xorders.size(0), ArrayND<double, XYDims>(x.shape()));

    // Compute the products of the Legendre polynomials in x and y
    for (size_t i_order=0; i_order < alllegsx.size(); ++i_order)
    {
        const ArrayND<double, XYDims>& legpols_x = alllegsx[i_order];
        const ArrayND<double, XYDims>& legpols_y = alllegsy[i_order];

        // Compute element wise product and store in result
        std::transform(
            legpols_x.data(), legpols_x.data() + x.numel(),
            legpols_y.data(),
            result[i_order].data(),
            [](double a, double b){return a*b;}
        );
    }

    return result;
}

} // namespace legendre_polynomials

} // namespace compute
