#pragma once

#include "types.cuh"
#include "array/core.h"

void* cuda_malloc(size_t nbytes);
void cuda_free(void* ptr);

void* cuda_malloc_pinned(size_t nbytes);
void cuda_free_pinned(void* ptr);

void cuda_copy_raw(const void* src, void *dst, size_t nbytes);
void cuda_copy_raw(
		const void* src,
		void *dst,
		size_t rank,
		const stride_t* src_strides_input,
		const stride_t* dst_strides_input,
		const dim_t* counts_input,
		size_t elem_size);