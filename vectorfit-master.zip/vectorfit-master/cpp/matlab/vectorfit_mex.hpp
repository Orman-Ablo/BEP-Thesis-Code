/* vectorfit_get_zernike_coefficients
 * z_coeffs = vectorfit_get_zernike_coefficients(xn, yn, gammas, params);
 * Calculates the Zernike coefficients, given gamma coefficients and x,y locations.
 * - xn,yn: coordinates or meshgrid of points for which we want to determine
 *   the Zernike coefficients. Units: physical coordinates of the total FOV
 *   (um) where the origin is at the outer edge of pixel 1,1.
 * - gammas: the gamma coefficients that determine how the Zernike
 *   Coefficients depend on x,y.
 *
 * returns an array or surface containing the zernike coeffcients in nm for each point (xn,yn)
*/

#ifdef DLL_EXPORT_SYM
    // Apparent conflict with the CMake matlab_add_mex() macro,
    // which adds this symbol as compiler definition, while
    // it is also defined in mex.hpp.
    #undef DLL_EXPORT_SYM
#endif

#include "mex.hpp"
#include "mexAdapter.hpp"


class VectorfitMexFunction : public matlab::mex::Function {
public:
    using ArgumentList = matlab::mex::ArgumentList;
    using Array = matlab::data::Array;
    using ArrayFactory = matlab::data::ArrayFactory;
    template<typename T> using TypedArray = typename matlab::data::TypedArray<T>;
    using ArrayType = matlab::data::ArrayType;

    void operator()(ArgumentList outputs, ArgumentList inputs) {
        checkArguments(outputs, inputs);
        execute(outputs, inputs);
    }

    virtual void checkArguments(ArgumentList outputs, ArgumentList inputs) = 0;
    virtual void execute(ArgumentList outputs, ArgumentList inputs) = 0;

    // Helper function to return an error message
    void feval_error(const std::string& error_msg) {
        _matlab_engine->feval(u"error",
            0,
            std::vector<Array>({ _array_factory.createScalar(error_msg) })
        );
    }

    // Helper function to display a message.
    // A newline character is added automatically.
    // Apparently, some compilers do not support the use of std::cout.
    void feval_print(const std::string& msg) {
        // Pass stream content to MATLAB fprintf function
        _matlab_engine->feval(u"fprintf", 0,
            std::vector<Array>({ _array_factory.createScalar(msg + "\n") })
        );
    }

protected:
    // Array factory
    ArrayFactory _array_factory;
    // Get pointer to engine
    std::shared_ptr<matlab::engine::MATLABEngine> _matlab_engine = getEngine();
};
