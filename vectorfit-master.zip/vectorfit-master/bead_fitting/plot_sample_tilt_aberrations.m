% Plot sample tilt and aberrations

% Load data
path_input_data = 'N:\tnw\IST\QI\users\idroste\Data\beads_example_for_yutong\Nanoruler\Raw data\CalibBead\Output\Cali1031_100bead_Oil100x_Col0-17_ex488_P50_400ms_EM100_Col170-Cntr_IsabelAnalysis\results.mat';
load(path_input_data)

Ncfg_total = size(allspots,4);

% Remove spots with zero aberrations
[~,idx] = ind2sub(size(theta.local(6:end,:)),find(theta.local(6:end,:)==0));
nonzero_idx = setdiff(1:Ncfg_total,idx);

%% Plot sample tilt
[Xq,Yq] = meshgrid(1:512*params.pixelsize*1e-3);
X = roixy(1,nonzero_idx)*params.pixelsize*1e-3;
Y = roixy(2,nonzero_idx)*params.pixelsize*1e-3;
Zq = griddata(X,Y,theta.local(3,nonzero_idx),Xq,Yq,"cubic");

figure
int_surf = surf(Xq,Yq,Zq,'FaceAlpha',0.7);
shading interp
hold on
beads = plot3(X,Y,theta.local(3,nonzero_idx),"o",'LineWidth',2);
xlabel('x (\mum)')
ylabel('y (\mum)')
zlabel('z (nm)')
legend('Interpolated surface','bead z-value')
ax = gca;
ax.FontSize = 16;

%% Plot aberrations

X = roixy(1,nonzero_idx)*params.pixelsize*1e-3;
Y = roixy(2,nonzero_idx)*params.pixelsize*1e-3;

labels = ["A(2,-2)" "A(2,2)" "A(3,-1)" "A(3,1)" "A(4,0)"];
for izer = 6:10
    hsub = subplot(2,3,izer-5);
    V = 1e3*theta.local(izer,nonzero_idx)/params.lambda;
    Vq = griddata(X,Y,V,Xq,Yq,"cubic");
 
    surf(Xq,Yq,Vq,'FaceAlpha',0.7)
    shading interp
    hold on
    plot3(X,Y,V,"o",'LineWidth',2)
    xlabel('x (\mum)')
    ylabel('y (\mum)')
    zlabel('m\lambda')
    zlim([-80 70])
    title(labels(izer-5))
    ax = gca;
    ax.FontSize = 16;

end