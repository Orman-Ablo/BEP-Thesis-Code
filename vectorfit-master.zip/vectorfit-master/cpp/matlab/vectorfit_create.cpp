/* vectorfit_create
 * fitter = vectorfit_create(spots, roixy, params, compute_device);
 * Creates a VectorFitter object that can be referenced in other API calls.
*/

#include "vectorfit_mex.hpp"
#include "vectorfit_fitter.hpp"

#include <ctime>  // TODO: remove; for testing only
#include <cstdlib>  // TODO: remove; for testing only
#include <iomanip>  // TODO: remove; for testing only
#include <set>
#include "array/operators.h"


class MexFunction : public VectorfitMexFunction {
public:
    using Struct = matlab::data::Struct;
    using StructArray = matlab::data::StructArray;
    using CharArray = matlab::data::CharArray;

    void execute(ArgumentList outputs, ArgumentList inputs) {
        // Parse configuration parameters
        matlab::data::StringArray input_compute_device_array = std::move(inputs[3]);
        std::string compute_device = input_compute_device_array[0];
        if (
            compute_device != "gpu"
            && compute_device != "gpu-lowaccuracy"
            && compute_device != "cpu"
        ) {
            feval_error("Compute device must be either \"cpu\", \"gpu\" or \"gpu-lowaccuracy\"");
        }
        StructArray input_params_array = std::move(inputs[2]);
        ParamsParser params_parser(input_params_array);
        FitParams params = params_parser.parse();

        // Handle unparsed params
        std::string default_params = params_parser.get_default_params();
        if (!default_params.empty()) {
            feval_print("NOTE: using default values for: " + default_params + ".");
        }

        // Populate spot data
        // The input layout from Matlab is (x, y, z, spot_index),
        // where x=row, y=column (size(z)=1) and memory layout must be column major.
        // The VectorfitFitter layout is (spot_index, x, y, z)
        TypedArray<double> input_spots = std::move(inputs[0]);
        matlab::data::ArrayDimensions dims = input_spots.getDimensions();
        size_t num_spots = dims[3];
        size_t num_x = dims[0];
        size_t num_y = dims[1];
        size_t num_z = dims[2]; // Must be 1! See checkArguments().
        size_t num_spot_elements = num_x*num_y;
        Arr4D<double> spots((int)num_spots, (int)num_x, (int)num_y, (int)num_z);

        // Copy spot data
        // Note: only column major Matlab memory layout is supported
        size_t i_el=0;
        for (const auto& value : input_spots)
        {
            int x = (int)(i_el % num_x);
            int y = (int)((i_el / num_x) % num_y);
            int z = 0;
            int spot_index = (int)(i_el / num_spot_elements);
            spots.access({spot_index, x, y, z}) = value;
            ++i_el;
        }

        // Copy roixy data
        // Note: only column major Matlab memory layout is supported
        TypedArray<double> input_roixy = std::move(inputs[1]);
        Arr2D<double> roixy_colmajor((int)num_spots, 2);
        std::copy(input_roixy.begin(), input_roixy.end(), roixy_colmajor.data());
        // Swap axes
        Arr2D<double> roixy = roixy_colmajor.reorder_axes({1, 0});

        // Debug output
        std::cout << "Loaded spot data for " << (int)spots.size(0) << " spots." << std::endl;

        // Create VectorfitFitter object
        uint64_t handle = _memory_manager.create(
            std::move(spots), std::move(roixy), std::move(params), compute_device
        );
        // Return its handle
        outputs[0] = _array_factory.createScalar(handle);
    }

    void checkArguments(ArgumentList outputs, ArgumentList inputs) {
        // Check array arguments
        if (inputs.size() != 4) {
            feval_error("Number of required inputs is 4: (spots, roixy, params, compute_device)");
        }
        // First input must be double array
        if (inputs[0].getType() != ArrayType::DOUBLE ||
            inputs[0].getType() == ArrayType::COMPLEX_DOUBLE ||
            inputs[0].getDimensions().size() != 4)
        {
            feval_error("Input 1 must be 4-dimensional double array");
        }

        // Verify that the spots are 2D
        size_t num_z = inputs[0].getDimensions()[2];
        if (num_z != 1)
        {
            feval_error("Length of z-dimension must be 1");
        }
        // Verify column major memory layout
        if (inputs[0].getMemoryLayout() != matlab::data::MemoryLayout::COLUMN_MAJOR)
        {
            feval_error("Currently, only column major memory layout is supported");
        }

        // Second input must be double array
        if (inputs[1].getType() != ArrayType::DOUBLE ||
            inputs[1].getType() == ArrayType::COMPLEX_DOUBLE ||
            inputs[1].getDimensions().size() != 2)
        {
            feval_error("Input 2 must be 2-dimensional double array");
        }

        // Third input must be the params struct
        if (inputs[2].getType() != ArrayType::STRUCT)
        {
            feval_error("Input 3 must be a params struct");
        }

        // Fourth input must be a string
        if (inputs[3].getType() != ArrayType::MATLAB_STRING)
        {
            feval_error("Input 4 must be a string");
        }

        // Check number of outputs
        if (outputs.size() != 1) {
            feval_error("Only one output is returned");
        }
    }

protected:
    class ParamsParser {
    public:
        ParamsParser(const StructArray& params_struct_array)
        : _params_struct_array(params_struct_array)
        , _params_struct(params_struct_array[0])
        {}

        FitParams parse() {
            // This function parses the fit params
            // using the Matlab variable naming convention.
            //
            // It is highly advised to pass a value for every parameter.
            // available. If any default values are used, the user receives
            // a notification. This helps prevent accidental use of
            // unset/default parameter values due to typo's etc.
            std::string model = parse_string("fitmodel", "xy");
            // Perform translation from Matlab fitmodel names to C++ names
            // by replacing substrings. This allows for additions after the base name.
            // Note: put longest names first in the map to prevent partial replacement!
            static const std::vector<std::pair<std::string, std::string>> fitmodel_names_map{
                {"xy-gamma-legendre", "xy"},  // before "xy-gamma"
                {"xy-gamma", "xy"},
                {"xyz-gamma-legendre", "xyz"},  // before "xyz-gamma"
                {"xyz-gamma", "xyz"},
            };
            for (const auto& name_pair : fitmodel_names_map) {
                if (model.find(name_pair.first) != std::string::npos) {
                    model.replace(0, name_pair.first.size(), name_pair.second);
                    std::cout << "Translated fitmodel to: " << model << std::endl;
                    break;
                }
            }
            // Obtain FitModelEnum from its name
            FitModelEnum fitModel = FitParams::get_fitmodel_from_string(model);
            FitParams out(fitModel);

            out.NA = parse_double("NA", out.NA);
            out.RefMed = parse_double("refmed", out.RefMed);
            out.RefCov = parse_double("refcov", out.RefCov);
            out.RefImm = parse_double("refimm", out.RefImm);
            out.RefImmNom = parse_double("refimmnom", out.RefCov);
            out.Lambda = parse_double("lambda", out.Lambda);
            out.LambdaCentral = parse_double("lambdacentral", out.LambdaCentral);
            out.LambdaSpread = parse_param_array<double, 2>("lambdaspread", out.LambdaSpread);
            out.imgSizeX = parse_int("imgSizeX", out.imgSizeX);
            out.imgSizeY = parse_int("imgSizeY", out.imgSizeY);
            out.NiterMax = parse_int("max_local_iterations", out.NiterMax);
            out.Tollim = parse_double("tollim", out.Tollim);
            out.Varfit = parse_double("varfit", out.Varfit);
            out.NPupil = parse_int("Npupil", out.NPupil);

            out.PixelSize = parse_double("pixelsize", out.PixelSize);
            out.SamplingDistance = parse_double("samplingdistance", out.PixelSize);
            out.Fwd = parse_double("fwd", out.Fwd);
            out.Depth = parse_double("depth", out.Depth);
            out.ZRange = parse_param_array<double, 2>("zrange", out.ZRange);
            out.ZSpread = parse_param_array<double, 2>("zspread", out.ZSpread);

            out.zstage = parse_double("zstage", out.zstage);

            out.Mx = parse_int("Mx", out.Mx);
            out.My = parse_int("My", out.default_my());
            out.Mz = parse_int("Mz", out.Mz);

            int K = parse_int("K", 1);
            if (K > 1 && !fitModel.has_z()) {
                throw std::runtime_error("Failed to set parameter K: cannot have K > 1 if fit model does not have Z");
            }
            out.Mz = K;

            out.XRange = parse_double("xrange", out.default_x_range());
            out.YRange = parse_double("yrange", out.default_y_range());
            out.PupilSize = parse_double("pupilsize", out.default_pupil_size());

            out.ZType = parse_enum("ztype", out.ZType, {
                {"stage", ZTypeEnum::stage},
                {"medium", ZTypeEnum::medium}
            });

            out.DoeType = parse_enum("doetype", out.DoeType, {
                {"vortex", DoeTypeEnum::vortex},
                {"none", DoeTypeEnum::none}
            });

            out.DipoleType = parse_enum("dipoletype", out.DipoleType, {
                {"free", DipoleTypeEnum::free},
                {"fixed", DipoleTypeEnum::fixed},
                {"diffusion", DipoleTypeEnum::diffusion}
            });

            out.Excitation = parse_enum("excitation", out.Excitation, {
                {"constant", ExcitationEnum::constant},
                {"zstack", ExcitationEnum::zstack}
            });

            out.RingRadius = parse_int("ringradius", out.RingRadius);
            out.DoeLevels = parse_int("doelevels", out.DoeLevels);
            out.DoePhaseDepth = parse_int("doephasedepth", out.DoePhaseDepth);
            out.DoeVortexFlip = parse_int("doevortexflip", out.DoeVortexFlip);

            out.Alpha = parse_double("alpha", out.Alpha);
            out.Beta = parse_double("beta", out.Beta);
            out.ReadNoiseStd = parse_double("readnoisestd", out.ReadNoiseStd);
            out.ReadNoiseVariance = parse_double("readnoisevariance", out.ReadNoiseVariance);

            out.Notfx = parse_int("Notfx", out.Notfx);
            out.Notfy = parse_int("Notfy", out.Notfy);
            if (fitModel.has_z()) {
                out.Notfz = parse_int("Notfz", out.Notfz);
            } // else: use default value of 1
            out.Mpsfx = parse_int("Mpsfx", out.Mpsfx);
            out.Mpsfy = parse_int("Mpsfy", out.Mpsfy);
            if (fitModel.has_z()) {
                out.Mpsfz = parse_int("Mpsfz", out.Mpsfz);
            } // else: use default value of 1
            out.PsfXRange = parse_double("psfxrange", out.default_psf_x_range());
            out.PsfYRange = parse_double("psfyrange", out.default_psf_y_range());
            out.PsfZRange = parse_double("psfzrange", out.default_psf_z_range());
            out.FlagOTF = parse_bool("FlagOTF", out.FlagOTF);
            out.OTFGridSizeX = parse_int("OTFGridSizeX", out.OTFGridSizeX);
            out.OTFGridSizeY = parse_int("OTFGridSizeY", out.OTFGridSizeY);

            out.psf_blur = parse_bool("PSFBlur", fitModel.has_fitted_aberrations());

            out.initialization = parse_enum("initialization", out.initialization, {
                    {"phasor", InitializationMethod::phasor},
                    {"centroid", InitializationMethod::centroid},
            });

            if (out.FlagOTF
                && (out.FitModel != FitModelEnum::xy)
                && (out.FitModel != FitModelEnum::xy_constaberrations)
                && (out.FitModel != FitModelEnum::xyz)
                && (out.FitModel != FitModelEnum::xyz_constaberrations)
            ) {
                throw std::runtime_error("OTF is only supported for fitmodels 'xy(z)' and 'xy(z)_constaberrations'");
            }

            out.NumThreads = parse_int("NumThreads", out.NumThreads);

            return out;
        }

        // Returns comma separated string of unused parameter names
        std::string get_unparsed_params() const {
            std::set<std::string> unparsed_params;
            // Add all input fields to unparsed_params and remove the parsed ones
            for (const auto& input_param : _params_struct_array.getFieldNames()) {
                unparsed_params.insert((std::string)input_param);
            }

            for (const std::string& parsed_param : _parsed_params) {
                unparsed_params.erase(parsed_param);
            }
            std::string unparsed_param_names;
            for (const std::string& param_name : unparsed_params) {
                if (!unparsed_param_names.empty())
                {
                    unparsed_param_names += ", ";
                }
                unparsed_param_names += param_name;
            }
            return unparsed_param_names;
        }

        // Returns comma separated string of parameter names for which default values are used
        std::string get_default_params() const {
            std::string default_param_names;
            for (const std::string& param_name : _default_params) {
                if (!default_param_names.empty())
                {
                    default_param_names += ", ";
                }
                default_param_names += param_name;
            }
            return default_param_names;
        }

    protected:
        StructArray _params_struct_array;
        Struct _params_struct;
        std::set<std::string> _parsed_params;
        std::set<std::string> _default_params;

        void register_parsed_param(const std::string& param_name) {
            _parsed_params.insert(param_name);
        }

        void register_default_param(const std::string& param_name) {
            _default_params.insert(param_name);
        }

        template<typename T>
        T parse_param(const std::string& key, T default_value) {
            try {
                register_parsed_param(key);
                TypedArray<T> val_arr = _params_struct[key];
                T value = val_arr[0];
                std::cout << "Setting param: " << key << " = " << value << std::endl;
                return value;
            } catch (const matlab::data::InvalidFieldNameException& ex) {
                register_default_param(key);
                std::cout << "Setting param: " << key << " = " << default_value << " (default)" << std::endl;
                return default_value;
            }
        }

        template<typename T, int SIZE>
        fixed_vector<T, SIZE> parse_param_array(const std::string& key, fixed_vector<T, SIZE> default_value = {}) {
            try {
                register_parsed_param(key);
                TypedArray<T> val_arr = _params_struct[key];
                fixed_vector<T, SIZE> value;
                // Verify array size
                if (val_arr.getNumberOfElements() != value.size()) {
                    throw std::invalid_argument(
                        "Parameter '" + key + "' has " + std::to_string(val_arr.getNumberOfElements())
                        + " instead of " + std::to_string(value.size()) + " elements"
                    );
                }
                std::copy(val_arr.cbegin(), val_arr.cend(), value.begin());
                std::cout << "Setting param: " << key << " = " << value << std::endl;
                return value;
            } catch (const matlab::data::InvalidFieldNameException& ex) {
                register_default_param(key);
                std::cout << "Setting param: " << key << " = " << default_value << " (default)" << std::endl;
                return default_value;
            }
        }

        template<typename T>
        T parse_enum(const std::string& key, T default_value, std::vector<std::pair<std::string, T>> options) {
            try {
                register_parsed_param(key);
                CharArray val_arr = _params_struct[key];
                std::string enum_name = val_arr.toAscii();

                for (const auto& p : options) {
                    if (enum_name == p.first) {
                        T value = p.second;
                        std::cout << "Setting param: " << key << " = " << enum_name << std::endl;
                        return value;
                    }
                }

                // Enum name not found
                throw std::invalid_argument("Parameter " + key + " has invalid value: " + enum_name);
            } catch (const matlab::data::InvalidFieldNameException& ex) {
                register_default_param(key);
                for (const auto& p : options) {
                    if (default_value == p.second) {
                        const std::string& enum_name = p.first;
                        std::cout << "Setting param: " << key << " = " << enum_name << " (default)" << std::endl;
                        break;
                    }
                }
                return default_value;
            }
        }

        double parse_double(const std::string& key, double default_value) {
            return parse_param<double>(key, default_value);
        }

        int64_t parse_int(const std::string& key, int default_value) {
            try {
                return parse_param<int64_t>(key, default_value);
            } catch (const matlab::data::InvalidArrayTypeException& ex) {
                // Try double conversion as fallback;
                // a const int may have been passed as a double by Matlab.
                std::cout << "(Note: reading '" << key << "' as int64 failed, trying to read it as double...)" << std::endl;
                return (int64_t)std::round(parse_param<double>(key, default_value));
            }
        }

        bool parse_bool(const std::string& key, bool default_value) {
            try {
                return parse_param<bool>(key, default_value);
            } catch (const matlab::data::InvalidArrayTypeException& ex) {
                // Try int conversion as fallback;
                // a bool may have been passed as an int by Matlab.
                try {
                    std::cout << "(Note: reading '" << key << "' as bool failed, trying to read it as int64...)" << std::endl;
                    return (bool)parse_param<int64_t>(key, default_value);
                } catch (const matlab::data::InvalidArrayTypeException& ex) {
                    // Try double conversion as fallback;
                    // a bool may have been passed as a double by matlab.
                    std::cout << "(Note: reading '" << key << "' as bool failed, trying to read it as double..)" << std::endl;
                    return (bool)std::round(parse_param<double>(key, default_value));
                }
            }
        }

        std::string parse_string(const std::string& key, const std::string& default_value) {
            try {
                register_parsed_param(key);
                CharArray val_arr = _params_struct[key];
                std::string value = val_arr.toAscii();
                std::cout << "Setting param: " << key << " = " << value << std::endl;
                return value;
            } catch (const matlab::data::InvalidFieldNameException& ex) {
                register_default_param(key);
                std::cout << "Setting param: " << key << " = " << default_value << " (default)" << std::endl;
                return default_value;
            }
        }
    };

    VectorfitMemoryManager _memory_manager;
};
