#include <iostream>
#include <vector>

#include "files.h"
#include "MultiDimArray.h"

using namespace std;

bool fileExists(const std::string& filename) {
	// Is this really the best way?
	return bool(std::ifstream(filename));
}

void readBinaryImage(const string& filename, WriteView3D<double> spotread)
{
	int mx = spotread.size(0);
	int my = spotread.size(1);
	int mz = spotread.size(2);

	std::vector<double> getdouble(mx * my * mz);
	ifstream myfile(filename, ios::in | ios::binary | ios::ate);

	if (!myfile)
	{
		throw std::runtime_error("failed to open for reading: " + filename);
	}

	streampos size = myfile.tellg();
	streampos expected_size = getdouble.size() * sizeof(double);

	if (size != expected_size)
	{
		throw std::runtime_error("file " + filename + " has invalid size, expecting "
								 + std::to_string(expected_size) + " bytes");
	}

	myfile.seekg(0, ios::beg);
	myfile.read((char*) getdouble.data(), size);

	for (int ii = 0; ii < mx; ii++)
	{
		for (int jj = 0; jj < my; jj++)
		{
			for (int kk = 0; kk < mz; kk++)
			{
				spotread(ii, jj, kk) = getdouble[(ii * my + jj) * mz + kk];
			}
		}
	}
}

void readBinaryImage(const string& filename, WriteView2D<double> spotread)
{
	using namespace placeholder;
	readBinaryImage(filename, spotread.view(_, _, newaxis()));
}

void writeBinaryImage(const string& filename, View3D<double> spotread)
{
	ofstream pmFile(filename, ios::binary | ios::out | ios::trunc);

	if (!pmFile)
	{
		throw std::runtime_error("failed to open for writing: " + filename);
	}

	for (int i = 0; i < spotread.size(0); i++)
	{
		for (int j = 0; j < spotread.size(1); j++)
		{
			for (int k = 0; k < spotread.size(2); k++)
			{
				double ctemp = spotread(i, j, k);
				pmFile.write(reinterpret_cast<char *>(&ctemp), sizeof(double));
			}
		}
	}
}

void writeBinaryImage(const string& filename, View2D<double> spotread)
{
	using namespace placeholder;
	writeBinaryImage(filename, spotread.view(_, _, newaxis(1)));
}

void writeBinaryImage(const string& filename, View1D<double> spotread)
{
	using namespace placeholder;
	writeBinaryImage(filename, spotread.view(_, newaxis(1), newaxis(1)));
}



