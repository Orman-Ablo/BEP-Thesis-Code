#pragma once

#include "Parameters.h"
#include "MultiDimArray.h"
#include "compute/czt.h"
#include "compute/common.h"

namespace compute {

inline void PSFfromOTF(
		const FitParams& AllParams,
		const SpotParameters& spot,
		CztPlan& czt,
		View3D<std::complex<double>> OTF,
		WriteView3D<double> Psf,
		WriteView4D<double> PsfDer
) {
	using namespace placeholder;
	using namespace std::complex_literals;

	const int Mx = AllParams.Mx;
	const int My = AllParams.My;
	const int Mz = AllParams.Mz;
	const int Notfx = AllParams.Notfx;
	const int Notfy = AllParams.Notfy;
	int Notfz = AllParams.Notfz;
	const bool with_z = AllParams.FitModel.has_z();
	if (!with_z) {
		// Set Notfz to 1 for xy models
		Notfz = 1;
	}
	double xemit = spot.XEmit;
	double yemit = spot.YEmit;
	double zemit = spot.ZEmit;
	double lambda = AllParams.Lambda;
	double NA = AllParams.NA;
	double FourierWindow = 2.0;  // Also called 'OTFSize'
	double DxyFourier = 2.0 * FourierWindow / Notfx;

	VF_ASSERT(
		(AllParams.FitModel == FitModelEnum::xy)
		|| (AllParams.FitModel == FitModelEnum::xy_constaberrations)
		|| (AllParams.FitModel == FitModelEnum::xyz)
		|| (AllParams.FitModel == FitModelEnum::xyz_constaberrations)
	);
	int numparams = AllParams.FitModel.num_parameters();
	VF_ASSERT(OTF.shape() == shape(Notfx, Notfy, Notfz));
	VF_ASSERT(Psf.shape() == shape(Mx, My, Mz));
	VF_ASSERT(PsfDer.shape() == shape(Mx, My, Mz, numparams));

	// spatial frequency grid, scaled with (-i * 2 * pi * NA / lambda)
	std::complex<double> xyFourierScale = (-1i * 2.0 * M_PI * NA / lambda);
	auto xyFourierScaled = [=](int ii){
		return xyFourierScale * (-FourierWindow + DxyFourier / 2.0 + ii * DxyFourier);
	};
	////////////////////////////////

	// generate OTF
	Arr2D<std::complex<double>> OTFtemp(Notfx, Notfy);
	Arr2D<std::complex<double>> OTFzmasked;
	Arr2D<std::complex<double>> zOTF;
	Arr2D<std::complex<double>> dOTFdx(Notfx, Notfy);
	Arr2D<std::complex<double>> dOTFdy(Notfx, Notfy);
	Arr2D<std::complex<double>> dOTFdz;
	Arr2D<std::complex<double>> P(Mx, My);
	Arr2D<std::complex<double>> Pdx(Mx, My);
	Arr2D<std::complex<double>> Pdy(Mx, My);
	Arr2D<std::complex<double>> Pdz;
	if (with_z)
	{
		// Only reserve memory if needed
		OTFzmasked.resize(Notfx, Notfy);
		zOTF.resize(Notfx, Notfy);
		dOTFdz.resize(Notfx, Notfy);
		Pdz.resize(Mx, My);

		// FourierWindow for z: larger range than default cutoff
		// (size=1) to accommodate possible RI mismatch.
		const double FourierWindowz = 2.0;
		const std::complex<double> DzOTF = 2*FourierWindowz/Notfz;
		const double refin = AllParams.RefImmNom;
		const double NA = AllParams.NA;
		// Compute 2D OTF from 3D OTF and z-derivative
		// Compute scaling factors per z-slice and store in zFactors.
		// The first dimension has two elements:
		// - [0]: mask factor for computing the 2D OTF
		// - [1]: factor used while computing the z-derivative
		Arr2D<std::complex<double>> zFactors(2, Notfz);
		for (int jz=0; jz< Notfz; ++jz)
		{
			std::complex<double> ZOTF = -FourierWindowz + (jz + 0.5) * DzOTF;
			std::complex<double> wavevectorz = (2.0*M_PI*(refin - sqrt(refin*refin - NA*NA))/lambda)*ZOTF;
			std::complex<double> ZPositionPhaseMask = exp(-1i * zemit * wavevectorz);
			zFactors(0, jz) = ZPositionPhaseMask * DzOTF;
			// Derivative
			std::complex<double> diffZPositionPhaseMask = -1i*wavevectorz*ZPositionPhaseMask;
			zFactors(1, jz) = diffZPositionPhaseMask * DzOTF;
		}
		// Reduce 3D OTF to 2D otf using the computed zFactors.
		for (int jx=0; jx< Notfx; ++jx)
		{
			for (int jy=0; jy< Notfy; ++jy)
			{
				std::complex<double> otf_2d_val_xy{0, 0};
				std::complex<double> otf_zder_val_xy{0, 0};
				for (int jz=0; jz< Notfz; ++jz)
				{
					const std::complex<double>& otf_val = OTF(jx, jy, jz);
					otf_2d_val_xy += otf_val * zFactors(0, jz);
					otf_zder_val_xy += otf_val * zFactors(1, jz);
				}
				OTFzmasked(jx, jy) = otf_2d_val_xy;
				zOTF(jx, jy) = otf_zder_val_xy;
			}
		}
	}

	View2D<std::complex<double>> OTF2d = with_z ? OTFzmasked.view() : OTF.drop_axis(2);

	// compute shifted PSFs from the 2D OTF
	for (int ii = 0; ii < Notfx; ii++)
	{
		for (int jj = 0; jj < Notfy; jj++)
		{
			std::complex<double> PositionPhaseMask = exp(xyFourierScaled(ii) * xemit + xyFourierScaled(jj) * yemit);
			OTFtemp(ii, jj) = OTF2d(ii,jj) * PositionPhaseMask;
			dOTFdx(ii, jj) = OTFtemp(ii, jj) * xyFourierScaled(ii);
			dOTFdy(ii, jj) = OTFtemp(ii, jj) * xyFourierScaled(jj);
			if (with_z)
			{
				dOTFdz(ii, jj) = zOTF(ii,jj) * PositionPhaseMask;
			}
		}
	}

	czt.execute(OTFtemp, P);
	czt.execute(dOTFdx, Pdx);
	czt.execute(dOTFdy, Pdy);
	if (with_z)
	{
		// TODO: get separate czt for z-direction
		czt.execute(dOTFdz, Pdz);
	}

	for (int ii = 0; ii < Mx; ii++)
	{
		for (int jj = 0; jj < My; jj++)
		{
			Psf(ii, jj, 0) = real(P(ii, jj));
			PsfDer(ii, jj, 0, 0) = real(Pdx(ii, jj));
			PsfDer(ii, jj, 0, 1) = real(Pdy(ii, jj));
			if (with_z)
			{
				PsfDer(ii, jj, 0, 2) = real(Pdz(ii, jj));
			}
			// Set to zero for Nph, Nbg
			PsfDer(ii, jj, 0, numparams-2) = 0;
			PsfDer(ii, jj, 0, numparams-1) = 0;
		}
	}

	// Note: normalization not needed if FourierWindow = 2.0!
}

inline void PSFtoMu(
		const FitParams& AllParams,
		const SpotParameters& spot,
		View3D<double> Psf,
		View4D<double> PsfDer,
		WriteView3D<double> mu,
		WriteView4D<double> dmudtheta
) {
	// Take Mx,My,Mz from Psf
	int Mx = Psf.size(0);
	int My = Psf.size(1);
	int Mz = Psf.size(2);
	int K = Mz;
	FitModelEnum fitmodel = AllParams.FitModel;
	int numparams = fitmodel.num_parameters();

	VF_ASSERT(mu.shape() == Psf.shape());
	VF_ASSERT(PsfDer.shape() == shape(Mx, My, Mz, numparams));
	VF_ASSERT(dmudtheta.shape() == PsfDer.shape());

	double Nph = spot.Nph;
	double Nbg = spot.Nbg;

	Arr1D<double> P(K);
	P.fill(1.0);

	Arr1D<double> dPdazim(K);
	Arr1D<double> dPdpola(K);

	//Get Poisson rate and derivatives
	mu.fill(0.0);
	dmudtheta.fill(0.0);

	if (AllParams.Excitation == ExcitationEnum::zstack)
	{
		for (int ii = 0; ii < Mx; ii++)
		{
			for (int jj = 0; jj < My; jj++)
			{
				for (int kk = 0; kk < K; kk++)
				{
					mu(ii, jj, kk) = Nph * Psf(ii, jj, kk) + Nbg;
					dmudtheta(ii, jj, kk, 0) = Nph * PsfDer(ii, jj, kk, 0);
					dmudtheta(ii, jj, kk, 1) = Nph * PsfDer(ii, jj, kk, 1);
					dmudtheta(ii, jj, kk, 2) = Nph * PsfDer(ii, jj, kk, 2);
					dmudtheta(ii, jj, kk, 3) = Psf(ii, jj, kk);

					switch (AllParams.FitModel)
					{
						case FitModelEnum::xyz:
						case FitModelEnum::xyz_constaberrations:
							dmudtheta(ii, jj, kk, 4) = 1.0 / K;
							break;
						case FitModelEnum::xyz_azim_pola_diffusion:
							dmudtheta(ii, jj, kk, 4) = 1.0 / K;
							dmudtheta(ii, jj, kk, 5) = Nph * PsfDer(ii, jj, kk, 3);
							dmudtheta(ii, jj, kk, 6) = Nph * PsfDer(ii, jj, kk, 4);
							dmudtheta(ii, jj, kk, 7) = Nph * PsfDer(ii, jj, kk, 5);
							break;
						case FitModelEnum::xyz_aberrations:
							dmudtheta(ii, jj, kk, 4) = 1.0 / K;
							for (int nn = 5; nn < numparams; nn++)
							{
								dmudtheta(ii, jj, kk, nn) = Nph * PsfDer(ii, jj, kk, nn - 2);
							}
							break;
						case FitModelEnum::xyz_azim_pola_diffusion_aberrations:
							dmudtheta(ii, jj, kk, 4) = 1.0 / K;
							dmudtheta(ii, jj, kk, 5) = Nph * PsfDer(ii, jj, kk, 3);
							dmudtheta(ii, jj, kk, 6) = Nph * PsfDer(ii, jj, kk, 4);
							dmudtheta(ii, jj, kk, 7) = Nph * PsfDer(ii, jj, kk, 5);
							for (int nn = 8; nn < numparams; nn++)
							{
								dmudtheta(ii, jj, kk, nn) = Nph * PsfDer(ii, jj, kk, nn);

							}
							break;
						default:
							throw std::runtime_error("unknown fit model");
							break;
					}
				}
			}
		}
	}
	else
	{
		for (int kk = 0; kk < K; kk++)
		{
			for (int ii = 0; ii < Mx; ii++)
			{
				for (int jj = 0; jj < My; jj++)
				{
					mu(ii, jj, kk) = Nph * P[kk] * Psf(ii, jj, kk) + Nbg;
					dmudtheta(ii, jj, kk, 0) = Nph * P[kk] * PsfDer(ii, jj, kk, 0);
					dmudtheta(ii, jj, kk, 1) = Nph * P[kk] * PsfDer(ii, jj, kk, 1);

					if (fitmodel == FitModelEnum::xy_azim_pola && K > 1)
					{
						dmudtheta(ii, jj, kk, 2) = P[kk] * Psf(ii, jj, kk);
						dmudtheta(ii, jj, kk, 3) = 1.0 / K;
						dmudtheta(ii, jj, kk, 4) = Nph * P[kk] * PsfDer(ii, jj, kk, 2) + Nph * dPdazim[kk] * Psf(ii, jj, kk);
						dmudtheta(ii, jj, kk, 5) = Nph * P[kk] * PsfDer(ii, jj, kk, 3) + Nph * dPdpola[kk] * Psf(ii, jj, kk);
					}

					switch (AllParams.FitModel)
					{
						case FitModelEnum::xy:
						case FitModelEnum::xy_constaberrations:
							dmudtheta(ii, jj, kk, 2) = P[kk] * Psf(ii, jj, kk);
							dmudtheta(ii, jj, kk, 3) = 1.0 / K;
							break;
						case FitModelEnum::xyz:
						case FitModelEnum::xyz_constaberrations:
							dmudtheta(ii, jj, kk, 2) = Nph * P[kk] * PsfDer(ii, jj, kk, 2);
							dmudtheta(ii, jj, kk, 3) = P[kk] * Psf(ii, jj, kk);
							dmudtheta(ii, jj, kk, 4) = 1.0 / K;
							break;
						case FitModelEnum::xyz_azim_pola_diffusion:
							dmudtheta(ii, jj, kk, 2) = Nph * P[kk] * PsfDer(ii, jj, kk, 2);
							dmudtheta(ii, jj, kk, 3) = P[kk] * Psf(ii, jj, kk);
							dmudtheta(ii, jj, kk, 4) = 1.0 / K;

							dmudtheta(ii, jj, kk, 5) = Nph * P[kk] * PsfDer(ii, jj, kk, 3) + Nph * dPdazim[kk] * Psf(ii, jj, kk);
							dmudtheta(ii, jj, kk, 6) = Nph * P[kk] * PsfDer(ii, jj, kk, 4) + Nph * dPdpola[kk] * Psf(ii, jj, kk);
							dmudtheta(ii, jj, kk, 7) = Nph * P[kk] * PsfDer(ii, jj, kk, 5);
							break;
						case FitModelEnum::xy_azim:
							dmudtheta(ii, jj, kk, 2) = P[kk] * Psf(ii, jj, kk);
							dmudtheta(ii, jj, kk, 3) = 1.0 / K;

							dmudtheta(ii, jj, kk, 4) = Nph * P[kk] * PsfDer(ii, jj, kk, 2) + Nph * dPdazim[kk] * Psf(ii, jj, kk);
							break;
						case FitModelEnum::xy_azim_pola:
							dmudtheta(ii, jj, kk, 2) = P[kk] * Psf(ii, jj, kk);
							dmudtheta(ii, jj, kk, 3) = 1.0 / K;

							dmudtheta(ii, jj, kk, 4) = Nph * P[kk] * PsfDer(ii, jj, kk, 2) + Nph * dPdazim[kk] * Psf(ii, jj, kk);
							dmudtheta(ii, jj, kk, 5) = Nph * P[kk] * PsfDer(ii, jj, kk, 3) + Nph * dPdpola[kk] * Psf(ii, jj, kk);
							break;
						case FitModelEnum::xyz_azim_pola:
							dmudtheta(ii, jj, kk, 2) = Nph * P[kk] * PsfDer(ii, jj, kk, 2);
							dmudtheta(ii, jj, kk, 3) = P[kk] * Psf(ii, jj, kk);
							dmudtheta(ii, jj, kk, 4) = 1.0 / K;

							dmudtheta(ii, jj, kk, 5) = Nph * P[kk] * PsfDer(ii, jj, kk, 3) + Nph * dPdazim[kk] * Psf(ii, jj, kk);
							dmudtheta(ii, jj, kk, 6) = Nph * P[kk] * PsfDer(ii, jj, kk, 4) + Nph * dPdpola[kk] * Psf(ii, jj, kk);
							break;
						case FitModelEnum::xy_azim_diffusion:
							dmudtheta(ii, jj, kk, 2) = P[kk] * Psf(ii, jj, kk);
							dmudtheta(ii, jj, kk, 3) = 1.0 / K;

							dmudtheta(ii, jj, kk, 4) = Nph * P[kk] * PsfDer(ii, jj, kk, 2) + Nph * dPdazim[kk] * Psf(ii, jj, kk);
							dmudtheta(ii, jj, kk, 5) = Nph * P[kk] * PsfDer(ii, jj, kk, 3);
							break;
						case FitModelEnum::xy_azim_pola_diffusion:
							dmudtheta(ii, jj, kk, 2) = P[kk] * Psf(ii, jj, kk);
							dmudtheta(ii, jj, kk, 3) = 1.0 / K;

							dmudtheta(ii, jj, kk, 4) = Nph * P[kk] * PsfDer(ii, jj, kk, 2) + Nph * dPdazim[kk] * Psf(ii, jj, kk);
							dmudtheta(ii, jj, kk, 5) = Nph * P[kk] * PsfDer(ii, jj, kk, 3) + Nph * dPdpola[kk] * Psf(ii, jj, kk);
							dmudtheta(ii, jj, kk, 6) = Nph * P[kk] * PsfDer(ii, jj, kk, 4);
							break;

						default:
							throw std::runtime_error("unknown fit model");
							break;
					}
				}
			}
		}
	}
}

inline void GetFieldMatrixDerivatives(
		const FitParams& AllParams,
		const SpotParameters& spot,
		CztPlan& czt,
		View4D<std::complex<double>> PupilMatrix,
		View3D<std::complex<double>> WaveVector,
		View2D<std::complex<double>> WaveVectorZImm,
		View3D<double> AllZernikes,
		WriteView5D<std::complex<double>> FieldMatrix,
		WriteView6D<std::complex<double>> FieldMatrixDer,
		bool fit_aberrations
) {
	using namespace std::complex_literals;
	using namespace placeholder;

	/* This function calculates the field matrix A_{ jk }, which gives the j - th electric field component proportional to the k - th dipole vector
		component, as well as the derivatives of A_{ jk } w.r.t.the xyz coordinates of the emitter and w.r.t.the emission wavelength lambda.
		parameters: NA, refractive indices of medium, wavelength(in nm), nominal emitter position(in nm) with z - position from cover slip - medium interface,
		spot footprint(in nm), axial range(in nm), sampling in pupil with(even), sampling in image plane(odd), sampling in axial direction
	*/
	// Take Mx,My,Mz from FieldMatrix
	int Mx = FieldMatrix.size(0);
	int My = FieldMatrix.size(1);
	int Mz = FieldMatrix.size(2);
	int K = Mz;

	double zstage = AllParams.zstage;
	double xemit = spot.XEmit;
	double  yemit = spot.YEmit;
	const int Npupil = AllParams.NPupil;
	const int NAberr = AllParams.FitModel.num_aberrations();

	int numders = 2;
	int xyzders = 2;

	if (AllParams.FitModel.has_z()) {
		// One more derivative for Z
		numders++;
		xyzders++;

		// NAberr more derivatives if aberrations are fitted
		if (AllParams.FitModel.has_fitted_aberrations()) {
			numders += NAberr;
		}
	}

	VF_ASSERT(PupilMatrix.shape() == shape(Npupil, Npupil, 2, 3));
	VF_ASSERT(WaveVector.shape() == shape(Npupil, Npupil, 3));
	VF_ASSERT(WaveVectorZImm.shape() == shape(Npupil, Npupil));
	VF_ASSERT(AllZernikes.shape() == shape(Npupil, Npupil, NAberr));
	VF_ASSERT(FieldMatrix.shape() == shape(Mx, My, K, 2, 3));
	VF_ASSERT(FieldMatrixDer.shape() == shape(Mx, My, K, numders, 2, 3));

	auto normfac = [&](int ii) {
		double orders[2];

		for (int jj = 0; jj < 2; jj++)
		{
			orders[jj] = AllParams.AberrationOrders[ii][jj];
		}

		return sqrt(2 * (orders[0] + 1) / (1 + double(orders[1] == 0)));
	};

	// preallocate
	Arr2D<std::complex<double>> PupilFunction(Npupil, Npupil);
	Arr3D<std::complex<double>> PupilFunctionDer(Npupil, Npupil, numders); // zeros(Npupil, Npupil, numders, 2, 3);
	Arr2D<std::complex<double>> PositionPhaseMask(Npupil, Npupil);  //Initialization for complex type? check!

	int nlayers = AllParams.Excitation == ExcitationEnum::zstack ? Mz : 1;

	// Loop over Z-stack
	for (int jz = 0; jz < nlayers; jz++)//define numel() total elements in ZImage
	{
		//define z-stack
		double zmin = AllParams.ZRange[0];
		double zmax = AllParams.ZRange[1];

		double DzImage = (zmax - zmin) / K;
		double zemitrun = zmin + (jz + 0.5) * DzImage;
		double zemit = spot.ZEmit;

		for (int ii = 0; ii < Npupil; ii++)
		{
			for (int jj = 0; jj < Npupil; jj++)
			{
				std::complex<double> Wpos = WaveVector(ii, jj, 0) * xemit + WaveVector(ii, jj, 1) * yemit;

				if (AllParams.Excitation == ExcitationEnum::zstack)
				{
					if (fit_aberrations)
					{
						if (AllParams.ZType == ZTypeEnum::stage)
						{
							Wpos += zemit * WaveVector(ii, jj, 2) + (zstage + zemitrun) * WaveVectorZImm(ii, jj);
						}
						else if (AllParams.ZType == ZTypeEnum::medium)
						{
							Wpos += (zemit + zemitrun) * WaveVector(ii, jj, 2) + zstage * WaveVectorZImm(ii, jj);
						}
					}
					else
					{
						if (AllParams.ZType == ZTypeEnum::stage)
						{
							Wpos += WaveVectorZImm(ii, jj) * (zemit - zemitrun);
						}
						else if (AllParams.ZType == ZTypeEnum::medium)
						{
							Wpos += WaveVector(ii, jj, 2) * (zemit - zemitrun);
						}
					}
				}
				else
				{
					if (AllParams.ZType == ZTypeEnum::stage)
					{
						Wpos += WaveVectorZImm(ii, jj) * zemit;
					}
					else if (AllParams.ZType == ZTypeEnum::medium)
					{
						Wpos += WaveVector(ii, jj, 2) * zemit;
					}
				}

				PositionPhaseMask(ii, jj) = exp(-1i * Wpos);
			}
		}

		for (int mm = 0; mm < 2; mm++)
		{
			for (int nn = 0; nn < 3; nn++)
			{
				for (int ii = 0; ii < Npupil; ii++)
				{
					for (int jj = 0; jj < Npupil; jj++)
					{
						// Pupil function
						PupilFunction(ii, jj) = PositionPhaseMask(ii, jj) * PupilMatrix(ii, jj, mm, nn);
					}
				}

				czt.execute(
						PupilFunction,
						FieldMatrix.view(_, _, jz, mm, nn));


				for (int ii = 0; ii < Npupil; ii++)
				{
					for (int jj = 0; jj < Npupil; jj++)
					{
						//pupil functions for xy - derivatives
						PupilFunctionDer(ii, jj, 0) = -1i * WaveVector(ii, jj, 0) * PupilFunction(ii, jj);
						PupilFunctionDer(ii, jj, 1) = -1i * WaveVector(ii, jj, 1) * PupilFunction(ii, jj);

						// Pupil functions for z - derivatives
						if (AllParams.FitModel.has_z())
						{
							if (AllParams.ZType == ZTypeEnum::stage)
							{
								PupilFunctionDer(ii, jj, 2) = -1i * WaveVectorZImm(ii, jj) * PupilFunction(ii, jj);
							}
							else
							{
								PupilFunctionDer(ii, jj, 2) = -1i * WaveVector(ii, jj, 2) * PupilFunction(ii, jj);
							}
						}

						// pupil functions for Zernike mode - derivative and FT to matrix elements
						if (AllParams.FitModel.has_fitted_aberrations())
						{
							for (int jzer = 0; jzer < NAberr; jzer++) //size of Aberrations=12
							{
								index_t jder = xyzders + jzer; //3 for z stack

								PupilFunctionDer(ii, jj, jder) = (2 * M_PI * 1i * normfac(jzer) * AllZernikes(ii, jj, jzer) / AllParams.Lambda)
																 * PositionPhaseMask(ii, jj) * PupilMatrix(ii, jj, mm, nn);
							}
						}
					}
				}

				for (int der = 0; der < numders; der++)
				{
					czt.execute(
							PupilFunctionDer.view(_, _, der),
							FieldMatrixDer.view(_, _, jz, der, mm, nn));
				}
			}
		}
	}
}

inline double Likelihood(
		const FitParams& AllParams,
		View3D<double> OneSpot,
		View3D<double> mu)
{
	/*returns the log - likelihood, as well as firstand second order derivatives w.r.t.the parameters for a noisy image M,
		measured in number of photons per pixel, and Poisson - rate mu with first order derivatives dmudtheta.
		The log - likelihood is Poisson + readout - noise based.
	*/
	double varfit = AllParams.Varfit;

	int Mx = AllParams.Mx;
	int My = AllParams.My;
	int Mz = AllParams.Mz;
	double keps = 1000.0 * EPS;

	VF_ASSERT(OneSpot.shape() == shape(Mx, My, Mz));
	VF_ASSERT(mu.shape() == shape(Mx, My, Mz));

	double merit = 0;

	for (int ii = 0; ii < Mx; ii++)
	{
		for (int jj = 0; jj < My; jj++)
		{
			for (int kk = 0; kk < Mz; kk++)
			{
				double mupos;
				if (mu(ii, jj, kk) < 0.0)
				{
					mupos = keps;
				}
				else
				{
					mupos = mu(ii, jj, kk);
				}

				merit += (OneSpot(ii, jj, kk) + varfit) * log(mupos + varfit) - (mupos + varfit);
			}
		}
	}

	return merit;
}

inline void ComputeThetaDerivate(
		const FitParams& AllParams,
		View3D<double> OneSpot,
		View3D<double> mu,
		View4D<double> dmudtheta,
		WriteView1D<double> grad,
		WriteView2D<double> Hessian)
{
	/*returns the log - likelihood, as well as firstand second order derivatives w.r.t.the parameters for a noisy image M,
		measured in number of photons per pixel, and Poisson - rate mu with first order derivatives dmudtheta.
		The log - likelihood is Poisson + readout - noise based.
	*/
	double varfit = AllParams.Varfit;

	int Mx = OneSpot.size(0);
	int My = OneSpot.size(1);
	int Mz = OneSpot.size(2);
	int numparams = grad.size(0);
	double keps = 1000.0 * EPS;

	VF_ASSERT(OneSpot.shape() == shape(Mx, My, Mz));
	VF_ASSERT(mu.shape() == shape(Mx, My, Mz));
	VF_ASSERT(dmudtheta.shape() == shape(Mx, My, Mz, numparams));
	VF_ASSERT(grad.shape() == shape(numparams));
	VF_ASSERT(Hessian.shape() == shape(numparams, numparams));

	grad.fill(0);
	Hessian.fill(0);

	for (int ii = 0; ii < Mx; ii++)
	{
		for (int jj = 0; jj < My; jj++)
		{
			for (int kk = 0; kk < Mz; kk++)
			{
				double mupos;
				if (mu(ii, jj, kk) < 0.0)
				{
					mupos = keps;
				}
				else
				{
					mupos = mu(ii, jj, kk);
				}

				double weight = (OneSpot(ii, jj, kk) - mupos) / (mupos + varfit);
				double dweight = (OneSpot(ii, jj, kk) + varfit) / pow2((mupos + varfit));

				for (int nn = 0; nn < numparams; nn++)
				{
					grad[nn] += weight * dmudtheta(ii, jj, kk, nn);

					for (int mm = 0; mm < numparams; mm++)
					{
						Hessian(nn, mm) += -dweight * dmudtheta(ii, jj, kk, nn)
										   * dmudtheta(ii, jj, kk, mm);
					}
				}
			}
		}
	}
}

inline void GetFixedPsfDerivatives(
		const FitParams& AllParams,
		double azim,
		double pola,
		FitModelEnum fitmodel,
		double normint_fixed,
		View5D<std::complex<double>> FieldMatrix,
		View6D<std::complex<double>> FieldMatrixDer,
		WriteView3D<double> FixedPSF,
		WriteView4D<double> FixedPSFder
) {
	int Mx = FieldMatrix.size(0);
	int My = FieldMatrix.size(1);
	int Mz = FieldMatrix.size(2);

	// dipole vectorand derivatives
	double dipor[3] = {0};
	dipor[0]=sin(pola) * cos(azim);
	dipor[1]=sin(pola) * sin(azim);
	dipor[2]=cos(pola);

	double diporDerivativesAzim[3] = {};
	diporDerivativesAzim[0] = -sin(pola) * sin(azim);
	diporDerivativesAzim[1] = sin(pola) * cos(azim);
	diporDerivativesAzim[2] = 0;

	double diporDerivativesPola[3] = {};
	diporDerivativesPola[0] = cos(pola) * cos(azim);
	diporDerivativesPola[1] = cos(pola) * sin(azim);
	diporDerivativesPola[2] = -sin(pola);

	for (int ii = 0; ii < Mx; ii++)
	{
		for (int jj = 0; jj < My; jj++)
		{
			for (int kk = 0; kk < Mz; kk++)
			{
				// electric field components and derivatives
				std::complex<double> Ex = dipor[0] * FieldMatrix(ii, jj, kk, 0, 0)
						+ dipor[1] * FieldMatrix(ii, jj, kk, 0, 1)
						+ dipor[2] * FieldMatrix(ii, jj, kk, 0, 2);
				std::complex<double> Ey = dipor[0] * FieldMatrix(ii, jj, kk, 1, 0)
						+ dipor[1] * FieldMatrix(ii, jj, kk, 1, 1)
						+ dipor[2] * FieldMatrix(ii, jj, kk, 1, 2);
				FixedPSF(ii, jj, kk) = (norm(Ex) + norm(Ey)) / normint_fixed;

				auto calculate_xy_der = [&](std::complex<double> Exder, std::complex<double> Eyder) {
					double der = 2 * real(conj(Ex) * Exder) + 2 * real(conj(Ey) * Eyder);
					return der / normint_fixed;
				};

				auto calculate_der = [&](int ll) {
					std::complex<double> Exder = dipor[0] * FieldMatrixDer(ii, jj, kk, ll, 0, 0)
							+ dipor[1] * FieldMatrixDer(ii, jj, kk, ll, 0, 1)
							+ dipor[2] * FieldMatrixDer(ii, jj, kk, ll, 0, 2);
					std::complex<double> Eyder = dipor[0] * FieldMatrixDer(ii, jj, kk, ll, 1, 0)
							+ dipor[1] * FieldMatrixDer(ii, jj, kk, ll, 1, 1)
							+ dipor[2] * FieldMatrixDer(ii, jj, kk, ll, 1, 2);
					return calculate_xy_der(Exder, Eyder);
				};

				int psf_index = 0;
				int field_index = 0;
				FixedPSFder(ii, jj, kk, psf_index++) = calculate_der(field_index++); // x
				FixedPSFder(ii, jj, kk, psf_index++) = calculate_der(field_index++); // y

				if (fitmodel.has_z())
				{
					FixedPSFder(ii, jj, kk, psf_index++) = calculate_der(field_index++);
				}

				//azim
				if (fitmodel.has_azim())
				{
					std::complex<double> Exder = diporDerivativesAzim[0] * FieldMatrix(ii, jj, kk, 0, 0)
							+ diporDerivativesAzim[1] * FieldMatrix(ii, jj, kk, 0, 1)
							+ diporDerivativesAzim[2] * FieldMatrix(ii, jj, kk, 0, 2);
					std::complex<double> Eyder = diporDerivativesAzim[0] * FieldMatrix(ii, jj, kk, 1, 0)
							+ diporDerivativesAzim[1] * FieldMatrix(ii, jj, kk, 1, 1)
							+ diporDerivativesAzim[2] * FieldMatrix(ii, jj, kk, 1, 2);
					FixedPSFder(ii, jj, kk, psf_index++) = calculate_xy_der(Exder, Eyder);
				}

				//pola
				if (fitmodel.has_pola())
				{
					std::complex<double> Exder = diporDerivativesPola[0] * FieldMatrix(ii, jj, kk, 0, 0)
							+ diporDerivativesPola[1] * FieldMatrix(ii, jj, kk, 0, 1)
							+ diporDerivativesPola[2] * FieldMatrix(ii, jj, kk, 0, 2);
					std::complex<double> Eyder = diporDerivativesPola[0] * FieldMatrix(ii, jj, kk, 1, 0)
							+ diporDerivativesPola[1] * FieldMatrix(ii, jj, kk, 1, 1)
							+ diporDerivativesPola[2] * FieldMatrix(ii, jj, kk, 1, 2);
					FixedPSFder(ii, jj, kk, psf_index++) = calculate_xy_der(Exder, Eyder);
				}

				if (fitmodel.has_diffusion())
				{
					FixedPSFder(ii, jj, kk, psf_index++) = 0;
				}

				if (fitmodel.has_fitted_aberrations())
				{
					for (int aa = 0; aa < fitmodel.num_aberrations(); aa++)
					{
						FixedPSFder(ii, jj, kk, psf_index++) = calculate_der(field_index++);
					}
				}
			}
		}
	}
}

inline void GetFreePsfDerivatives(
		const FitParams& AllParams,
		FitModelEnum fitmodel,
		double normint_free,
		View5D<std::complex<double>> FieldMatrix,
		View6D<std::complex<double>> FieldMatrixDer,
		WriteView3D<double> FreePSF,
		WriteView4D<double> FreePSFder
) {
	int Mx = FieldMatrix.size(0);
	int My = FieldMatrix.size(1);
	int Mz = FieldMatrix.size(2);

	for (int ii = 0; ii < Mx; ii++)
	{
		for (int jj = 0; jj < My; jj++)
		{
			for (int kk = 0; kk < Mz; kk++)
			{
				//Calculation of Free PSF and derivatives
				double tempsum = 0.0;

				for (int mm = 0; mm < 2; mm++) {
					for (int nn = 0; nn < 3; nn++) {
						tempsum += norm(FieldMatrix(ii, jj, kk, mm, nn));
					}
				}

				FreePSF(ii, jj, kk) = (1.0 / 3.0) * (tempsum / normint_free);
			}
		}
	}

	for (int ii = 0; ii < Mx; ii++)
	{
		for (int jj = 0; jj < My; jj++)
		{
			for (int kk = 0; kk < Mz; kk++)
			{
				auto calculate_der = [&](int ll) {
					double sum = 0.0;
					for (int mm = 0; mm < 2; mm++)
					{
						for (int nn = 0; nn < 3; nn++)
						{
							sum += real(conj(FieldMatrix(ii, jj, kk, mm, nn)) * FieldMatrixDer(ii, jj, kk, ll, mm, nn));
						}
					}

					return (2.0 / 3.0) * (sum / normint_free);
				};

				int psf_index = 0;
				int field_index = 0;
				FreePSFder(ii, jj, kk, psf_index++) = calculate_der(field_index++); // x
				FreePSFder(ii, jj, kk, psf_index++) = calculate_der(field_index++); // y

				if (fitmodel.has_z())
				{
					FreePSFder(ii, jj, kk, psf_index++) = calculate_der(field_index++);
				}

				if (fitmodel.has_azim())
				{
					FreePSFder(ii, jj, kk, psf_index++) = 0;
				}

				if (fitmodel.has_pola())
				{
					FreePSFder(ii, jj, kk, psf_index++) = 0;
				}

				if (fitmodel.has_diffusion())
				{
					FreePSFder(ii, jj, kk, psf_index++) = 0;
				}

				if (fitmodel.has_fitted_aberrations())
				{
					for (int aa = 0; aa < fitmodel.num_aberrations(); aa++)
					{
						FreePSFder(ii, jj, kk, psf_index++) = calculate_der(field_index++);
					}
				}
			}
		}
	}
}

inline void GetPsfDerivatives(
		const FitParams& AllParams,
		const SpotParameters& spot,
		double normint_free,
		double normint_fixed,
		View5D<std::complex<double>> FieldMatrix,
		View6D<std::complex<double>> FieldMatrixDer,
		WriteView3D<double> Psf,
		WriteView4D<double> PsfDer
) {
	using namespace placeholder;

	/* This function calculates the free or fixed dipole PSFs given the field matrix, the dipole orientation, and the pupil polarization,
	as well as the derivatives w.r.t.the xyz coordinates of the emitterand w.r.t.the emission wavelength lambda.
	parameters: emitter / absorber dipole orientation(characterized by angles pola and azim).
	*/
	// Take Mx,My,Mz from Psf
	int Mx = Psf.size(0);
	int My = Psf.size(1);
	int Mz = Psf.size(2);
	int K = Mz;
	FitModelEnum fitmodel = AllParams.FitModel;
	int numparams = fitmodel.num_parameters();
	DipoleTypeEnum dipoleType = AllParams.DipoleType;

	VF_ASSERT(FieldMatrix.shape() == shape(Mx, My, K, 2, 3));
	VF_ASSERT(FieldMatrixDer.shape() == shape(Mx, My, K, FieldMatrixDer.size(3), 2, 3));
	VF_ASSERT(PsfDer.shape() == shape(Mx, My, K, PsfDer.size(3)));

	if (dipoleType == DipoleTypeEnum::free)
	{
		GetFreePsfDerivatives(
				AllParams,
				fitmodel,
				normint_free,
				FieldMatrix,
				FieldMatrixDer,
				Psf,
				PsfDer);
	}

	else if (dipoleType == DipoleTypeEnum::fixed)
	{
		GetFixedPsfDerivatives(
				AllParams,
				spot.Azim,
				spot.Pola,
				fitmodel,
				normint_fixed,
				FieldMatrix,
				FieldMatrixDer,
				Psf,
				PsfDer);
	}

	else if (dipoleType == DipoleTypeEnum::diffusion)
	{
		Arr3D<double> FreePSF(Mx, My, Mz);
		Arr4D<double> FreePSFder(Mx, My, Mz, numparams);
		GetFreePsfDerivatives(
				AllParams,
				fitmodel,
				normint_free,
				FieldMatrix,
				FieldMatrixDer,
				FreePSF,
				FreePSFder);

		Arr3D<double> FixedPSF(Mx, My, Mz);
		Arr4D<double> FixedPSFder(Mx, My, Mz, numparams);
		GetFixedPsfDerivatives(
				AllParams,
				spot.Azim,
				spot.Pola,
				fitmodel,
				normint_fixed,
				FieldMatrix,
				FieldMatrixDer,
				FixedPSF,
				FixedPSFder);

		double g2 = spot.G2;

		// -2 since Nph and Nbg do not exist in Psf
		int diffusion_index = fitmodel.offset_diffusion() - 2;

		for (int ii = 0; ii < Mx; ii++)
		{
			for (int jj = 0; jj < My; jj++)
			{
				for (int kk = 0; kk < K; kk++)
				{
					Psf(ii, jj, kk) = (1 - g2) * FreePSF(ii, jj, kk) + g2 * FixedPSF(ii, jj, kk);

					for (int dd = 0; dd < numparams; dd++)
					{
						PsfDer(ii, jj, kk, dd) = (1 - g2) * FreePSFder(ii, jj, kk, dd) + g2 * FixedPSFder(ii, jj, kk, dd);
					}

					// Set the diffusion factor.
					if (fitmodel.has_diffusion())
					{
						PsfDer(ii, jj, kk, diffusion_index) = -FreePSF(ii, jj, kk) + FixedPSF(ii, jj, kk);
					}
				}
			}
		}
	}
}

inline void DoPixelBlurring(
		const FitParams& AllParams,
		FFT2DPlan& plan,
		View2D<double> PSFin,
		WriteView2D<double> PSFout) {
		/* This function blurs a computed spot due to the effect of a non - zero
	pixel size, by low - pass filtering with the sinc - shaped kernel arising
	from the square pixel size.
	PSFin: Mx x My(x Mz) array of a through - focus spot without pixel blurring
	oversampling : ratio of physical pixel size to sampling distance in xy - plane in PSFin
	PSFout : Mx x My(x Mz) array of a through - focus spot with pixel blurring
	copyright Sjoerd St_inga, TU Delft, 2018
	*/
	int Mx = AllParams.Mx;
	int My = AllParams.My;

	double oversampling = AllParams.PixelSize / AllParams.SamplingDistance;
	int centerx = Mx / 2;
	int centery = My / 2;

	for (int ii = 0; ii < Mx; ii++)
	{
		for (int jj = 0; jj < My; jj++)
		{
			plan.in(ii, jj) = PSFin(ii, jj);
		}
	}

	plan.execute_forward();

	//fftshift fitParams.outPB and pass it to fitParams.inPB
	for (int i = 0; i < Mx; i++) {
		for (int j = 0; j < My; j++) {
			int ii = (i + centerx) % Mx;
			int jj = (j + centery) % My;

			double sincQx = sinc(oversampling * (jj - centery) / My);
			double sincQy = sinc(oversampling * (ii - centerx) / Mx);
			double pixelblurkernel = sincQx * sincQy;

			plan.in(i, j) = plan.out(i, j) * pixelblurkernel;
		}
	}

	plan.execute_backward();

	// Get output data into 2-d form - use same array as for input
	for (int ii = 0; ii < Mx; ii++)
	{
		for (int jj = 0; jj < My; jj++)
		{
			PSFout(ii, jj) = real(plan.out(ii, jj)) / (Mx*My);
		}
	}
}

}