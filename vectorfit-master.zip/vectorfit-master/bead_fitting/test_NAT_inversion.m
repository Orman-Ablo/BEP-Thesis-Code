% Test inversion of NAT

clear all
close all

%%
%path_output_data = '/home/idroste/Desktop/TUDelft/Data/Lidke/data_analysis/beads/With_Astigmatism/results_zstack_00*';
%path_output_data = 'U:\NATaberrations\ExperimentalData\Lidke\data_analysis\DATA1\beads\With_Astigmatism\results_*';
path_output_data = 'U:\NATaberrations\ExperimentalData\Lidke\data_analysis\DATA1\beads\Without_Astigmatism\results_zstack_00*';

all_output_files = dir(path_output_data);
nr_of_outfiles = size(all_output_files,1);
fprintf('Found %i files\n',nr_of_outfiles);

theta_combined = [];
roixy_combined = [];
mu_combined = [];
allspots_combined = [];

%for file_i=1:nr_of_outfiles
for file_i=6:9

    filename = all_output_files(file_i).name
    foldername = all_output_files(file_i).folder;
    path_output_data_full = fullfile(foldername, filename);    
    
    dataout = load(path_output_data_full,'theta','roixy','mu','allspots','outliers','params');
    
    theta_temp = dataout.theta.local;
    roixy_temp = dataout.roixy;
    mu_temp = dataout.mu;
    allspots_temp = dataout.allspots;
    outliers = dataout.outliers;
    %outliers = [];
    no_outliers = setdiff(1:size(theta_temp,2),outliers);
    params = dataout.params;

    theta_combined = cat(2,theta_combined,theta_temp(:,no_outliers));
    roixy_combined = cat(2,roixy_combined,roixy_temp(:,no_outliers));
    mu_combined = cat(4,mu_combined,mu_temp(:,:,:,no_outliers));
    allspots_combined = cat(4,allspots_combined,allspots_temp(:,:,:,no_outliers));

end


errM = get_fiterror(mu_combined,allspots_combined,params);

idx_err = find(errM(1,:)>50 | errM(2,:)>50 | errM(3,:)>5e4); % Lidke 2D

small_err = setdiff(1:size(roixy_combined,2),idx_err);

theta_combined = theta_combined(:,small_err);
roixy_combined = roixy_combined(:,small_err);
mu_combined = mu_combined(:,:,:,small_err);
allspots_combined = allspots_combined(:,:,:,small_err);
%%
params.aberrations = [...
     2     0     0
     2    -2     0
     2     2     0
     3    -1     0
     3     1     0
     4     0     0];

params.NATgammas = {{[0 0 2 0 1.0],0.0},...
                     {[1 0 2 0 1.0],0.0},...
                     {[0 1 2 0 1.0],0.0},...
                     {[2 0 2 0, 1.0],[0 2 2 0, 1.0],0.0},...
                     {[0 0 2 2 1.0],0.0},...
                     {[0 0 2 -2 1.0],0.0},...
                     {[1 0 2 2 1.0],[0 1 2 -2 1.0],0.0},...
                     {[0 1 2 2 -1.0],[1 0 2 -2 1.0],0.0},...
                     {[2 0 2 2 1/sqrt(5)],[0 2 2 2 -1/sqrt(5)],[1 1 2 -2 1.0],0.0},...
                     {[0 0 3 1 1.0],0.0},...
                     {[0 0 3 -1 1.0],0.0},...
                     {[1 0 3 1 1.0],[0 1 3 -1 1.0],0.0},...
                     {[0 0 4 0 1.0],0.0}};

params.numgammas = length(params.NATgammas);
params.multiplex_factors = zeros(params.numgammas,1); 
params.numNATparvecs = 0;
for jgam = 1:params.numgammas
  RR = params.NATgammas{jgam};
  multiples = length(RR)-1;
  for jm = 1:multiples
    NATvec = RR{jm};
    params.multiplex_factors(jgam) = params.multiplex_factors(jgam) + NATvec(5)^2;
  end
  params.numNATparvecs = params.numNATparvecs + multiples;
end

params.orders2D = zeros(params.numNATparvecs,2);
    jv = 1; % counter to step through list of all different NATvec terms
    for jgam = 1:params.numgammas
      RR = params.NATgammas{jgam};
      multiples = length(RR)-1;
      for jm = 1:multiples
        NATvec = RR{jm};
        params.orders2D(jv,1) = NATvec(1);
        params.orders2D(jv,2) = NATvec(2);
        jv = jv+1;
      end
    end

params.legendre_normfac = sqrt((1+2*params.orders2D(:,1)).*(1+2*params.orders2D(:,2)));


%%
Ncfg = size(roixy_combined,2);
allzernikes_measured = [zeros(1,Ncfg); theta_combined(6:end,:)];
fov_coordinates = get_fov_coordinates(roixy_combined,theta_combined(1,:),theta_combined(2,:),params);
xn = fov_coordinates(1,:);
yn = fov_coordinates(2,:);

%%
xgrid = linspace(-1,1,50);
ygrid = linspace(-1,1,50);
[Xgrid,Ygrid] = meshgrid(xgrid,ygrid);

gammas = invertNAT(xn,yn,allzernikes_measured,params);
allzernikes_fitted = 1e3*get_zernike_coefficients(xn,yn,gammas,params)'/params.lambda;
zernike_surface_fitted = 1e3*get_zernike_coefficients(Xgrid,Ygrid,gammas,params)/params.lambda;

%% Open aberations from single molecules
%path_smlm = 'U:\NATaberrations\ExperimentalData\Lidke\data_analysis\DATA1\Data_wo_Astigmatism\fitted_aberrations\roi17\fitted_aberrations_0001_segmentation_roi17_offset100_thr30_Data0010.mat';
path_smlm = 'U:\NATaberrations\ExperimentalData\Lidke\data_analysis\DATA1\Data_w_Astigmatism\fitted_aberrations\001_fitted_aberrations_segmentation_thr30_Data0001.mat';
smlm_data = load(path_smlm);
gammas_smlm = smlm_data.theta_full.global.*[-1,-1,-1,-1,-1,-1,-1,-1,-1,1,1,1,-1]';
zernike_surface_smlm = 1e3*get_zernike_coefficients(Xgrid,Ygrid,gammas_smlm,params)/params.lambda;

%%

labels = ["A(2,0)" "A(2,-2)" "A(2,2)" "A(3,-1)" "A(3,1)" "A(4,0)"];
figure
for izer = 2:size(params.aberrations,1)
    hsub = subplot(2,3,izer);
    V = 1e3*allzernikes_measured(izer,:)/params.lambda;
    Vgrid = griddata(xn,yn,V,Xgrid,Ygrid,"cubic");

    surf(Xgrid,Ygrid,Vgrid,'FaceAlpha',0.7)
    shading interp
    hold on
    plot3(xn,yn,V,"o",'LineWidth',2,'MarkerSize',5)
    hold on
    surf(Xgrid,Ygrid,zernike_surface_fitted(:,:,izer),'FaceAlpha',0.5,'EdgeColor','none','FaceColor','#F80')
    hold on
    surf(Xgrid,Ygrid,zernike_surface_smlm(:,:,izer),'FaceAlpha',0.3,'EdgeColor','none','FaceColor','#00F')
    %plot3(xn,yn,allzernikes_fitted(izer,:),"o",'LineWidth',2,'MarkerSize',8)
    xlabel('x (\mum)')
    ylabel('y (\mum)')
    zlabel('m\lambda')
    %zlim([-40 60])
    title(labels(izer))
    ax = gca;
    ax.FontSize = 16;

end
legend('Bead aberrations','Beads','Fitted from beads','Fitted from single molecules','Location','east','Fontsize',16)

%% Plot both gammas in one plot
figure
plot(gammas_smlm,'--o','LineWidth',2,'MarkerSize',7)
hold on
plot(gammas,'--o','LineWidth',2,'MarkerSize',7)
xlabel('NAT coeffient')
xticks(1:13)
ax = gca;
ax.FontSize = 18;
legend('NAT coefficients from single molecules','NAT coefficients from beads')

