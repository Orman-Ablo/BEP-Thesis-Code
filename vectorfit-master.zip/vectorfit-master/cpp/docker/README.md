# Docker
## Introduction
This dockerfile provides a compilation and running environment for smsl_vectorfit.
## Prerequisites
The host computer needs the following preparations:
1. Make the nvidia repository available to your package manager: https://docs.nvidia.com/datacenter/tesla/tesla-installation-notes/index.html
2. Install the container toolkit: https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/install-guide.html#install-guide

## Building the docker image
Note: the recommended way of using this docker image is to have containers mount the source code folder, whereas the build process that is run inside a container creates files and folders within that mounted source code folder. Therefore, it is most convenient if these files can be accessed both on the host and inside containers. One easy way to accomplish that is to work with the same user ID and group ID on the host and inside the image.

Build the docker image on a development machine such that the user id and user group id are also used inside the container:
```
docker build -t smlm_vectorfit --build-arg USER_ID=$(id -u) --build-arg USER_GID=$(id -g) .
```

## Creating a container for building and running
Here's an example to create a temporary container that supports building and running the source code (replace `<absolute_source_path_on_host>`):
```
docker run --rm -it --name smlm-builder --runtime=nvidia --gpus all \
-v <absolute_source_path_on_host>:/opt/smlm_vectorfit \
smlm_vectorfit:latest
```

If you want to build the Matlab interface, you can mount the Matlab installation folder:
```
docker run --rm -it --name smlm-builder --runtime=nvidia --gpus all \
-v <absolute_source_path_on_host>:/opt/smlm_vectorfit \
-v <absolute_matlab_path_on_host>:/opt/matlab \
smlm_vectorfit:latest
```
and pass a hint to cmake so that Matlab is found:
```
cmake -DMatlab_ROOT_DIR=/opt/matlab/R<release>/ [additional_cmake_options..]
```

This example mounts an extra folder with test data to make it available at `/opt/data` inside the container (replace `<absolute_source_path_on_host>` and `<absolute_test_data_path_on_host>`):
```
docker run --rm -it --name smlm-builder --runtime=nvidia --gpus all -v <absolute_source_path_on_host>:/opt/smlm_vectorfit -v <absolute_test_data_path_on_host>:/opt/data smlm_vectorfit:latest
```
