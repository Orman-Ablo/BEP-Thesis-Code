#pragma once

#include "MultiDimArray.h"
#include "Parameters.h"

namespace compute {
	void ThetaLimits(
			const FitParams& AllParams,
			View1D<double> theta,
			WriteView1D<double> thetamin,
			WriteView1D<double> thetamax,
			WriteView1D<double> thetaretry);

	bool ThetaUpdate(
			const FitParams& AllParams,
			View1D<double> theta,
			View1D<double> thetamax,
			View1D<double> thetamin,
			View1D<double> thetaretry,
			View1D<double> grad,
			View2D<double> Hessian,
			const double& alamda,
			WriteView1D<double> thetatry);

	void AddMeritOffset(
			const FitParams& AllParams,
			WriteView1D<double> Merit,
			View3D<const double> OneSpot);
}