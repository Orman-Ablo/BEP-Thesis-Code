#include "initial_values.h"
#include "MultiDimArray.h"
#include "Parameters.h"
#include "common.h"
#include "estimator/cpu_estimator.h"
#include "Fitter.h"
#include "compute/theta.h"

namespace compute {

void getSpotFxy(View3D<double> OneSpot, ExcitationEnum excitation, WriteView2D<double> fxy) {
	using namespace placeholder;
	int Mx = OneSpot.size(0);
	int My = OneSpot.size(1);
	int K = OneSpot.size(2);
	VF_ASSERT(fxy.shape() == shape(Mx, My));
	int Kr = round(K / 2);

	if (excitation == ExcitationEnum::zstack) {
		fxy = OneSpot.view(_, _, Kr);
	} else {
		for (int i = 0; i < K; i++)	{
			fxy += OneSpot.view(_, _, i);
		}
	}
}

void getImageXY(const FitParams& params, WriteView2D<double> XImage, WriteView2D<double> YImage) {
	//Sampling coordinates in image plane (Physical length units)
	//  Compute the xy grid in the image plane
	int Mx = params.Mx;
	int My = params.My;
	double ImageSizex = params.XRange;
	double ImageSizey = params.YRange;
	double tempxy;
	////////
	VF_ASSERT(XImage.shape() == shape(Mx, My));
	VF_ASSERT(YImage.shape() == shape(Mx, My));

	//Create meshgrid, Pupil coordinate sampling
	for (int i = 0; i < Mx; i++)
	{
		tempxy = -ImageSizex + ImageSizex / Mx + i * 2 * ImageSizex / Mx;
		for (int j = 0; j < My; j++)
		{
			XImage(i, j) = tempxy;
		}
	}
	for (int j = 0; j < My; j++)
	{
		tempxy = -ImageSizey + ImageSizey / My + j * 2 * ImageSizey / My;
		for (int i = 0; i < Mx; i++)
		{
			YImage(i, j) = tempxy;
		}
	}
}

void getPhasorThetaStart(
	const FitParams& AllParams,
	View3D<double> OneSpot,
	View2D<double> fxy,
	WriteView1D<double> ThetaStart
) {
	const FitModelEnum& FitModel = AllParams.FitModel;
	int K = AllParams.Mz;
	int Mx = AllParams.Mx;
	int My = AllParams.My;

	//Sampling coordinates in image plane (Physical length units)
	Arr2D<double>XImage(Mx, My);
	Arr2D<double>YImage(Mx, My);
	getImageXY(AllParams, XImage, YImage);

	//= == = phasor - based position estimation ==============
	double qx1, qy1, phasor_sinx, phasor_cosx, phasor_siny, phasor_cosy, x0, y0;
	Arr2D<double>sinfacx(Mx, My);
	Arr2D<double>cosfacx(Mx, My);
	Arr2D<double>sinfacy(Mx, My);
	Arr2D<double>cosfacy(Mx, My);

	qx1 = 2.0 * M_PI /(Mx * AllParams.PixelSize);
	qy1 = 2.0 * M_PI /(My * AllParams.PixelSize);

	for (int ii=0;ii<Mx;ii++)
	{
		for (int jj = 0; jj < My; jj++)
		{
			sinfacx(ii, jj) = sin(qx1 * XImage(ii, jj)) * fxy(ii, jj);
			cosfacx(ii, jj) = cos(qx1 * XImage(ii, jj)) * fxy(ii, jj);
			sinfacy(ii, jj) = sin(qy1 * YImage(ii, jj)) * fxy(ii, jj);
			cosfacy(ii, jj) = cos(qy1 * YImage(ii, jj)) * fxy(ii, jj);
		}
	}
	phasor_sinx = sinfacx.sum();
	phasor_cosx = cosfacx.sum();
	phasor_siny = sinfacy.sum();
	phasor_cosy = cosfacy.sum();

	x0 = (Mx /(2.0*M_PI)) * AllParams.PixelSize * atan2(phasor_sinx, phasor_cosx);
	y0 = (My /(2.0*M_PI)) * AllParams.PixelSize * atan2(phasor_siny, phasor_cosy);

    const int theta_size = AllParams.FitModel.theta_size();
    Arr1D<double> thetaMin(theta_size);
	Arr1D<double> thetaMax(theta_size);
	Arr1D<double> thetaRetry(theta_size);
	compute::ThetaLimits(AllParams, ThetaStart, thetaMin, thetaMax, thetaRetry);

    // enforce physical boundaries in parameter space
    // +double check to enforce physical boundaries in parameter space
	if (x0 > thetaMax[FitModel.offset_x()])
	{
		x0 = 2*thetaMax[FitModel.offset_x()] - x0;
	}
    if (y0 > thetaMax[FitModel.offset_y()])
	{
		y0 = 2*thetaMax[FitModel.offset_y()] - y0;
	}
    if (x0 < thetaMin[FitModel.offset_x()])
	{
		x0 = 2*thetaMin[FitModel.offset_x()] - x0;
        if (x0 > thetaMax[FitModel.offset_x()])
        {
            x0 = (thetaMin[FitModel.offset_x()] + thetaMax[FitModel.offset_x()])/2.0;
        }
        
	}
    if (y0 < thetaMin[FitModel.offset_y()])
	{
		y0 = 2*thetaMin[FitModel.offset_y()] - y0;
        if (y0 > thetaMax[FitModel.offset_y()])
        {
            y0 = (thetaMin[FitModel.offset_y()] + thetaMax[FitModel.offset_y()])/2.0;
        }
	}

	ThetaStart[FitModel.offset_x()] = x0;
	ThetaStart[FitModel.offset_y()] = y0;
   
	if (FitModel.has_z()) {

        // Added by Isabel Droste 18 nov 2024
        // z0 estimator -------------------------------------
        double astigrms, astangle, phasora_xy, phasora_xx, phasora_yy, deltA, Ac, dof, scurvelength, gamfac, z0;
        Arr2D<double>sinfacxaya(Mx, My);
	    Arr2D<double>cosfacxa(Mx, My);
	    Arr2D<double>cosfacya(Mx, My);

        auto spot = SpotParameters::from_theta(FitModel, ThetaStart);
        double astighorver = spot.AberrationCoefs[2]/AllParams.Lambda; // todo: get aberration index automatically instead of hard coding '0' and '2' for A2-2 and A22.
        double astigdiag = spot.AberrationCoefs[0]/AllParams.Lambda;
        //std::cout << "A22 = " << astighorver << ", A2-2 = " << astigdiag  << std::endl;
        astigrms = sqrt(astighorver * astighorver + astigdiag * astigdiag);
        astangle = atan2(astigdiag, astighorver) / 2;

        if (astigrms > 0)
        {
            for (int ii=0;ii<Mx;ii++)
	        {
		        for (int jj = 0; jj < My; jj++)
		        {
                    sinfacxaya(ii, jj) = sin(qx1 * (XImage(ii, jj) - x0)) * sin(qy1 * (YImage(ii, jj) - y0)) * fxy(ii, jj);
                    cosfacxa(ii, jj) = cos(qx1 * (XImage(ii, jj) - x0)) * fxy(ii, jj);
                    cosfacya(ii, jj) = cos(qy1 * (YImage(ii, jj) - y0)) * fxy(ii, jj);
		        }
	        }
            phasora_xy = sinfacxaya.sum();
            phasora_xx = 2 * cosfacxa.sum();
            phasora_yy = 2 * cosfacya.sum();
            deltA = cos(2 * astangle) * (phasora_yy - phasora_xx) + sin(2 * astangle)* 2 * phasora_xy;
            Ac = phasora_xx + phasora_yy;
            if (AllParams.NA < AllParams.RefMed)
	        {
		        dof = AllParams.Lambda / (AllParams.RefMed-sqrt(AllParams.RefMed * AllParams.RefMed - AllParams.NA * AllParams.NA)); //depth of focus
	        }
	        else
	        {
		        dof = AllParams.Lambda / AllParams.RefMed;
	        }
            scurvelength = (2 * AllParams.RefMed * AllParams.Lambda / (AllParams.NA * AllParams.NA)) * sqrt(8) * astigrms; // half the distance between focal lines, paraxial formula 
            gamfac = dof / scurvelength;
            if (Ac * Ac > (1 + gamfac * gamfac) * deltA * deltA)
	        {
                z0 = scurvelength * (1 + gamfac * gamfac) * deltA / (Ac + sqrt(Ac * Ac - (1 + gamfac * gamfac) * deltA * deltA));
		    }
	        else
	        {
		        z0 = scurvelength*(1 + gamfac * gamfac) * deltA / Ac;
	        }
    
            // enforce physical boundaries in parameter space
            // +double check to enforce physical boundaries in parameter space
	        if (z0 > thetaMax[FitModel.offset_z()])
	        {
		        z0 = 2*thetaMax[FitModel.offset_z()] - z0;
	        }
            if (z0 < thetaMin[FitModel.offset_z()])
	        {
		        z0 = 2*thetaMin[FitModel.offset_z()] - z0;
                if (z0 > thetaMax[FitModel.offset_z()])
                {
                    z0 = (thetaMin[FitModel.offset_z()] + thetaMax[FitModel.offset_z()])/2.0;
                }       
	        }
		    ThetaStart[FitModel.offset_z()] = z0;
        }
        else
        {
            z0 = 0.0;
        }
	}
	ThetaStart[FitModel.offset_nph()] = 1.0;
	ThetaStart[FitModel.offset_nbg()] = 0.0;


}

void InitialValuesPhasor(const FitParams& AllParams, View3D<double> OneSpot, WriteView1D<double> ThetaInit)
{
	// Compute initial values for the fit parameters using the phasor method
	using namespace placeholder;
	VF_ASSERT(AllParams.initialization == InitializationMethod::phasor);

	int K = AllParams.Mz;
	int Mx = AllParams.Mx;
	int My = AllParams.My;
	VF_ASSERT(OneSpot.shape() == shape(Mx, My, K));

	const FitModelEnum& FitModel = AllParams.FitModel;
	int NumParams = FitModel.num_parameters();

	VF_ASSERT(
		(AllParams.DoeType == DoeTypeEnum::none) &&
		((FitModel == FitModelEnum::xy)
			|| FitModel == FitModelEnum::xy_constaberrations
			|| FitModel == FitModelEnum::xyz
			|| FitModel == FitModelEnum::xyz_constaberrations
		)
	);

	// Initialize ThetaInit parameters with zeros,
	// including z, pola, azim, and diffusion (but not fitted aberrations).
	int num_reset_params = FitModel.num_parameters() - FitModel.num_fitted_aberrations();
	ThetaInit.view(placeholder::range(0, num_reset_params)).fill(0);

	double xc, yc, fxy_sum, Nph0, bg0, Nph, bg;
	std::cout.precision(10);

	//= == = phasor - based position estimation ==============
	Arr1D<double> ThetaStart = ThetaInit;
	Arr2D<double>fxy(Mx, My);
	getSpotFxy(OneSpot, AllParams.Excitation, fxy);
	getPhasorThetaStart(AllParams, OneSpot, fxy, ThetaStart);

	Arr3D<double> allMu(Mx, My, K);
	Arr4D<double> allMuDer(Mx, My, K, NumParams);

	// Create a temporary estimator. Be sure to disable OTF,
	// because we merely need a single call to PoissonRate
	// and computing an OTF for that would only slow things down.
	FitParams LocalParamas = AllParams;
	LocalParamas.FlagOTF = false;
	Estimator estimator{LocalParamas};
	auto spot = SpotParameters::from_theta(FitModel, ThetaStart);
	spot.Pola = M_PI_2;
	estimator.PoissonRate(spot, allMu, allMuDer);
	// mu = Nph * Psf + Nbg --> Psf = (mu - Nbg) / Nph
	Arr2D<double> PSF = (allMu.drop_axis(2) - spot.Nbg) / spot.Nph;
	//=============

	//background estimate from the median value of rim pixels
	double nav, SIH, wav, SH1, SH2, Hav, H2av, nHav;
	int idx = 0;
	Arr2D<double> weight(Mx, My);

    // check that values are ok
	bg0 = getBorderBackground(fxy);
    bg0 = std::max(bg0,1.0);
    fxy_sum = fxy.sum();
	Nph0 = fxy_sum - Mx*My*bg0;
    if (Nph0 < 0)
    {
        Nph0 = fxy_sum;
    }
    
    // refinement of initial estimate of photon count and background by linear regression
	Arr2D<double> ones(Mx, My);
	ones.fill(1.0);
	weight = ones / ( PSF * Nph0 + bg0 );

	Hav = (weight * PSF).sum() / weight.numel();
	H2av = (weight * PSF * PSF).sum() / weight.numel();
	nav = (weight * fxy).sum() / weight.numel();
	nHav = (weight * fxy * PSF).sum() / weight.numel();
	wav = weight.sum() / weight.numel();

	xc = ThetaStart[FitModel.offset_x()];
	yc = ThetaStart[FitModel.offset_y()];

	double detty = H2av*wav - Hav*Hav;
	Nph = (nHav*wav - nav*Hav) / detty;
	bg = (nav*H2av - nHav*Hav) / detty;
    
    //provision for negative or too large estimates
    if (bg < 1 || bg > 5*bg0)
    {
        Nph = Nph + Mx * My * (bg - bg0);
        bg = bg0;
    }
    if (Nph < 0 || Nph > 2*fxy_sum)
    {
        Nph = Nph0;
    }


	ThetaInit(FitModel.offset_x()) = xc;
	ThetaInit(FitModel.offset_y()) = yc;
    if (FitModel.has_z())
	{
		ThetaInit(FitModel.offset_z()) = ThetaStart[FitModel.offset_z()];
	}
	ThetaInit(FitModel.offset_nph()) = Nph;
	ThetaInit(FitModel.offset_nbg()) = bg;
}

void InitialValuesCentroid(const FitParams& AllParams, View3D<double> OneSpot, WriteView1D<double> ThetaInit)
{
	using namespace placeholder;

	//Provides initial values for the fit parameters by means of a centroid fit.
	int K = AllParams.Mz;
	int Mx = AllParams.Mx;
	int My = AllParams.My;
	VF_ASSERT(OneSpot.shape() == shape(Mx, My, K));

	const FitModelEnum& FitModel = AllParams.FitModel;

	double xc, yc;
	double Nph,bg;
	double z0(0.0), pola0(0.0), azim0(0.0), g20(0.0);
	std::cout.precision(10);

	////////////// Centroid initialization //////////////
	double PhotonFlux;

	if ((AllParams.DoeType==DoeTypeEnum::none)&&(FitModel == FitModelEnum::xy))
	{
		PhotonFlux = 1.0; //Rough photon flux correction
	}
	else
	{
		PhotonFlux = 2.5; //
	}

	double Zmin = AllParams.ZSpread[0];
	double Zmax = AllParams.ZSpread[1];
	double deltaZ = Zmax - Zmin;

	ArrayND<double, 3> fxyk(Mx, My, K);
	Arr2D<double>fxy(Mx, My);
	getSpotFxy(OneSpot, AllParams.Excitation, fxy);
	fxyk = OneSpot.view();
	//background estimate from the median value of rim pixels
	bg = getBorderBackground(fxy);
	//Estimate the signal photon count
	Arr2D<double>temp(Mx, My);
	int Kr = round(K / 2);
	if (AllParams.Excitation == ExcitationEnum::zstack)
	{
		fxy = fxyk.view(_, _, Kr) - bg;
	}
	else
	{
		double bgt = bg / K;
		fxyk -= bgt; //operations on 3d
		double ref = 0.001;

		fxyk.clamp(ref, INFINITY); //max, min on Arr3d,
		Arr2D<double>ftemp(Mx, My);

		for (int i = 0; i < K; i++)
		{
			ftemp += fxyk.view(_, _, i);
		}
		fxy = ftemp;
	}

	//Sampling coordinates in image plane (Physical length units)
	Arr2D<double>XImage(Mx, My);
	Arr2D<double>YImage(Mx, My);
	getImageXY(AllParams, XImage, YImage);

	double m00, m10, m01, m20, m02, m11;
	m00 = fxy.sum();
	m10 = (XImage * fxy).sum();
	m01 = (YImage * fxy).sum();
	Nph = PhotonFlux * m00;

	//calculate centroids
	xc = m10 / m00;
	yc = m01 / m00;
	//xc=m10/Nph;
	//yc=m01/Nph;
	m20 = (XImage * XImage * fxy).sum();
	m02 = (YImage * YImage * fxy).sum();
	m11 = (XImage * YImage * fxy).sum();

	double mu20, mu11, mu02, mu21, mu12;
	mu20 = m20 - m00 * xc * xc;
	mu11 = m11 - m00 * xc * yc;
	mu02 = m02 - m00 * yc * yc;
	mu21 = m20 - m20 * yc - 2 * m11 * yc + 2 * m00 * xc * xc * yc;
	mu12 = m02 - m02 * xc - 2 * m11 * yc + 2 * m00 * xc * yc * yc;

	//centroid estimate of axial position
	double eig1, eig2, eccentricity;
	if (FitModel.has_z())
	{
		z0 = 1250 * m11 / (m20 + m02);
		z0 = std::min(z0, (Zmax + 0.5 * deltaZ));
		z0 = std::max(z0, (Zmin - 0.5 * deltaZ));
		z0 = 0;
	}

	if (FitModel.has_pola())
	{
		eig1 = ((mu20 + mu02) + sqrt(pow2((mu20 - mu02)) + 4 * pow2(mu11))) / 2;
		eig2 = ((mu20 + mu02) - sqrt(pow2((mu20 - mu02)) + 4 * pow2(mu11))) / 2;
		eccentricity = sqrt(1 - eig2 / eig1);
		//pola0 = fmod(M_PI * eccentricity, M_PI);  //why modulus here?
		pola0 = M_PI * eccentricity;
		pola0 = pola0 - ((int)(pola0 / M_PI)) * M_PI;
		if (pola0 < 0.0)
		{
			pola0 = pola0 + M_PI; //bound [M_PI]
		}

		// pola0 = pi / 4;
	}
	if (K == 1)
	{
		if (AllParams.DoeType == DoeTypeEnum::none)
		{
			azim0 = M_PI / 4;
		}
		else if (AllParams.DoeType == DoeTypeEnum::vortex)
		{
			azim0 = -atan2(mu12, mu21);
			//azim0 = azim0 - (int)(azim0/M_PI)*M_PI;
			azim0 = azim0 - ((int)(azim0 / M_PI)) * M_PI;//awe

			if (azim0 < 0)
			{
				azim0 = azim0 + M_PI; //bound [0 2*M_PI]
			}

		}

	}
	else if (K > 1)
	{
		azim0 = M_PI / 4;
		pola0 = M_PI / 4;

	}
	g20 = 0.75; //0.499

	// Initialize ThetaInit parameters with zeros,
	// including z, pola, azim, and diffusion (but not fitted aberrations).
	int num_reset_params = FitModel.num_parameters() - FitModel.num_fitted_aberrations();
	ThetaInit.view(placeholder::range(0, num_reset_params)).fill(0);

	ThetaInit(FitModel.offset_x()) = xc;
	ThetaInit(FitModel.offset_y()) = yc;
	ThetaInit(FitModel.offset_nph()) = Nph;
	ThetaInit(FitModel.offset_nbg()) = bg;

	if (FitModel.has_z()) {
		ThetaInit(FitModel.offset_z()) = z0;
	}

	if (FitModel.has_azim()) {
		ThetaInit(FitModel.offset_azim()) = azim0;
	}

	if (FitModel.has_pola()) {
		ThetaInit(FitModel.offset_pola()) = pola0;
	}

	if (FitModel.has_diffusion()) {
		ThetaInit(FitModel.offset_diffusion()) = g20;
	}
}

void InitialValues(const FitParams& AllParams, View3D<double> OneSpot, WriteView1D<double> ThetaInit) {
	if (AllParams.initialization == InitializationMethod::phasor) {
		InitialValuesPhasor(AllParams, OneSpot, ThetaInit);
	} else {
		InitialValuesCentroid(AllParams, OneSpot, ThetaInit);
	}
}

void InitialValues_aberr(const FitParams& AllParams, View3D<double> OneSpot, WriteView1D<double> ThetaInit)
{
	// TODO (Erik, 2023-09-08):
	// This method of using a centroid fit for initial theta values is no longer used. Remove function?

	using namespace placeholder;

	//Provides initial values for the fit parameters by means of a centroid fit.
	int K = AllParams.Mz;
	int Mx = AllParams.Mx;
	int My = AllParams.My;
	VF_ASSERT(OneSpot.shape() == shape(Mx, My, K));

	double Zmin = AllParams.ZSpread[0];
	double Zmax = AllParams.ZSpread[1];
	double deltaZ = Zmax - Zmin;
	FitModelEnum FitModel = AllParams.FitModel;
	int NumParams = FitModel.num_parameters();

	double PhotonFlux;
	if (AllParams.DoeType == DoeTypeEnum::none)
	{
		PhotonFlux = 1.5; //Rough photon flux correction
	}
	else
	{
		PhotonFlux = 1.5; //
	}

	/////////////////
	//
	//Sampling coordinates in image plane (Physical length units)
	//  Compute the xy grid in the image plane
	double ImageSizex = AllParams.XRange;
	double ImageSizey = AllParams.YRange;
	double tempxy;
	////////
	Arr2D<double>XImage(Mx, My);
	Arr2D<double>YImage(Mx, My);

	//Create meshgrid, Pupil coordinate sampling
	for (int i = 0; i < Mx; i++)
	{
		tempxy = -ImageSizex + ImageSizex / Mx + i * 2 * ImageSizex / Mx;
		for (int j = 0; j < My; j++)
		{
			XImage(i, j) = tempxy;
		}
	}
	for (int j = 0; j < My; j++)
	{
		tempxy = -ImageSizey + ImageSizey / My + j * 2 * ImageSizey / My;
		for (int i = 0; i < Mx; i++)
		{
			YImage(i, j) = tempxy;
		}
	}

	///////

	//Arr4D<double> _spots(AllSpots);
	Arr3D<double>fxyk(Mx, My, K);
	Arr2D<double>fxy(Mx, My);
	Arr2D<double>temp(Mx, My);
	int Kr = round(K / 2);

	fxyk.copy_from(OneSpot);

	if (AllParams.Excitation == ExcitationEnum::zstack)
	{
		fxy += fxyk.view(_, _, Kr);
	}
	else
	{
		for (int i = 0; i < K; i++)
		{
			fxy += fxyk.view(_, _, i);
		}
	}

	//background estimate from the median value of rim pixels
	double bg = getBorderBackground(fxy);

	//bg = 1.0; //test value for bg
	//Estimate the signal photon count
	if (AllParams.Excitation == ExcitationEnum::zstack)
	{
		//fxy.ArrCopy(fxyk, Kr, 3);//
		for (int ii = 0; ii < Mx; ii++) {
			for (int jj = 0; jj < My; jj++) {
				fxy(ii, jj) = std::max(fxy(ii, jj) - bg, 0.0);
			}
		}
	}
	else
	{
		double bgt = bg / K;
		fxyk -= bgt; //operations on 3d
		double ref = 0.001;

		fxyk.clamp(ref, INFINITY); //max, min on Arr3d,
		Arr2D<double>ftemp(Mx, My);

		for (int i = 0; i < K; i++)
		{
			ftemp += fxyk.view(_, _, i); //        fxy = sum(fxyk,3);
		}
		fxy = ftemp;
	}

	//use template to sum matrices
	double m00, m10, m01, m20, m02, m11;
	m00 = fxy.sum();
	m10 = (XImage * fxy).sum();
	m01 = (YImage * fxy).sum();
	m20 = (XImage * XImage * fxy).sum();
	m02 = (YImage * YImage * fxy).sum();
	m11 = (XImage * YImage * fxy).sum();


	//calculate centroids
	double xc, yc;
	xc = m10 /(PhotonFlux*m00);
	yc = m01 /(PhotonFlux*m00);

	//calculate central moments
	double mu20, mu11, mu02, mu21, mu12;
	mu20 = m20 - m00 * xc * xc;
	mu11 = m11 - m00 * xc * yc;
	mu02 = m02 - m00 * yc * yc;
	mu21 = m20 - m20 * yc - 2 * m11 * yc + 2 * m00 * xc * xc * yc;
	mu12 = m02 - m02 * xc - 2 * m11 * yc + 2 * m00 * xc * yc * yc;

	//centroid estimate of axial position
	double z0, eig1, eig2, eccentricity, pola0 = 0.0, azim0;
	if (FitModel.has_z())
	{
		z0 = 1250 * m11 / (m20 + m02);
		z0 = std::min(z0, (Zmax + 0.5 * deltaZ));
		z0 = std::max(z0, (Zmin - 0.5 * deltaZ));
		z0 = 0;
	}

	if (FitModel.has_pola())
	{
		eig1 = ((mu20 + mu02) + sqrt(pow2((mu20 - mu02)) + 4 * pow2(mu11))) / 2;
		eig2 = ((mu20 + mu02) - sqrt(pow2((mu20 - mu02)) + 4 * pow2(mu11))) / 2;
		eccentricity = sqrt(1 - eig2 / eig1);
		//pola0 = fmod(M_PI * eccentricity, M_PI);  //why modulus here?
		pola0 = M_PI * eccentricity;
		pola0 = pola0 - ((int)(pola0 / M_PI)) * M_PI;
		if (pola0 < 0.0)
		{
			pola0 = pola0 + M_PI; //bound [M_PI]
		}

		// pola0 = pi / 4;
	}
	if (K == 1)
	{
		if (AllParams.DoeType == DoeTypeEnum::none)
		{
			azim0 = M_PI / 4;
		}
		else if (AllParams.DoeType == DoeTypeEnum::vortex)
		{
			azim0 = -atan2(mu12, mu21);
			//azim0 = azim0 - (int)(azim0/M_PI)*M_PI;
			azim0 = azim0 - ((int)(azim0 / M_PI)) * M_PI;//awe

			if (azim0 < 0)
			{
				azim0 = azim0 + M_PI; //bound [0 2*M_PI]
			}

		}
		else
		{
			throw std::runtime_error("invalid DoeType");
		}
	}
	else if (K > 1)
	{
		azim0 = M_PI / 4;
		pola0 = M_PI / 4;
	}
	else
	{
		throw std::runtime_error("invalid K");
	}

	double g20 = 0.75; //0.499
	double Nph = m00 * PhotonFlux;

	ThetaInit.fill(0);
	ThetaInit(FitModel.offset_x()) = xc;
	ThetaInit(FitModel.offset_y()) = yc;
	ThetaInit(FitModel.offset_nph()) = Nph;
	ThetaInit(FitModel.offset_nbg()) = bg;

	if (FitModel.has_z()) {
		ThetaInit(FitModel.offset_z()) = z0;
	}

	if (FitModel.has_azim()) {
		ThetaInit(FitModel.offset_azim()) = azim0;
	}

	if (FitModel.has_pola()) {
		ThetaInit(FitModel.offset_pola()) = pola0;
	}

	if (FitModel.has_diffusion()) {
		ThetaInit(FitModel.offset_diffusion()) = g20;
	}
}

}