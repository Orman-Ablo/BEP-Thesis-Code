#pragma once

#include "catch.hpp"

#include <cuda_runtime_api.h>
#include <vector>
#include <random>

#include "cuda/types.cuh"
#include "array/cuda_array.h"
#include "Parameters.h"


inline void initialize_cuda() {
	VF_CUDA_CHECK(cudaSetDevice(0));
}

inline std::vector<FitParams> test_fit_models() {
	FitParams xyz(FitModelEnum::xyz);
	xyz.Mz = 2;

	return {
		{FitModelEnum::xy},
		{FitModelEnum::xy_azim},
		{FitModelEnum::xy_azim_pola},
		{FitModelEnum::xy_azim_pola_diffusion},
		xyz
	};
}

template <typename T>
struct default_generator {};

template <>
struct default_generator<double> {
	double operator()(std::default_random_engine& rng) {
		return std::uniform_real_distribution<double>{-1.0, 1.0}(rng);
	}
};

template <>
struct default_generator<std::complex<double>> {
	std::complex<double> operator()(std::default_random_engine& rng) {
		double angle = std::uniform_real_distribution<double>{0, 2 * M_PI}(rng);
		double mag = std::uniform_real_distribution<double>{0.1, 2}(rng);
		return {cos(angle) * mag, sin(angle) * mag};
	}
};

template <typename T, size_t N, typename G = default_generator<T>>
void fill_random(ArrayND<T, N>& v, int seed=0, G gen={}) {
	std::default_random_engine rng(seed);

	for (T& value: v) {
		value = gen(rng);
	}
}

template <typename T, size_t N>
void fill_zeros(ArrayND<T, N>& v) {
	for (T& value: v) {
		value = T{};
	}
}

inline void check_equals_value(double reference, double output) {
	static constexpr double ATOL = 1e-12;
	static constexpr double RTOL = 1e-9;

	REQUIRE_THAT(output, Catch::WithinAbs(reference, ATOL) || Catch::WithinRel(reference, RTOL));
}

inline void check_equals_value(std::complex<double> reference, std::complex<double> output) {
	INFO("reference=" << reference);
	INFO("output=" << output);
	check_equals_value(0, std::abs(reference - output));
}

template <typename T, size_t N>
void check_equals(ArrayND<T, N>& reference, ArrayND<T, N>& output) {
	CHECK(reference.shape() == output.shape());

	iterate_nd(reference.shape(), [&](auto ndindex) {
		INFO("index=" << ndindex);
		check_equals_value(reference.access(ndindex), output.access(ndindex));
	});
}

template <typename T, typename T2, size_t N>
void check_equals(ArrayND<T, N>& reference, CudaArrayND<T2, N>& output_g) {
	ArrayND<T, N> output(output_g.shape());
	cuda_copy(output_g, output);

	check_equals(reference, output);
}