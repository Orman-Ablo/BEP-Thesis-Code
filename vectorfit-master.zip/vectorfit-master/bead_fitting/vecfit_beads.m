% This script can be used to fit measured and synthetic beads using a
% vectorial dipole PSF.
%
% INPUT
% Either unsegmented or unsegmented bead data. 
%
% When input data is non-segmented, set 'segmented_data' to 'false'. The
% input file 'input_data_file' should then be a .mat file that contains: 
% allspots, allspots, roixy, params (= the outcome of segmentation)
%
% When input data is segmented, set 'segmented_data' to 'false'. The input
% file 'input_data_file' should then be a .tiff 3D image of the beads.
%
% OUTPUT
% segmentation data (if input was non-segmented data)
% localized data of the beads (incl. aberrations) 


close all;
clearvars;

%% Settings
use_initialvalues_phasor = false;
%segemented_data = true;
segmentation_type = 'nonsegmented'; % 'segmented', 'nonsegmented', or 'singlebead'.
segmentation_threshold = 200; % Only used when segmentation_type is nonsegmented.
select_beads = false; % Only process a subsection of the beads
bead_selection = 1:16;

% Choose on which computer the code will run to make sure the right paths
% are chosen. If running the code on another computer, specify custom
% paths.
% Options: 'windows_laptop', 'linux_pc', 'hpc_cluster', 'custom_paths'
computer = 'hpc_cluster';
%custom_code_path = 'path/to/code';
%custom_source = 'path/to/raw/data';
%custom_destination = 'path/where/data/will/be/saved';

% Get the paths where the code and data are stored.
switch computer
    case 'windows_laptop'
        code_path = 'C:\Users\idroste\Desktop\TUDelft\Code\vecfitcpu_vortex';
        %source_directory = 'N:\tnw\IST\QI\users\idroste\Data\synthetic_data\small_beads\';
        source_directory = 'N:\tnw\IST\QI\users\idroste\Data\data_bead_fitting_22_02_15\raw\';
        %source_directory = 'N:\tnw\IST\QI\users\idroste\Data\dataPieter\';
        %destination_directory = 'N:\tnw\IST\QI\users\idroste\Data\dataPieter\results\';
        %destination_directory = 'N:\tnw\IST\QI\users\idroste\Data\data_bead_fitting_22_02_15\processed\50it_4ab\';
        %destination_directory = 'N:\tnw\IST\QI\users\idroste\Data\synthetic_data\small_beads\results\';
        destination_directory = 'C:\Users\idroste\Desktop\TUDelft\Code\vecfitcpu_vortex\read\';
        %destination_directory = 'C:\Users\idroste\Desktop\TUDelft\Code\vecfitcpu_vortex\read\'
    case 'linux_pc'
        code_path = '/home/idroste/Desktop/TUDelft/Code/vecfitcpu_vortex';
        source_directory = '/home/idroste/Desktop/TUDelft/Data/data_bead_fitting_22_02_15/raw/';
        destination_directory = '/home/idroste/Desktop/TUDelft/Data/data_bead_fitting_22_02_15/processed/';
    case 'hpc_cluster'
        code_path = '/home/nfs/idroste/Desktop/TUDelft/Code/vecfitcpu_vortex';
        source_directory = '/tudelft.net/staff-bulk/tnw/IST/QI/users/idroste/Data/data_bead_fitting_22_02_15/raw/';
        destination_directory = '/tudelft.net/staff-bulk/tnw/IST/QI/users/idroste/Data/data_bead_fitting_22_02_15/processed/zernike12_50it/';
    case 'custom_paths'
        code_path = custom_code_path;
        source_directory = custom_source;
        destination_directory = custom_destination;
    otherwise
        error('Source and destination paths not correcly specified');
end

% Name of the source file. Can also be a pattern for example
% 'data_region_*.mat'. All files in the source_directory that match the 
% pattern are processed one by one.
%input_data_file = 'bead_data.mat';
input_data_file = 'old_region_5.tif';
%input_data_file = 'bead.tif';
%input_data_file = 'segmentation_old_region_5.mat';

%% Seach data
% Add all the folders and subfolders to the path
addpath(genpath(code_path));
addpath(genpath(source_directory));
addpath(genpath(destination_directory));

% Set parameter file. When using segmented data, this will be overwritten
% by that parameter file from the input data.
params = set_parameters_zstack_bead_0215;

%file_path = strcat(source_directory, synthetic_data_filename);
%[directory, source_name_without_extension, extension] = fileparts(file_path);
%synthetic_data = load(file_path);

% Search in the source directory for files that match the pattern
all_files = dir(strcat(source_directory, input_data_file));
fprintf('\n Found %i matching input data files in %s\n', length(all_files), source_directory);
for i = 1:size(all_files,1)
    disp(all_files(i).name);
end

% Loop over the input files.
% For each file, the data is (segmented and) localized
for Nrawdata = 1:size(all_files,1)

% Clear all variables at the beginning of a new round except the ones 
% defined before the for loop.
clearvars -except use_initialvalues_phasor segmentation_type segmentation_threshold ...
select_beads bead_selection computer code_path source_directory ...
destination_directory input_data_file params all_files  Nrawdata

source_filename = all_files(Nrawdata).name;
[directory, source_name_without_extension, extension] = fileparts(source_filename);

fprintf('\nStart processing raw data file %i: %s\n\n', Nrawdata, source_filename);

%% Open/segment data
switch segmentation_type
    case 'segmented'
        loaded_data = load(source_filename);
        allspots = loaded_data.allspots;
        roixy = loaded_data.roixy;
        try
            params = loaded_data.params;
        catch
            params = loaded_data.parameters;
        end
    
        %allspots = (allspots-params.offset)/params.gain;
        %allspots(allspots<=0) = 1e-3; 
        
        % update parameters
        params.K = size(allspots,3); % number of z-slices
        params.Ncfg = size(allspots,4); % number of beads
    case 'nonsegmented'
        fprintf('Start segmentation\n\n');
        [allspots,roixy,~,params] = get_segmentation(params,source_filename,segmentation_threshold);
        
        %allspots = (allspots-params.offset)/params.gain;
        %allspots(allspots<=0) = 1e-3; 
        
        % update parameters
        params.K = size(allspots,3); % number of z-slices
        params.Ncfg = size(allspots,4); % number of configurations
        
        % Save the segmentation results
        dest_file = strcat(destination_directory, 'segmentation_', source_name_without_extension, '.mat');
        save(dest_file,'segmentation_threshold','params','allspots','roixy');
        disp(strcat('Segmentation results saved in ', dest_file, '\n'));
    case 'singlebead'
        InfoImage =  imfinfo(source_filename);
        try
            allspots = double(LoadTiff16bit(source_filename, [1 length(InfoImage)]));
        catch
            allspots = zeros(InfoImage(1).Width,InfoImage(1).Height,length(InfoImage));
            for j=1:length(InfoImage)
                allspots (:,:,j) = double(imread(source_filename, j));
            end
            disp('Warning: Used slower imread instead of LoadTiff')
        end
        %allspots = (allspots-params.offset)/params.gain;
        %allspots(allspots<=0) = 1e-3;
        
        % update parameters
        params.K = size(allspots,3); % number of z-slices
        params.Ncfg = 1;
        params.FOV = 0;
        roixy = zeros(1,2);
    otherwise
        error('Segmentation_type incorrect');
end

% Select beads
if select_beads
    allspots = allspots(:,:,:,bead_selection);
    roixy = roixy(bead_selection,:);
    params.Ncfg = length(bead_selection);
end

% Change parameters if needed.
params.nr_of_parallel_workers = 28;
params.Nitermax = 50;
%params.fitmodel = 'xyz-aberrations';
%params.numparams = 4;
%params.lambda0 = 1e4;

%% Localization

fprintf('Start localization\n');

if use_initialvalues_phasor
    [thetainit] = initialvalues_phasor(allspots,params);
else    
    [thetainit] = initialvalues(allspots,params);
end

%[thetastore,mu,dmudtheta,merit,numiters,iteration_path,alambdastore,time] = localization(allspots,thetainit,params); 
% todo: replace localization by localmax
[thetastore,thetatrystore,mu,dmudtheta,merit,merittry,numiters,iteration_path,alambdastore,time] = localization_localmax(allspots,thetainit,params);

%% Process and save
theta = thetastore(:,:,end);

% compute CRLB using the estimated parameters
[crlb,rcondstore] = get_fisher_crlb(params,mu,dmudtheta);

% compute fitting errors (chi2, LLR, and SSE)
[fiterror] = get_fiterror(mu,allspots,params);

% outlier removal based on statistics of maximum log-likelihood, number of
% iterations, and on found position
% TODO: find out if we should use outliers or fiterror to remove outliers.
[outliers] = get_outliers(theta,merit,numiters,params);

% convert xy to field positions and azim-pola to half-sphere
theta_end = theta;
roixy(:,1)= roixy(:,1)-params.FOV/2;
roixy(:,2)= roixy(:,2)-params.FOV/2;
theta = roi2fov(theta,roixy,params);

% Find indices of out-of-focus emitters
outfocus= find(fiterror(1,:)>20); 

% Compute increase in objective function
merit_shift = zeros(size(merit));
merit_shift(:,2:end) = merit(:,1:end-1);
dmerit = merit - merit_shift;

% Store the full output in *_original files 
% and remove out-of-focus emitters.
thetainit_original = thetainit;
thetastore_original = thetastore;
thetatrystore_original = thetatrystore;
theta_end_original = theta_end;
theta_original = theta;
mu_original = mu;
merit_original = merit;
merittry_original = merittry;
dmerit_original = dmerit;
numiters_original = numiters;
crlb_original = crlb;
rcondstore_original = rcondstore;
fiterror_original = fiterror;
outliers_original = outliers;
iteration_path_original = iteration_path;
alambdastore_original = alambdastore;
time.time_per_spot_original = time.time_per_spot;
time.time_per_iteration_original = time.time_per_iteration;

thetainit(:,outfocus) = [];
thetastore(:,outfocus,:) = [];
thetatrystore(outfocus,:,:) = [];
theta_end(:,outfocus) = [];
theta(:,outfocus) = [];
mu(:,:,:,outfocus) = [];
merit(outfocus,:) = [];
merittry(outfocus,:) = [];
dmerit(outfocus,:) = [];
numiters(:,outfocus) = [];
crlb(:,outfocus) = [];
fiterror(:,outfocus) = [];
rcondstore(:,outfocus) = [];
outliers(:,outfocus) = [];
iteration_path(outfocus,:) = [];
alambdastore(outfocus,:) = [];
time.time_per_spot(outfocus) = [];
time.time_per_iteration(outfocus,:) = [];


% Save the localization results
dest_file = strcat(destination_directory, 'localization_', source_name_without_extension, '.mat');
save( dest_file,'params','thetainit','thetastore','thetatrystore','theta_end','theta','mu','merit','merittry','dmerit','numiters', ...
    'crlb','rcondstore','fiterror','outliers','iteration_path', 'alambdastore', 'time', ...
    'outfocus', ...
'thetainit_original','thetastore_original','thetatrystore_original','theta_end_original','theta_original','mu_original','merit_original','merittry_original','dmerit_original','numiters_original', ...
    'crlb_original','rcondstore_original','fiterror_original','outliers_original','iteration_path_original','alambdastore_original')

% TODO: check if save was succesfull
disp(strcat('Locatization results saved in ', dest_file, '\n'));

end % end of looping of all input files.

fprintf('Script completed\n');

