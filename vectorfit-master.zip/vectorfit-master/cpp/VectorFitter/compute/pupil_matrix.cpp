#include <complex>

#include "compute/pupil_matrix.h"
#include "compute/common.h"
#include "compute/SAF.h"

using std::complex;
using std::sqrt;
using std::abs;

void get_xy_pupil(
		int NPupil,
		WriteView2D<double> XPupil,
		WriteView2D<double> YPupil,
		WriteView2D<double> ApertureMask)
{
	//pupil radius(in diffraction units) and pupil coordinate sampling
	// double DxyPupil = 2 * PupilSize / Npupil;
	double PupilSize = 1.0;

	//Create meshgrid, Pupil coordinate sampling
	for (int i = 0; i < NPupil; i++)
	{
		for (int j = 0; j < NPupil; j++)
		{
			double xpupillin = -PupilSize + PupilSize / NPupil + i * 2 * PupilSize / NPupil;
			XPupil(i, j) = xpupillin;

			double ypupillin = -PupilSize + PupilSize / NPupil + j * 2 * PupilSize / NPupil;
			YPupil(i, j) = ypupillin;

			// definition aperture
			double dist = pow2(XPupil(i, j)) + pow2(YPupil(i, j));
			ApertureMask(i, j) = double(dist < 1.0);
		}
	}
}

void get_zernike_functions(
		const PupilParams& AllParams,
		int NAberr,
		const Arr2D<double>& XPupil,
		const Arr2D<double>& YPupil,
		Arr3D<double>& AllZernikes)
{
	//calculation aberration function
	//Arr2D<double> Aberrations(12, 3); // size could be changeable
	Arr2D<double> orders(NAberr, 2);
	for (int ii = 0; ii < NAberr; ii++) {
		orders(ii, 0) = AllParams.AberrationOrders[ii][0];
		orders(ii, 1) = AllParams.AberrationOrders[ii][1];
	}

	// This function computes the Zernike basis aberration functions for the Zernike orders given in the input argument orders.
	int zersize, Nzer, radormax, azormax,radazormax,Nx, Ny, n, jn;
	int m;
	Nx = XPupil.size(0);
	Ny = XPupil.size(1);
	Nzer = orders.size(0);

	Arr2D<double>rhosq(Nx, Ny);
	Arr2D<double>rho(Nx, Ny);
	Arr2D<double>phi(Nx, Ny);

	radormax = 0;
	azormax = 0;
	for (int ii = 0; ii < Nzer; ii++)
	{
		int rador = orders(ii, 0);
		int azor = std::abs(orders(ii, 1));
		radormax = std::max(rador, radormax);
		azormax = std::max(azor, azormax);
	}
	radazormax = std::max(radormax + 1, azormax + 4);

	//Arr4D<double> zerpol(Nx, Ny, radazormax + 1, azormax + 1);
	Arr4D<double> zerpol(Nx, Ny, 2*radormax + 5, azormax +2);
	for (int ii = 0; ii < Nx; ii++) {
		for (int jj = 0; jj < Ny; jj++) {
			rhosq(ii, jj) = pow2(XPupil(ii, jj)) + pow2(YPupil(ii, jj));
			rho(ii, jj) = sqrt(rhosq(ii, jj));
			zerpol(ii, jj, 0, 0) = 1.0;
			phi(ii, jj) = atan2(YPupil(ii, jj), XPupil(ii, jj));
		}
	}


	for (int jm = 0; jm < azormax+2; jm++) //jm<azormax, why +2? out of index?
	{
		//m = jm - 1;
		m = jm;

		if(jm > 0)
		{
			for(int ii = 0; ii < Nx; ii++)
			{
				for(int jj = 0; jj < Ny; jj++)
				{
					zerpol(ii, jj, jm, jm) = (double)rho(ii, jj) * (double)zerpol(ii, jj, jm-1, jm-1);
				}
			}
		}
		for (int ii = 0; ii < Nx; ii++)
		{
			for (int jj = 0; jj < Ny; jj++)
			{
				zerpol(ii, jj, jm + 2, jm) = ((m + 2) * rhosq(ii, jj) - m - 1) * zerpol(ii, jj, jm, jm);
			}
		}
		for (int p = 2; p < radormax - m + 2; p++)//check the jacobian recursion
		{
			n = m + 2 * p;
			jn = n;
			for (int ii = 0; ii < Nx; ii++)
			{
				for (int jj = 0; jj < Nx; jj++)
				{
					zerpol(ii, jj, jn, jm) = (2 * (n - 1) * (n * (n - 2) * (2 * rhosq(ii, jj) - 1) - pow2(m)) * zerpol(ii, jj, jn - 2, jm) -
											  n * (n + m - 2) * (n - m - 2) * zerpol(ii, jj, jn - 4, jm)) / ((n - 2) * (n + m) * (n - m));
					//the correct jacobian recursion has to be implemented in the matlab routine.
					//zerpol(ii, jj, jn, jm) = (2 * (n - 1) * (n * (n - 2) * (2 * rhosq(ii, jj) - 1) - pow2(jm)) * zerpol(ii, jj, jn - 2, jm) -
					//	n * (n + m - 2) * (n - m - 2) * zerpol(ii, jj, jn - 4, jm))/ ((n - 2) * (n + m) * (n - m));
				}
			}
		}
	}

	//Computation of the Zernike aberration functions from the radial Zernike polynomialsand the azimuthal factors
	for (int j = 0; j < Nzer; j++)
	{
		n = orders(j, 0);
		m = orders(j, 1);
		if (m >= 0)
			for (int ii = 0; ii < Nx; ii++) {
				for (int jj = 0; jj < Nx; jj++) {
					AllZernikes(ii, jj, j) = zerpol(ii, jj, n, m) * cos(m * phi(ii, jj));
				}
			}
		else
			for (int ii = 0; ii < Nx; ii++) {
				for (int jj = 0; jj < Nx; jj++) {
					AllZernikes(ii, jj, j) = zerpol(ii, jj, n, - m) * sin(-1 * m * phi(ii, jj));
				}
			}
	}
}

void normalize_zernike_functions(
		const PupilParams& AllParams,
		int NAberr,
		Arr3D<double>& AllZernikes,
		Arr3D<double>& AllZernikesNormalized)
{
	const int Npupil = AllParams.NPupil;

	for (int j = 0; j < NAberr; j++)
	{
		double orders[2];
		orders[0] = AllParams.AberrationOrders[j][0];
		orders[1] = AllParams.AberrationOrders[j][1];
		double normfac = sqrt(2 * (orders[0] + 1) / (1 + double(orders[1] == 0)));

		for (int nn = 0; nn < Npupil; nn++)
		{
			for (int mm = 0; mm < Npupil; mm++)
			{
				AllZernikesNormalized(nn, mm, j) = AllZernikes(nn, mm, j) * normfac;
			}
		}
	}
}

Arr2D<double> calculate_zonefun(
		const PupilParams& AllParams,
		const Arr2D<double>& XPupil,
		const Arr2D<double>& YPupil) {
	//calculation DOE / SLM phase function
	const int Npupil = AllParams.NPupil;
	Arr2D<double> zonefun(Npupil, Npupil);

	if (AllParams.DoeType == DoeTypeEnum::vortex) {
		double numzones = AllParams.RingRadius - 1;  //is it a vector?

		for (int nn = 0; nn < Npupil; nn++) {
			for (int mm = 0; mm < Npupil; mm++) {
				double rho = sqrt(pow2(XPupil(nn, mm)) + pow2(YPupil(nn, mm)));
				double phi = atan2(YPupil(nn, mm), XPupil(nn, mm));
				double zoneindex = 0.0;

				for (int jj = 0; jj < numzones; jj++) {
					// FIXME: Stijn: This comparison does not make sense but was in the original code?
					zoneindex += jj * double(rho > AllParams.RingRadius) *
								 double(rho <= AllParams.RingRadius);
				}

				if (AllParams.DoeLevels == 0) {
					zonefun(nn, mm) = (phi / (2.0 * M_PI)) * (zoneindex * 2.0 - 1.0) + 0.5;
				} else {
					zonefun(nn, mm) = ((zoneindex * 2.0 - 1.0) * (phi / (2.0 * M_PI)) + 0.5) * AllParams.DoeLevels;
					zonefun(nn, mm) = round(zonefun(nn, mm)) / AllParams.DoeLevels;
				}
			}
		}

		double aa = zonefun.maximum();

		if (AllParams.DoeVortexFlip == 1) {
			for (int nn = 0; nn < Npupil; nn++) {
				for (int mm = 0; mm < Npupil; mm++) {
					zonefun(nn, mm) = aa - zonefun(nn, mm);
				}
			}
		}
	}

	return zonefun;
}


void calculate_fresnel_coefficients(
		const PupilParams& AllParams,
		const int NAberr,
		View2D<double> XPupil,
		View2D<double> YPupil,
		View2D<double> ApertureMask,
		WriteView2D<std::complex<double>> cosThetaCov,
		WriteView2D<std::complex<double>> cosThetaImm,
		WriteView2D<std::complex<double>> cosThetaImmnom,
		WriteView2D<std::complex<double>> cosThetaMed,
		WriteView4D<std::complex<double>> PolarizationVector,
		WriteView2D<std::complex<double>> Amplitude
) {
	using namespace std::complex_literals;

// This function calculates the pupil matrix Q_{ jk }, which gives the j - the electric field component proportional to the k - th dipole vector component.
	const double NA = AllParams.NA;
	const double refcov = AllParams.RefCov;
	const double refmed = AllParams.RefMed;
	const double refimm = AllParams.RefImm;
	const double refimmnom = AllParams.RefImmNom;
	const double lambda = AllParams.Lambda;
	const int Npupil = AllParams.NPupil;

	//pupil radius(in diffraction units) and pupil coordinate sampling
	double PupilSize = 1.0;
	double DxyPupil = 2 * PupilSize / Npupil;

	////////////////////////////////
	// calculation of relevant Fresnel - coefficients for the interfaces between the medium and the cover slip and between the cover slip
	//	and the immersion fluid The Fresnel - coefficients should be divided by the wavevector z - component  of the incident medium,
	//	this factor originates from the Weyl - representation of the emitted vector spherical wave of the dipole.
	//		 CosThetaMed = sqrt(1 - (XPupil. ^ 2 + YPupil. ^ 2) * NA ^ 2 / refmed ^ 2);
	// SAF correction 26 - 07 - 2020
	//Clockwise rotation(sqrt assumes counterclockwise; Eulers formula)
	//check which of thes are complex

	for (int nn = 0; nn < Npupil; nn++)
	{
		for (int mm = 0; mm < Npupil; mm++)
		{
			double argMed = 1.0 - (pow2(YPupil(nn, mm)) + pow2(XPupil(nn, mm))) * pow2(NA) / pow2(refmed);
			double phiMed = atan2(0, argMed);

			double tempvar;
			std::complex<double> ctempvar;

			tempvar = 1.0 - (pow2(YPupil(nn, mm)) + pow2(XPupil(nn, mm))) * pow2(NA) / pow2(refcov);
			cosThetaCov(nn, mm) = sqrt(tempvar+1i*0.0);

			tempvar = 1.0 - (pow2(YPupil(nn, mm)) + pow2(XPupil(nn, mm))) * pow2(NA) / pow2(refimm);
			cosThetaImm(nn, mm) = sqrt(tempvar+1i*0.0);

			tempvar = 1.0 - (pow2(YPupil(nn, mm)) + pow2(XPupil(nn, mm))) * pow2(NA) / pow2(refimmnom);
			cosThetaImmnom(nn, mm) = sqrt(tempvar+1i*0.0);

			std::complex<double> FresnelPmedcov;
			std::complex<double> FresnelSmedcov;

			cosThetaMed(nn, mm) = sqrt(abs(argMed)) * (cos(phiMed / 2.0) - 1i * sin(phiMed / 2.0));

			ctempvar= (cosThetaCov(nn, mm) * refmed) + (cosThetaMed(nn, mm) * refcov);
			FresnelPmedcov = (cosThetaMed(nn, mm) * (2.0 * refmed)) / ctempvar;

			ctempvar = (cosThetaMed(nn, mm) * refmed) + (cosThetaCov(nn, mm) * refcov);
			FresnelSmedcov = (cosThetaMed(nn, mm) * (2.0 * refmed)) / ctempvar;

			ctempvar = (cosThetaImm(nn, mm) * refcov) + (cosThetaCov(nn, mm) * refimm);
			complex<double> FresnelPcovimm = (cosThetaCov(nn, mm) * (2.0 * refcov)) / ctempvar;

			ctempvar = (cosThetaCov(nn, mm) * refcov) + (cosThetaImm(nn, mm) * refimm);
			complex<double> FresnelScovimm = (cosThetaCov(nn, mm) * (2.0 * refcov)) / ctempvar;

			complex<double> FresnelP = FresnelPmedcov * FresnelPcovimm;
			complex<double> FresnelS = FresnelSmedcov * FresnelScovimm;

			double Phi = atan2(YPupil(nn, mm), XPupil(nn, mm));
			double CosPhi = cos(Phi);
			double SinPhi = sin(Phi);
			complex<double> CosTheta = cosThetaMed(nn, mm);
			complex<double> SinTheta = sqrt(1.0 - pow2(CosTheta));

			complex<double> pvec[3];
			pvec[0] = FresnelP * CosTheta * CosPhi;
			pvec[1] = FresnelP * CosTheta * SinPhi;
			pvec[2] = -1.0*FresnelP * SinTheta;

			complex<double> svec[3];
			svec[0] = -1.0*FresnelS * SinPhi;
			svec[1] = FresnelS * CosPhi;
			svec[2] = 0.0;

			for (int kk = 0; kk < 3; kk++)
			{
				PolarizationVector(nn, mm, 0, kk) = CosPhi * pvec[kk] - SinPhi * svec[kk];
				PolarizationVector(nn, mm, 1, kk) = SinPhi * pvec[kk] + CosPhi * svec[kk];
			}

			std::complex<double> mask = ApertureMask(nn, mm);

			Amplitude(nn, mm) = mask * sqrt(cosThetaImm(nn, mm));
			Amplitude(nn, mm) = Amplitude(nn, mm) / (refmed * cosThetaMed(nn, mm));

			// combining this factor with the Fresnel - coefficient factors T_{ p } and T_{ s }
			//		 the amplitude scales as[sqrt(cos(theta_imm)) / cos(theta_med)] x T_{ p,s }
			//		 where T_{ p } = T_{ p,med->cov } x T_{ p,cov->imm }
			//		 andT_{ s } = T_{ s,med->cov } x T_{ s,cov->imm }
			//		 with T_{ p,med->cov } = 2 * ref_med * cos(theta_med) / [ref_med * cos(theta_cov) + ref_cov * cos(theta_med)]
			//		 andT_{ s,med->cov } = 2 * ref_med * cos(theta_med) / [ref_med * cos(theta_med) + ref_cov * cos(theta_cov)]
			//		 in case of index matching the overall amplitude scaling is with
			//		 [1 / sqrt(cos(theta_med))] x T_{ p,s }
		}
	}
}

void calculate_wave_vector(
		const PupilParams& params,
		View2D<double> XPupil,
		View2D<double> YPupil,
		WriteView2D<std::complex<double>> cosThetaImm,
		WriteView2D<std::complex<double>> cosThetaMed,
		WriteView3D<std::complex<double>> WaveVector,
		WriteView2D<std::complex<double>> WaveVectorZImm
) {
	const int Npupil = params.NPupil;
	const double NA = params.NA;
	const double lambda = params.Lambda;
	const double refmed = params.RefMed;
	const double refimm = params.RefImm;

	for (int nn = 0; nn < Npupil; nn++)
	{
		for (int mm = 0; mm < Npupil; mm++)
		{
			// calculate wavevector inside immersion fluidand z - component inside medium
			WaveVector(nn, mm, 0) = XPupil(nn, mm) * (2 * M_PI * NA / lambda);
			WaveVector(nn, mm, 1) = YPupil(nn, mm) * (2 * M_PI * NA / lambda);
			WaveVector(nn, mm, 2) = cosThetaMed(nn, mm) * (2 * M_PI * refmed / lambda);
			WaveVectorZImm(nn, mm) = cosThetaImm(nn, mm) * (2 * M_PI * refimm / lambda);
		}
	}
}

PupilMatrix::PupilMatrix(const PupilParams& params, int NAberr): AllParams(params), NAberr(NAberr) {
	int NPupil = AllParams.NPupil;

	XPupil.resize(NPupil, NPupil);
	YPupil.resize(NPupil, NPupil);
	AllZernikes.resize(NPupil, NPupil, NAberr);
	AllZernikesNormalized.resize(NPupil, NPupil, NAberr);
	PolarizationVector.resize(NPupil, NPupil, 2, 3);
	Amplitude.resize(NPupil, NPupil);
	cosThetaImm.resize(NPupil, NPupil);
	cosThetaImmnom.resize(NPupil, NPupil);
	cosThetaMed.resize(NPupil, NPupil);
	cosThetaCov.resize(NPupil, NPupil);
	ApertureMask.resize(NPupil, NPupil);
	WaveVector.resize(NPupil, NPupil, 3);
	WaveVectorZImm.resize(NPupil, NPupil);

	get_xy_pupil(
			NPupil,
			XPupil,
			YPupil,
			ApertureMask);

	get_zernike_functions(
			AllParams,
			NAberr,
			XPupil,
			YPupil,
			AllZernikes);

	normalize_zernike_functions(
			AllParams,
			NAberr,
			AllZernikes,
			AllZernikesNormalized);

	zonefun = calculate_zonefun(AllParams, XPupil, YPupil);

	calculate_fresnel_coefficients(
			AllParams,
			NAberr,
			XPupil,
			YPupil,
			ApertureMask,
			cosThetaCov,
			cosThetaImm,
			cosThetaImmnom,
			cosThetaMed,
			PolarizationVector,
			Amplitude);

	calculate_wave_vector(
			AllParams,
			XPupil,
			YPupil,
			cosThetaImm,
			cosThetaMed,
			WaveVector,
			WaveVectorZImm);

	/* NOTE: SAF code path disabled!
	if ((params.NA > params.RefMed) && (params.Depth < 4 * params.Lambda))
		//ZVals = setSAF(params);
        ZVals = getRIMismatchPars(params);
	else
		ZVals = getRIMismatchPars(params);
	*/

	double coeffs[PupilParams::MaxNaberr] = {0};
	update_aberrations(coeffs);
}


void PupilMatrix::update_aberrations(const double* AberrationCoefs) {
	using namespace std::complex_literals;

	const double refmed = AllParams.RefMed;
	const double refimm = AllParams.RefImm;
	const double refimmnom = AllParams.RefImmNom;
	const double lambda = AllParams.Lambda;
	const double NA = AllParams.NA;
	const int Npupil = AllParams.NPupil;

	Matrix.resize(Npupil, Npupil, 2, 3);
	Arr2D<std::complex<double>> Waberration(Npupil, Npupil);

	/* NOTE: SAF code path disabled! And this block should reset Waberration to 0
	         before continuing, because the code block after uses: Waberration(nn, mm) += ...
	//calculation aberration function
	//PupilParams.ZVals are taken to be constants obtained from matlab for comparison only
	if ((NA > AllParams.RefMed) && (AllParams.Depth < 4 * lambda)) {
		for (int nn = 0; nn < Npupil; nn++)
		{
			for (int mm = 0; mm < Npupil; mm++)
			{
				Waberration(nn, mm) = 0;

				for (int j = 0; j < NAberr; j++)
				{
					Waberration(nn, mm) += AllZernikesNormalized(nn, mm, j) * AberrationCoefs[j];
				}
			}
		}

		//ZVals = GetSafFocus(
		//		AllParams,
		//		PolarizationVector,
		//		Amplitude,
		//		Waberration,
		//		XPupil, YPupil,
		//		cosThetaMed,
		//		cosThetaImm,
		//		cosThetaImmnom,
		//		ApertureMask);
	} else {
		// Already initialized in constructor
//			ZVals = getRIMismatchPars(AllParams);
	}
	*/

	for (int nn = 0; nn < Npupil; nn++)
	{
		for (int mm = 0; mm < Npupil; mm++)
		{
			//Waberration(nn, mm) +=
			//		+ cosThetaImm(nn, mm) * ZVals[0] * refimm
			//		- cosThetaImmnom(nn, mm) * ZVals[1] * refimmnom
			//		- cosThetaMed(nn, mm) * ZVals[2] * refmed;

			for (int j = 0; j < NAberr; j++)
			{
				Waberration(nn, mm) += AllZernikesNormalized(nn, mm, j) * AberrationCoefs[j];
			}

			if (AllParams.DoeType==DoeTypeEnum::vortex) {
				double tempzer = zonefun(nn, mm) - floor(zonefun(nn, mm));
				complex<double> doeaberration = tempzer * AllParams.DoePhaseDepth;
				Waberration(nn, mm) += doeaberration;
			}

			Waberration(nn, mm) *= ApertureMask(nn, mm);
			complex<double> phasefactor = exp((2.0 * M_PI / lambda) * 1i * Waberration(nn, mm));

			// compute pupil matrix
			for (int ii = 0; ii < 2; ii++)
			{
				for (int jj = 0; jj < 3; jj++)
				{
					Matrix(nn, mm, ii, jj) = (Amplitude(nn, mm) * phasefactor) * PolarizationVector(nn, mm, ii, jj); //check the dimensions of Amplitude, phasefactor, ..
				}
			}
		}
	}


	// Fill the intensity matrix
	intensity.fill(0);

	for (int iPupil = 0; iPupil < Npupil; iPupil++)
	{
		for (int jPupil = 0; jPupil < Npupil; jPupil++)
		{
			for (int kk = 0; kk < 2; kk++)
			{
				for (int mm = 0; mm < 3; mm++)
				{
					for (int nn = 0; nn < 3; nn++)
					{
						intensity(mm, nn) += real(Matrix(iPupil, jPupil, kk, mm) * conj(Matrix(iPupil, jPupil, kk, nn)));
					}
				}
			}
		}
	}
}

void PupilMatrix::compute_normalization(
		double pola,
		double azim,
		double& normint_free,
		double& normint_fixed)
{
	// This function computes the PSF normalization by evaluating the energy flow through the lens aperture parameters
	double NA = AllParams.NA;
	double lambda = AllParams.Lambda;
	int Npupil = AllParams.NPupil;
	double pixelsize = AllParams.PixelSize;


	// Should there be a difference between the aberr and non-aberr factor?
//	double normfac;
//	if (is_aberr)
//	{
//		normfac = pow2(2.0 / Npupil) / pow2(pixelsize * (NA / lambda));
//	}
//	else
//	{
//		normfac = pow2(2.0 * (NA / lambda) / Npupil) / pow2(pixelsize);
//	}

	// normalization to take into account discretization correctly
	double normfac = pow2(2.0 * (NA / lambda) / Npupil) / pow2(pixelsize);

	//dipole unit vector

	double dipor[3];
	dipor[0] = sin(pola) * cos(azim);
	dipor[1] = sin(pola) * sin(azim);
	dipor[2] = cos(pola);

	//evaluation normalization factors
	double sumfix = 0.0;
	double sumfree = 0.0;

	for (int mm = 0; mm < 3; mm++)
	{
		sumfree += intensity[mm][mm];
	}
	normint_free = (sumfree * normfac) / 3.0;

	for (int mm = 0; mm < 3; mm++)
	{
		for (int nn = 0; nn < 3; nn++)
		{
			sumfix += intensity[mm][nn] * dipor[mm] * dipor[nn];
		}
	}
	normint_fixed = sumfix * normfac;
}