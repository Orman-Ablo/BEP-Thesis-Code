#pragma once

#include "fixed_vector.h"
#include "cuda/macros.cuh"

using stride_t = int;
using index_t = int;
using dim_t = index_t;

template <size_t N>
using ndindex_t = fixed_vector<index_t, N>;

template <size_t N>
using shape_t = ndindex_t<N>;

template <size_t N, typename ...Is>
static constexpr bool is_ndindex = sizeof...(Is) == N && (std::is_convertible<Is, index_t>::value && ...);

enum struct MemorySpace {
	Host,
	Device,
};

template <typename... Ts>
shape_t<sizeof...(Ts)> shape(Ts&&... ts) {
	return {std::forward<Ts>(ts)...};
}

template <typename From, typename To>
struct is_copy_compatible {
	static constexpr bool value = false;
};

template <typename T>
struct is_copy_compatible<T, T> {
	static constexpr bool value = !std::is_const<T>::value;
};

template <typename From, typename To>
struct is_copy_compatible<const From, To>: is_copy_compatible<From, To> {
};

template< class T, class U >
CUDA_HOST_DEVICE
constexpr bool cmp_less(const T& t, const U& u) noexcept {
	using UT = std::make_unsigned_t<T>;
	using UU = std::make_unsigned_t<U>;
	if constexpr (std::is_signed_v<T> != std::is_signed_v<U>) {
		if constexpr (std::is_signed_v<T>) {
			return t < 0 ? true : UT(t) < u;
		} else {
			return u < 0 ? false : t < UU(u);
		}
	}

	return t < u;
}

template<class T, class R>
constexpr bool in_range(const R& input) noexcept {
	return !cmp_less(input, std::numeric_limits<T>::min()) && !cmp_less(std::numeric_limits<T>::max(), input);
}

template <typename T, typename R>
T safe_cast(R input) {
	VF_ASSERT(in_range<T>(input));
	return static_cast<T>(input);
}