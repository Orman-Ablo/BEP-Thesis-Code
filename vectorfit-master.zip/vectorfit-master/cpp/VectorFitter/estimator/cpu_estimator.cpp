#include <cstring>
#include <omp.h>
#include <algorithm>

#include "estimator/cpu_estimator.h"
#include "compute/initial_values.h"
#include "compute/psf.h"
#include "compute/common.h"
#include "compute/theta.h"


void Estimator::PoissonRate(
		const SpotParameters& spot,
		WriteView3D<double> mu,
		WriteView4D<double> dmudtheta,
		View3D<std::complex<double>> OTF)
{
	PoissonRate(
		spot,
		mu,
		dmudtheta,
		AllParams.Mx,
		AllParams.My,
		AllParams.Mz,
		czt_psf,
		OTF
	);
}

void Estimator::PoissonRate(
		const SpotParameters& spot,
		WriteView3D<double> mu,
		WriteView4D<double> dmudtheta,
		int Mx,
		int My,
		int K,
		CztPlan& czt,
		View3D<std::complex<double>> OTF)
{
	using namespace placeholder;

	// Returns the Poisson - rates for all pixels and all first order derivatives w.r.t.the parameters theta.
	FitModelEnum fitmodel = AllParams.FitModel;
	int numparams = fitmodel.num_parameters();
	const int NAberr = fitmodel.num_aberrations();

	int numders = 2;

	if (fitmodel.has_z())
	{
		numders++;

		if (fitmodel.has_fitted_aberrations())
		{
			numders += NAberr; 
		}
	}

	Arr3D<double> Psf(Mx, My, K);
	Arr4D<double> PsfDer(Mx, My, K, numparams);
	Arr5D<std::complex<double>> FieldMatrix(Mx, My, K, 2, 3);
	Arr6D<std::complex<double>> FieldMatrixDer(Mx, My, K, numders, 2, 3);

	if (OTF.data())
	{
		compute::PSFfromOTF(
				AllParams,
				spot,
				czt_otf_to_psf, OTF,
				Psf, PsfDer);
	}
	else
	{
		// Update the pupil function if we have aberrations,
		// either fitted or const
		if (fitmodel.has_aberrations())
		{
			pupil_matrix.update_aberrations(spot.AberrationCoefs);
		}

		compute::GetFieldMatrixDerivatives(
				AllParams,
				spot,
				czt,
				pupil_matrix.get(),
				pupil_matrix.WaveVector,
				pupil_matrix.WaveVectorZImm,
				pupil_matrix.AllZernikes,
				FieldMatrix,
				FieldMatrixDer,
				fitmodel.has_fitted_aberrations());

		double normint_free, normint_fixed;
		pupil_matrix.compute_normalization(
				spot.Pola,
				spot.Azim,
				normint_free,
				normint_fixed);

		compute::GetPsfDerivatives(
				AllParams,
				spot,
				normint_free,
				normint_fixed,
				FieldMatrix,
				FieldMatrixDer,
				Psf,
				PsfDer);

		if (AllParams.psf_blur) //check this in matlab program.
		{
			//=== PSF pixel blurring =========
			for (int jz = 0; jz < K; jz++) {
				compute::DoPixelBlurring(
						AllParams, pixel_bluring_fft,
						Psf.view(_, _, jz),
						Psf.view(_, _, jz));

				for (int jder = 0; jder < std::min(3, numparams); jder++) {
					compute::DoPixelBlurring(
							AllParams, pixel_bluring_fft,
							PsfDer.view(_, _, jz, jder),
							PsfDer.view(_, _, jz, jder));
				}
			}
			//=============================================
		}
	}

	compute::PSFtoMu(
			AllParams,
			spot,
			Psf,
			PsfDer,
			mu,
			dmudtheta);
}

void Estimator::InitialValues(View3D<double> OneSpot, WriteView1D<double> ThetaInit)
{
	/* old init model - not used anymore
	if (AllParams.FitModel.has_aberrations()) {
		compute::InitialValues_aberr(AllParams, OneSpot, ThetaInit);
	} else */ {
		compute::InitialValues(AllParams, OneSpot, ThetaInit);
	}
}

void Estimator::VerifyOTF(SpotParameters spot, View3D<std::complex<double>> OTF) {
	// Verification
	int numparams = AllParams.FitModel.num_parameters();
	const bool has_z = AllParams.FitModel.has_z();
	Arr3D<double> PSFFromOTF(AllParams.Mx, AllParams.My, AllParams.Mz);
	Arr4D<double> PSFderFromOTF(AllParams.Mx, AllParams.My, AllParams.Mz, numparams);
	Arr3D<double> SpotMu(AllParams.Mx, AllParams.My, AllParams.Mz);
	Arr4D<double> SpotMuDer(AllParams.Mx, AllParams.My, AllParams.Mz, numparams);

	for (double xemit = -30.0; xemit <= 30.1; xemit += 30.0) {
		for (double yemit = -30.0; yemit <= 30.1; yemit += 30.0) {
			for (double zemit = -30.0*(int)has_z; zemit <= 30.1*(int)has_z; zemit += 30.0) {
				spot.XEmit = xemit;
				spot.YEmit = yemit;
				spot.ZEmit = zemit;
				PoissonRate(spot, SpotMu, SpotMuDer, AllParams.Mx, AllParams.My, AllParams.Mz, czt_psf, {}); // Without OTF
				View3D<double> SpotPSF = SpotMu;
				compute::PSFfromOTF(AllParams, spot, czt_otf_to_psf, OTF, PSFFromOTF, PSFderFromOTF);
				Arr3D<double> psf_diff = PSFFromOTF - SpotPSF;
				Arr3D<double> rel_psf_diff = psf_diff / SpotPSF;
				std::cout << "Spot PSF error range at ("
					<< spot.XEmit << ", " << spot.YEmit << ", " << spot.ZEmit
					<< "): "
					<< "[" << psf_diff.minimum() << ", " << psf_diff.maximum() << "]" << std::endl;
				std::cout << "Relative spot PSF error range at ("
					<< spot.XEmit << ", " << spot.YEmit << ", " << spot.ZEmit
					<< "): "
					<< "[" << rel_psf_diff.minimum() << ", " << rel_psf_diff.maximum() << "]" << std::endl;
			}
		}
	}
}

void Estimator::ComputeOTF(
	View1D<double> otf_zernike_coefficients,
	WriteView3D<std::complex<double>> OTF
) {
	// This function computes an OTF from a (usually large) PSF.
	using namespace placeholder;
	int num_aberr = AllParams.FitModel.num_aberrations();
	VF_ASSERT(otf_zernike_coefficients.size(0) == num_aberr);
	// Assure OTF shape
	VF_ASSERT(OTF.shape() == shape(AllParams.Notfx, AllParams.Notfy, AllParams.Notfz));
	// Use the PSF size as regular ROI size for the PSF estimation
	int Mpsfx = AllParams.Mpsfx;
	int Mpsfy = AllParams.Mpsfy;
	int Mpsfz = AllParams.Mpsfz;

	//int Ncfg = otf_grid_size_x * otf_grid_size_y;
	int numparams = AllParams.FitModel.num_parameters();

	// Create theta: all zeros except the aberration coefficients.
	Arr1D<double> theta;
	theta.resize({AllParams.FitModel.theta_size()}, 0.0);
	theta.view(
		range(
			AllParams.FitModel.offset_aberrations(),
			AllParams.FitModel.offset_aberrations()+num_aberr
		)
	) = otf_zernike_coefficients;

	Arr3D<double> mu(Mpsfx, Mpsfy, Mpsfz);
	Arr4D<double> muder(Mpsfx, Mpsfy, Mpsfz, numparams);
	// Compute spot
	SpotParameters spot = SpotParameters::from_theta(AllParams.FitModel, theta);
	// With Nph = 1.0 and Nbg = 0.0, mu == psf
	spot.Nph = 1.0;
	spot.Nbg = 0.0;

	// Compute PSF for OTF
	// Create PSF with xrange = PsfXRange, Mx = Mpsfx
	// Compute PoissonRate for Mpsfx/y/z and with OTF disabled of course
	PoissonRate(spot, mu, muder, Mpsfx, Mpsfy, Mpsfz, czt_psf_for_otf, {});
	View3D<double> PSF = mu;

	// Compute the OTF from the center PSF
	Arr3D<std::complex<double>> complexPSF = PSF;
	czt_psf_to_otf.execute(complexPSF, OTF);
	// Take the complex conjugate to make FT and IFT consistent
	OTF.for_each(
		[&](std::complex<double>& value) {value = conj(value);}
	);
	// Verification (for debugging)
	//VerifyOTF(spot, OTF);
}

void Estimator::Localize(
		View3D<double> OneSpot,
		View1D<double> ThetaInit,
		View3D<std::complex<double>> OTF,
		WriteView2D<double> ThetaStore,
		WriteView3D<double> mu3,
		WriteView4D<double> dmu3dTheta,
		WriteView1D<double> MeritStore,
		int& NumIters,
		bool& IsConverged)
{
	using namespace placeholder;
	double tollim = AllParams.Tollim;
	int Nitermax = AllParams.NiterMax;
	FitModelEnum FitModel = AllParams.FitModel;
	int numparams = FitModel.num_parameters();
	int theta_size = FitModel.theta_size();

	Arr1D<double> theta(theta_size);
	Arr1D<double> thetaTry(theta_size);
	Arr1D<double> thetaMin(theta_size);
	Arr1D<double> thetaMax(theta_size);
	Arr1D<double> thetaRetry(theta_size);

	theta = ThetaInit;
	compute::ThetaLimits(AllParams, theta, thetaMin, thetaMax, thetaRetry);

	SpotParameters spot = SpotParameters::from_theta(FitModel, theta);
	PoissonRate(spot, mu3, dmu3dTheta, OTF);

	double merit = compute::Likelihood(
			AllParams,
			OneSpot,
			mu3);

	//temp variables
	Arr1D<double> gradL(numparams);
	Arr2D<double> Hessian(numparams, numparams);
	compute::ComputeThetaDerivate(
			AllParams,
			OneSpot,
			mu3,
			dmu3dTheta,
			gradL,
			Hessian);

	//start iteration loop
	double monitor = 2 * tollim;
	double alamda = 1.0;
	double alamdafac = 10;
	int iiter = 0;

	while (monitor > tollim && iiter < Nitermax)
	{
		//update parameters
		bool is_invertible = compute::ThetaUpdate(
			AllParams,
			theta,
			thetaMax,
			thetaMin,
			thetaRetry,
			gradL,
			Hessian,
			alamda,
			thetaTry);

		if (is_invertible)
		{
			// calculate and update the merit function
			spot = SpotParameters::from_theta(FitModel, thetaTry);
			PoissonRate(spot, mu3, dmu3dTheta, OTF);

			double meritTry = compute::Likelihood(
					AllParams,
					OneSpot,
					mu3);

			double dmerit = meritTry - merit;

			// modify Levenberg - Marquardt parameter
			if (dmerit < 0)
			{
				alamda *= alamdafac;
			}
			else
			{
				compute::ComputeThetaDerivate(
						AllParams,
						OneSpot,
						mu3, dmu3dTheta,
						gradL, Hessian);

				alamda = alamda / alamdafac;
				theta = thetaTry;
				thetaRetry = thetaTry;
				merit = meritTry;
				monitor = std::abs(dmerit / merit);
			}
		}
		else
		{
			alamda *= alamdafac;
		}

		// store values and update counter
		NumIters = iiter + 1;
		ThetaStore.view(_, iiter + 1) = theta;
		MeritStore(iiter + 1) = merit;
		iiter++;
	}

	IsConverged = monitor <= tollim;

	// Fill remaining iterations
	while (iiter < Nitermax)
	{
		ThetaStore.view(_, iiter + 1) = theta;
		MeritStore(iiter + 1) = merit;
		iiter++;
	}

	compute::AddMeritOffset(AllParams, MeritStore, OneSpot);
}


Estimator::Estimator(FitParams fitParam)
	: AllParams(fitParam)
	, pupil_matrix(fitParam, fitParam.FitModel.num_aberrations())
{
	czt_psf = CztPlan(fitParam.NPupil, fitParam.Mx, fitParam.PupilSize, fitParam.XRange);
	if (fitParam.FlagOTF) {
		std::array<double, 3> otf_roi_sizes{
			AllParams.XRange * AllParams.NA / AllParams.Lambda,
			AllParams.YRange * AllParams.NA / AllParams.Lambda,
			// TODO:3DOTF what's the ZRange here?
			0.5*(AllParams.ZRange[1]-AllParams.ZRange[0]) * AllParams.NA / AllParams.Lambda};
		std::array<double, 3> otf_xsizes{
			AllParams.PsfXRange * AllParams.NA / AllParams.Lambda,
			AllParams.PsfYRange * AllParams.NA / AllParams.Lambda,
			AllParams.PsfZRange * AllParams.NA / AllParams.Lambda};

		double otf_fourier_window = 2.0;
		std::array<double, 3> otf_qsizes{
			otf_fourier_window,
			otf_fourier_window,
			otf_fourier_window};

		czt_otf_to_psf = CztPlan(
			fitParam.Notfx,
			fitParam.Mx,
			otf_fourier_window,
			AllParams.XRange * AllParams.NA / AllParams.Lambda);
		czt_psf_for_otf = CztPlan(fitParam.NPupil, fitParam.Mpsfx, fitParam.PupilSize, fitParam.PsfXRange);
		// The czt_psf_to_otf plan corresponds with Matlab's get_otf.m
		czt_psf_to_otf = CztPlan3D(
			shape(fitParam.Mpsfx, fitParam.Mpsfy, fitParam.Mpsfz),
			shape(fitParam.Notfx, fitParam.Notfy, fitParam.Notfz),
			otf_xsizes,
			otf_qsizes);
	} else {
		pixel_bluring_fft = FFT2DPlan(fitParam.Mx, fitParam.My);
	}
}

Estimator::~Estimator() = default;

/*void Estimator::SetOTF(const std::shared_ptr<otf_type>& NewOTF) {
	OTF = NewOTF;
}*/
