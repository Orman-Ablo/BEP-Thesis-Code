/* vectorfit_flip_z
 * vectorfit_flip_z();
 * Flip the z-coordinate in the theta of a vectorfitter object.
*/

#include "vectorfit_mex.hpp"
#include "vectorfit_fitter.hpp"


class MexFunction : public VectorfitMexFunction {
public:
    using ArgumentList = matlab::mex::ArgumentList;

    void execute(ArgumentList outputs, ArgumentList inputs) {
        // Obtain fitter object handle
        const uint64_t handle = inputs[0][0];
        VectorfitFitter* fitter = VectorfitMemoryManager::get(handle);
        // Flip z
        fitter->fitter().flip_z();

        // Output theta, if requested.
        if (outputs.size() == 1) {
            // Only output the actual parameters and not
            // potential const aberration coefficients.
            View2D<double> theta = fitter->fitter().theta_params_only();
            TypedArray<double> output_theta = _array_factory.createArray<double>(
                {(uint64_t)theta.size(1), (uint64_t)theta.size(0)}
            );
            // Create output iterator and copy data
            auto output_theta_begin = output_theta.begin();
            theta.for_each(
                [&](const double& value) {*(output_theta_begin++) = value;}
            );
            outputs[0] = output_theta;
        }
    }

    void checkArguments(ArgumentList outputs, ArgumentList inputs) {
        // Check array argument: first input must be an uint64_t scalar
        if (inputs[0].getType() != ArrayType::UINT64 ||
            inputs[0].getNumberOfElements() != 1)
        {
            feval_error("Input must be a vectorit handle in the form of a uint64 scalar");
        }
        // Outputs: either none or theta
        if (outputs.size() > 1)
        {
            feval_error("Only 1 optional output is returned (theta)");
        }
    }
};
