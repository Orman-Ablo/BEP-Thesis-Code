function [thetainit,theta,thetastore,meritstore,mu,dmudtheta,Niters,outliers,localizations,localizations_with_outliers,monitorstore_total] = localization_nat(allspots,roixy,framelist,ID,params)
% This function fits the local (location,N,b) and global (gamma) parameters
% given single emitter data.
%
% INPUT
% -allspots = all segmented spots
% -roixy = the locations in the FOV of the spots, in pixels
% -thetainit = initial estimate of the fitting variables
% -params
%
% OUTPUT
% -theta = the final accepted theta.
% -thetastore = the accepted theta in each iteration.
% -meritstore = value of the cost function in each iteration per spot.
% -meritstore_total = value of the cost function in each iteration per spot.
% -mu = the final modeled N*PSFs+bg
% -dmudtheta = derivative of each pixel w.r.t. thetas
% 
% Autor: Isabel Droste, TU Delft, 2022, 2023

%% Settings
numparams = params.numparams;
numgammas = params.numgammas;
Ncfg = params.Ncfg;
min_total_iterations = params.min_total_iterations;
max_total_iterations = params.max_total_iterations;

%% Allocation
% index convention: numparams x Ncfg x iterations

thetastore_local = zeros(numparams,Ncfg,0);
thetastore_global = zeros(numgammas,0);

meritstore_local = zeros(Ncfg,0);
meritstore_global = [];
monitorstore_total = [];

alambda_local = ones(Ncfg,1)*params.alambda0_local;
alambda_global = params.alambda0_global;

Niters_local = zeros(Ncfg,0);
Niters_global = [];

params.perform_final_iterations = false;
flip_z_net = false;

%% Initial values

thetainit.global = initialvalues_phasor_nat(params);
if params.cpp
    fitmodel_matlab = params.fitmodel;
    if strcmp(fitmodel_matlab,'xy-gamma')
        params.fitmodel = 'xy-constaberrations';
    elseif strcmp(fitmodel_matlab,'xyz-gamma')
        params.fitmodel = 'xyz-constaberrations';
    end
    fitter = vectorfitter(allspots,roixy, params,params.cpp_fitmode);
    fitter.update_zernike_coefficients(thetainit.global, params.aberrations);
    thetainit.local = fitter.theta_init();
    params.fitmodel = fitmodel_matlab;
else
    thetainit.local = initialvalues_phasor(allspots,roixy,thetainit.global,params);
end

theta_local = thetainit.local;
theta_global = thetainit.global;

%% Update loop

tollim_total = params.tollim_total;
monitor_total = 2*tollim_total;
iiter_total = 1;

%[theta_global,thetastore_global,meritstore_global,alambda_global,dmudtheta_global,Niters_global,flip_z_net] = ...
%global_update(theta_local,theta_global,thetastore_global,meritstore_global,alambda_global,allspots,roixy,iiter_total,Niters_global,[],params);

while ((iiter_total<=max_total_iterations) && ((iiter_total<=min_total_iterations) || (monitor_total>tollim_total)))

    % Local update
    if params.cpp
        [fitter,theta_local,thetastore_local,localizations,localizations_with_outliers,meritstore_local,mu,dmudtheta_local,Niters_local,outliers] = ...
        local_update_cpp(fitter,thetastore_local,theta_global,meritstore_local,allspots,roixy,iiter_total,Niters_local,flip_z_net,framelist,ID,params); 
    else
        [theta_local,thetastore_local,localizations,localizations_with_outliers,meritstore_local,alambda_local,mu,dmudtheta_local,Niters_local,outliers] = ...
        local_update(theta_local,thetastore_local,theta_global,meritstore_local,alambda_local,allspots,roixy,iiter_total,Niters_local,flip_z_net,framelist,ID,params);    
    end

    % Global update
    [theta_global,thetastore_global,meritstore_global,alambda_global,dmudtheta_global,Niters_global,flip_z_net] = ...
    global_update(theta_local,theta_global,thetastore_global,meritstore_global,alambda_global,allspots,roixy,iiter_total,Niters_global,outliers,params);
    
    if iiter_total>=2
        meritstore_local_sum = sum(meritstore_local,1);
        dmerit_total = meritstore_local_sum(end) - meritstore_local_sum(end-1);
        monitor_total = abs(dmerit_total/meritstore_local_sum(end)); 
    end
    monitorstore_total(end+1) = monitor_total;
    iiter_total = iiter_total + 1;

end

% %%% Put inverse aberrations here
% theta_global = zeros(params.numgammas,1);
% theta_global(5) = 150*1e-3*params.lambda;
% theta_global(10) = 50*1e-3*params.lambda; %coma
% %%%

% Final local update (for final merit)
% Local update
if params.cpp
    [fitter,theta_local,thetastore_local,localizations,localizations_with_outliers,meritstore_local,mu,dmudtheta_local,Niters_local,outliers] = ...
    local_update_cpp(fitter,thetastore_local,theta_global,meritstore_local,allspots,roixy,iiter_total,Niters_local,flip_z_net,framelist,ID,params); 
    fitter.delete();
else
    [theta_local,thetastore_local,localizations,localizations_with_outliers,meritstore_local,alambda_local,mu,dmudtheta_local,Niters_local,outliers] = ...
    local_update(theta_local,thetastore_local,theta_global,meritstore_local,alambda_local,allspots,roixy,iiter_total,Niters_local,flip_z_net,framelist,ID,params);    
end

% Calculate global CRLB with all spots
params_temp = params;
params_temp.selected_indices_global = 1:params.Ncfg;
[~,~,~,~,dmudtheta_global_all] = get_merit_nat(theta_local,theta_global,allspots,roixy,params_temp);


%% Process results
meritstore.local = meritstore_local;
meritstore.global = meritstore_global;

theta.local = theta_local;
theta.global = theta_global;

thetastore.local = thetastore_local;
thetastore.global = thetastore_global;

dmudtheta.local = dmudtheta_local;
dmudtheta.global = dmudtheta_global_all;

Niters.local = Niters_local;
Niters.global = Niters_global;

end