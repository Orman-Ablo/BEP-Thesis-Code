
clear all
close all

params = set_parameters_xy_NAT;

% Generate data
params.generate_new_data = true;
params.add_newnoise = false;
params.simulated_data = true;
params.groundtruth_exists = true;
plot_data = true;
final_local_update = false;

get_NAT_data

%%
fprintf('\nPerform local fit with %i spots\n',Ncfg_total);

theta_global = groundtruth.global;

params.fitmodel = 'xy_constaberrations';
params.initialization = 'phasor';
params.FlagOTF = true;
params.Mpsfx = 129;
params.Mpsfy = 129;
params.NFourier = 42;
params.OTFGridSizeX = 20;
params.OTFGridSizeY = 20;

tic
cpp_spots = allspots;
fitter = vectorfitter(cpp_spots,roixy, params,"gpu-lowaccuracy");%gpu-lowaccuracy
fitter.recompute_zernike_coefficients(theta_global, params.aberrations);
theta_init_cpp = fitter.theta_init();
cpp_zernike_coeffs = fitter.recompute_zernike_coefficients(theta_global, params.aberrations);
[cpp_theta_update, cpp_num_iters] = fitter.local_update();
toc
cpp_outliers = fitter.outliers();
delete(fitter)


%% Compare to matlab fit

max_local_iterations = params.max_local_iterations;
numparams = params.numparams;

% Set up parallel pool
if isempty(gcp('nocreate'))
    number_of_parallel_workers = params.nr_of_parallel_workers;
    parpool('Threads', number_of_parallel_workers);
end

tic;
params.fitmodel = 'xy-gamma';
theta_global = groundtruth.global;

theta_init_matlab = initialvalues_phasor(allspots,roixy,theta_global,params);
theta_local = theta_init_matlab;
thetastore_local = zeros(numparams,Ncfg_total,max_local_iterations);
meritstore = zeros(Ncfg_total,max_local_iterations);
alambda_local = ones(Ncfg_total,1)*params.alambda0_local;
Niters = zeros(Ncfg_total,1);
flip_z_net = false;
iiter_total = 1;

[theta_local,thetastore_local,localizations,localizations_with_outliers,meritstore,alambda_local,mu,dmudtheta_local,Niters,outliers] = ...
local_update(theta_local,thetastore_local,theta_global,meritstore,alambda_local,allspots,roixy,iiter_total,Niters,flip_z_net,framelist,ID,params);
 
toc;

%% Compare outputs


diff_matlab_gpu = cpp_theta_update - theta_local;
figure
for i=1:numparams
    subplot(2,3,i)
    histogram(diff_matlab_gpu(i,:))
end
sgtitle('Difference theta update')

numel(setdiff(find(diff_matlab_gpu(3,:)>1e-2),outliers))


diff_init = theta_init_matlab - theta_init_cpp;
figure
for i=1:numparams
    subplot(2,3,i)
    histogram(diff_init(i,:))
end
sgtitle('Difference theta init')

%% Compare pupilmatrix

% clear all
% 
% params = set_parameters_xy_NAT;
% 
% get_NAT_data
% 
% cpp_spots = allspots;
% fitter = vectorfitter(cpp_spots,roixy, params,"cpu");%gpu-lowaccuracy
% 
% params.fitmodel = 'xy_constaberrations';
% fitter = vectorfitter(cpp_spots, roixy, cpp_params, "gpu");

% Matlab pupil matrix comparison
% if compare_matlab_cpp && size(cpp_spots,4) == params.Ncfg
%     pupil_matrix_zernike_coefficients = rand(6,1);
%     [wavevector,wavevectorzimm,~,allzernikes,PupilMatrixInit] = get_pupil_matrix(params, pupil_matrix_zernike_coefficients);
%     cpp_pupil_matrix = fitter.get_pupil_matrix(pupil_matrix_zernike_coefficients);
%     pupil_matrix_max_diff = max(max(max(max(abs(cpp_pupil_matrix - PupilMatrixInit)))))
% end
% 
% params.fitmodel = 'xy-gamma';
% [~,~,~,~,pupilmatrix_matlab] = get_pupil_matrix(params,zernikeCoefficients(1,:));

