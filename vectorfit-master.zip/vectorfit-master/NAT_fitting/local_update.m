function [theta_local,thetastore_local,localizations,localizations_with_outliers,meritstore_local,alambda_local,mu_allspots,dmudtheta_allspots,Niters_local,outliers] = ...
         local_update(theta_local,thetastore_local,theta_global,meritstore_local,alambda_local,allspots,roixy,iiter_total,Niters_local,flip_z_net,framelist,ID,params)
% This function executes an update of the local variables, consisting of
% multiple local iterations.
%
% Autor: Isabel Droste, TU Delft, 2022, 2023

% To do: make sure that 10 iteration really does 10 iterations
% and that the spots that converge in the last iterations are not seen as
% outliers

% When symmetric aberrations have been flipped an uneven nr. of times in
% previous global update, z-coordinates need to be flipped
if flip_z_net
    theta_local(3,:) = -1*theta_local(3,:);
end

% Settings
Ncfg = params.Ncfg;
numparams = params.numparams;
tollim = params.tollim;
varfit = params.varfit;
max_local_iterations = params.max_local_iterations;
min_local_iterations = params.min_local_iterations;
fitmodel = params.fitmodel;

% Allocation and initialization
mu_allspots = zeros(params.Mx,params.My,params.K,Ncfg);
dmudtheta_allspots = zeros(params.Mx,params.My,params.K,numparams,Ncfg);
Niters_temp = zeros(1,Ncfg);
thetastore_local_temp = zeros(numparams,Ncfg);
meritstore_local_temp = zeros(Ncfg,1);

% Compute aberrations
%if strcmp(fitmodel,'xy-gamma') || strcmp(fitmodel,'xyz-gamma')
fov_coordinates = get_fov_coordinates(roixy,theta_local(1,:),theta_local(2,:),params);
zernikeCoefficients = get_zernike_coefficients(fov_coordinates(1,:), fov_coordinates(2,:), theta_global, params);
%else
%    zernikeCoefficients = repmat(params.aberrations(:,3),[1,Ncfg])';
%end
    
%% Local update loop
fprintf('\nStart local update %i\n',iiter_total);

%parfor jcfg = 1:Ncfg
%parfor jcfg = 1:1000
for jcfg = 1:Ncfg

    if rem(jcfg,round(Ncfg/10)) == 0
        fprintf('fitting spot %i\n',jcfg);
    end
    
    % inital values
    theta = theta_local(:,jcfg);
    spot = allspots(:,:,:,jcfg);
    [thetamin,thetamax] = thetalimits(params,theta);
    thetaretry = (thetamax+thetamin)/2;
    
    % TODO: OTF method.
    %
    % note: there is an overlap with the last iteration of the global update,
    % both compute the PSF, this can be combined.
    [wavevector,wavevectorzimm,~,allzernikes,PupilMatrix] = get_pupil_matrix(params,zernikeCoefficients(jcfg,:));
    
    % if params.OTF
    %     params_local = params;
    %     params_local.xemit = 0;
    %     params_local.yemit = 0;
    %     % Calculate center PSF
    %     [FieldMatrix,FieldMatrixDerivatives] = get_field_matrix_derivatives(params_local,PupilMatrix,allzernikes,wavevector,wavevectorzimm);
    %     [PSF,~] = get_psfs_derivatives(params_local,PupilMatrix,FieldMatrix,FieldMatrixDerivatives);
    % 
    %     % Calculate OTF from PSF
    %     OTF = get_otf(PSF,params);
    % end
    %params.OTF = false;
    [mu,dmudtheta] = poissonrate(params,theta,PupilMatrix,allzernikes,wavevector,wavevectorzimm);
    [merit,grad,Hessian] = likelihood(params,spot,mu,dmudtheta,varfit);
    meritprev = merit;
    
    % start iteration loop
    iiter = 1;
    monitor = 2*tollim;
    alambda = alambda_local(jcfg);
    alambdafac = params.alambdafac_local;
    
    while ((iiter<=max_local_iterations) && ((iiter<=min_local_iterations) || (monitor>tollim)))

        %fprintf('spot %i iter %i\n',jcfg,iiter);
         
        % update parameters
        [thetatry,~] = thetaupdate(theta,thetamax,thetamin,thetaretry,grad,Hessian,alambda,params);

        % calculate update merit function
        [mutry,dmudthetatry] = poissonrate(params,thetatry,PupilMatrix,allzernikes,wavevector,wavevectorzimm);
        [merittry,gradtry,Hessiantry] = likelihood(params,spot,mutry,dmudthetatry,varfit);
        dmerit = merittry-merit;
        
        % modify Levenberg-Marquardt parameter
        if (dmerit<0)
            alambda = alambdafac*alambda;
        else
            alambda = alambda/alambdafac;
            theta = thetatry;
            mu = mutry;
            dmudtheta = dmudthetatry;
            merit = merittry;
            grad = gradtry;
            Hessian = Hessiantry;
            dmerit = merit-meritprev;
            monitor = abs(dmerit/merit);
            meritprev = merit;
            thetaretry = theta;
        end
    
        % Store values and update counter
        thetastore_local_temp(:,jcfg) = theta;
        meritstore_local_temp(jcfg) = merit;

        iiter = iiter+1;
        
    end % end while iiter<max_local_iterations && monitor>tollim

    Niters_temp(jcfg) = iiter-1;
    if monitor>=tollim
        Niters_temp(jcfg) = iiter; 
    end

    theta_local(:,jcfg) = theta;
    alambda_local(jcfg) = alambda;     
    mu_allspots(:,:,:,jcfg) = mu;
    dmudtheta_allspots(:,:,:,:,jcfg) = dmudtheta;
    
end % end for jcfg = 1:Ncfg

Niters_local(:,iiter_total) = Niters_temp';
thetastore_local(:,:,end+1) = thetastore_local_temp;
meritstore_local(:,end+1) = meritstore_local_temp;
% Outliers are computed again each update, so the previous outliers are not
% remembered.
outliers = find(get_outliers(theta_local,meritstore_local(:,end),Niters_temp,mu_allspots,allspots,params));

% Calculate CRLB
CRLB_local = get_fisher_crlb(params,mu_allspots,dmudtheta_allspots);

% Create localization list in physical FOV coordinates. Format:
% x(nm) y(nm) (z(nm)) framelist CRLBx CRLBy CRLBz Nph bg
Ncfg_total = size(theta_local,2);
localizations_with_outliers = zeros(Ncfg_total,10);

[~,fov_coordinates_physical] = get_fov_coordinates(roixy,theta_local(1,:),theta_local(2,:),params);
fov_coordinates_physical_nm = 1e3*fov_coordinates_physical;
localizations_with_outliers(:,1) = ID;
localizations_with_outliers(:,2:3) = fov_coordinates_physical_nm(1:2,:)';
localizations_with_outliers(:,5) = framelist';
localizations_with_outliers(:,6) = CRLB_local(1,:)';
localizations_with_outliers(:,7) = CRLB_local(2,:)';
if contains(params.fitmodel,'xyz')
    localizations_with_outliers(:,4) = theta_local(3,:)'; 
    localizations_with_outliers(:,8) = CRLB_local(3,:)';
    localizations_with_outliers(:,9) = theta_local(4,:)';
    localizations_with_outliers(:,10) = theta_local(5,:)';
else
    localizations_with_outliers(:,4) = zeros(Ncfg_total,1);
    localizations_with_outliers(:,8) = zeros(Ncfg_total,1);
    localizations_with_outliers(:,9) = theta_local(3,:)';
    localizations_with_outliers(:,10) = theta_local(4,:)';
end

no_outliers = setdiff(1:Ncfg_total,outliers);
localizations = localizations_with_outliers(no_outliers,:);

end % end of function
