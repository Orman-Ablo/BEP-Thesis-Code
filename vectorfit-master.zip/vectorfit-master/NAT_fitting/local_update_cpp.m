function [fitter,theta_local,thetastore_local,localizations,localizations_with_outliers,meritstore_local,mu,dmudtheta_local,Niters_local,outliers] = ...
        local_update_cpp(fitter,thetastore_local,theta_global,meritstore_local,allspots,roixy,iiter_total,Niters_local,flip_z_net,framelist,ID,params)  
% Perform a local update using the c++ code.
% The code is equivalent to the matlab script local_update.
% This local update can be done either on the CPU or GPU

fprintf('\nStart local update %i with %s\n',iiter_total,params.cpp_fitmode);

if flip_z_net
    fitter.flip_z();
end

zernike_coefficients = fitter.update_zernike_coefficients(theta_global, params.aberrations);
zernike_mlambda = zernike_coefficients*1e3/params.lambda;
[theta_local, Niters_temp] = fitter.local_update();
outliers = fitter.outliers();
CRLB_local = fitter.fisher_crlb();
mu = fitter.mu();
dmudtheta_local = fitter.dmudtheta();

thetastore_local(:,:,end+1) = theta_local;
Niters_local(:,iiter_total) = Niters_temp;

% Calculate the merit (maybe c++ code can return this instead)
Ncfg = size(theta_local,2);
lastcol = size(meritstore_local,2)+1;
for jcfg = 1:Ncfg
    meritstore_local(jcfg,lastcol) = likelihood(params,allspots(:,:,:,jcfg),mu(:,:,:,jcfg),dmudtheta_local(:,:,:,:,jcfg),params.varfit);
end

localizations_with_outliers = zeros(Ncfg,10);

[~,fov_coordinates_physical] = get_fov_coordinates(roixy,theta_local(1,:),theta_local(2,:),params);
fov_coordinates_physical_nm = 1e3*fov_coordinates_physical;
localizations_with_outliers(:,1) = ID;
localizations_with_outliers(:,2:3) = fov_coordinates_physical_nm(1:2,:)';
localizations_with_outliers(:,5) = framelist';
localizations_with_outliers(:,6) = CRLB_local(1,:)';
localizations_with_outliers(:,7) = CRLB_local(2,:)';
if contains(params.fitmodel,'xyz')
    localizations_with_outliers(:,4) = theta_local(3,:)'; 
    localizations_with_outliers(:,8) = CRLB_local(3,:)';
    localizations_with_outliers(:,9) = theta_local(4,:)';
    localizations_with_outliers(:,10) = theta_local(5,:)';
else
    localizations_with_outliers(:,4) = zeros(Ncfg,1);
    localizations_with_outliers(:,8) = zeros(Ncfg,1);
    localizations_with_outliers(:,9) = theta_local(3,:)';
    localizations_with_outliers(:,10) = theta_local(4,:)';
end

no_outliers = setdiff(1:Ncfg,outliers);
localizations = localizations_with_outliers(no_outliers,:);

end