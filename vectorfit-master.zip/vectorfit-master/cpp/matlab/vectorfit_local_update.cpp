/* vectorfit_get_zernike_coefficients
 * z_coeffs = vectorfit_get_zernike_coefficients(xn, yn, gammas, params);
 * Calculates the Zernike coefficients, given gamma coefficients and x,y locations.
 * - xn,yn: coordinates or meshgrid of points for which we want to determine
 *   the Zernike coefficients. Units: physical coordinates of the total FOV
 *   (um) where the origin is at the outer edge of pixel 1,1.
 * - gammas: the gamma coefficients that determine how the Zernike
 *   Coefficients depend on x,y.
 *
 * returns an array or surface containing the zernike coeffcients in nm for each point (xn,yn)
*/

#include "vectorfit_mex.hpp"
#include "vectorfit_fitter.hpp"
#include "array/operators.h"


class MexFunction : public VectorfitMexFunction {
public:
    using ArgumentList = matlab::mex::ArgumentList;
    using Struct = matlab::data::Struct;
    using StructArray = matlab::data::StructArray;

    void execute(ArgumentList outputs, ArgumentList inputs) {
        // Obtain fitter object handle
        const uint64_t handle = inputs[0][0];
        VectorfitFitter* fitter = VectorfitMemoryManager::get(handle);
        // Perform local update
        fitter->fitter().update();
        // Output theta. Only output the actual parameters and not
        // potential const aberration coefficients.
        View2D<double> theta = fitter->fitter().theta_params_only();
        TypedArray<double> output_theta = _array_factory.createArray<double>(
            {(uint64_t)theta.size(1), (uint64_t)theta.size(0)}
        );
        // Create output iterator and copy data
        auto output_theta_begin = output_theta.begin();
        theta.for_each(
            [&](const double& value) {*(output_theta_begin++) = value;}
        );
        outputs[0] = output_theta;
        // Output num iters
        View1D<int> num_iters = fitter->fitter().num_iters();
        outputs[1] = _array_factory.createArray<int>(
            {(uint64_t)num_iters.size(0)},
            num_iters.begin(),
            num_iters.end()
        );
    }

    void checkArguments(ArgumentList outputs, ArgumentList inputs) {
        // Check array arguments
        if (inputs.size() != 1) {
            feval_error("Number of required inputs is 1: (vectorfit_handle)");
        }
        // Check array argument: first input must be a uint64_t scalar
        if (inputs[0].getType() != ArrayType::UINT64 ||
            inputs[0].getNumberOfElements() != 1)
        {
            feval_error("Input 1 must be a vectorfit handle in the form of a uint64 scalar");
        }
        if (outputs.size() != 2)
        {
            feval_error("Two outputs are returned: theta and number of iterations");
        }
    }
};
