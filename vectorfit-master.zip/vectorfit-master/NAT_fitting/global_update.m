function [theta_global,thetastore_global,meritstore_global,alambda_global,dmudtheta_allspots,Niters_global,flip_z_net] = ...
         global_update(theta_local,theta_global,thetastore_global,meritstore_global,alambda_global,allspots,roixy,iiter_total,Niters_global,outliers,params)
% This function executes an update of the local variables, consisting of
% multiple global iterations.
%
% Autor: Isabel Droste, TU Delft, 2022, 2023

% Settings
Ncfg = params.Ncfg;
Ncfg_global = params.Ncfg_global;
tollim = params.tollim;
max_local_iterations = params.max_local_iterations;
min_global_iterations = params.min_global_iterations;
max_global_iterations = params.max_global_iterations;
per_final_iteration = params.per_final_iteration;
numgammas_fitted = params.numgammas_fitted;

% Select global spots for this round
if params.select_spots
    %no_outliers = setdiff(1:Ncfg,outliers);
    %idx = randperm(numel(no_outliers),Ncfg_global); 
    %params.selected_indices_global = no_outliers(idx);

    %%%%%%%%%%%%%%%%%%%%
    % Use preselected global indices
    params.selected_indices_global = setdiff(params.selected_indices_global_all(:,iiter_total),outliers);
    %%%%%%%%%%%%%%%%%%%%
else
    params.selected_indices_global = 1:Ncfg;
    params.selected_indices_global = setdiff(params.selected_indices_global,outliers);
end


% Show selected spots
% figure
% scatter(roixy(1,params.selected_indices_global),roixy(2,params.selected_indices_global),20,'filled', 'MarkerFaceAlpha', 0.5)
% axis square
% pause

% Allocation and initialization
thetatry = theta_global;
[thetamin,thetamax] = thetalimits_nat(params);

alambda = alambda_global;
%alambda = params.alambda0_global; % reset alambda global at the start (reduces performance)

alambdafac = params.alambdafac_global;
merit_total = 0;
monitor = 2*tollim;
iiter = 1;
flip_z_net = false;

%% Global update loop
fprintf('\nStart global update %i\n',iiter_total);
fprintf('Selected %i spots for global update\n',numel(params.selected_indices_global));

while ((iiter<=max_global_iterations) && (monitor>tollim || iiter<=min_global_iterations))
    fprintf('iteration %i\n',iiter);

    % Calculate total merit.
    [merittry_total,merittry_allspots,gradtry_total,Hessiantry_total,dmudthetatry_allspots] = get_merit_nat(theta_local,thetatry,allspots,roixy,params);
    
    % Check if merit is improved
    dmerit = merittry_total - merit_total;

    if (dmerit < 0 && iiter > 1) % update not accepted
        alambda = alambdafac*alambda;
  
    else % update accepted
        if iiter>1
            alambda = alambda/alambdafac;
        end
        theta = thetatry;
        thetaretry = theta;
        dmudtheta_allspots = dmudthetatry_allspots;
        merit_total = merittry_total; % sum of merit over all spots
        merit_allspots = merittry_allspots; % merit for each spot
        monitor = abs(dmerit/merit_total);
        grad_total = gradtry_total;
        Hessian_total = Hessiantry_total;
    end

    % Calculate global update for the next iteration
    [thetatry,flip_z,invertible] = thetaupdate_nat(theta,thetamax,thetamin,thetaretry,grad_total,Hessian_total,alambda,params);
    
    if flip_z
        theta_local(3,:) = -1*theta_local(3,:);
        flip_z_net = ~flip_z_net;
    end

    % Store values and update counter
    thetastore_global(:,end+1) = theta;
    meritstore_global(end+1) = merit_total;
    iiter = iiter + 1;

end % end of iiter<=max_global_iterations && monitor>tollim

% Store values
theta_global = theta;
alambda_global = alambda;
Niters_global(iiter_total) = iiter-1;

end % end of function
