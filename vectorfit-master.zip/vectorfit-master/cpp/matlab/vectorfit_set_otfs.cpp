/* vectorfit_set_otfs
 * vectorfit_set_otfs(vectorfit_handle, otfs, spot_otf_indices);
 * Sets OTFs and the OTF index per spot from externally computed values.
 * - gammas: the gamma coefficients that determine how the Zernike
 *   Coefficients depend on x,y.
 *
*/

#include "vectorfit_mex.hpp"
#include "vectorfit_fitter.hpp"
#include "compute/zernike_coefficients.h"
#include "array/operators.h"


class MexFunction : public VectorfitMexFunction {
public:
    using Struct = matlab::data::Struct;
    using StructArray = matlab::data::StructArray;

    void execute(ArgumentList outputs, ArgumentList inputs) override {
        // Obtain fitter object handle
        const uint64_t handle = inputs[0][0];
        VectorfitFitter* fitter = VectorfitMemoryManager::get(handle);
        // Obtain otfs and spot_otf_indices
        TypedArray<std::complex<double>> input_otfs = std::move(inputs[1]);
        TypedArray<int32_t> input_spot_otf_indices = std::move(inputs[2]);

        // Define input
        matlab::data::ArrayDimensions input_otfs_dims = input_otfs.getDimensions();
        int input_num_otfs = (int)input_otfs_dims[0];
        std::vector<int> input_otfs_size(std::next(input_otfs_dims.begin()), input_otfs_dims.end());
        // Notfz of the input is set to 1 for the 2D case
        if (input_otfs_size.size() < 3) {
            input_otfs_size.push_back(1);
        }
        std::vector<int> fitter_otfs_size{
            fitter->fitter().params().Notfx,
            fitter->fitter().params().Notfy,
            fitter->fitter().params().Notfz
        };
        Arr4D<std::complex<double>> otfs_reversed_axes(
            input_otfs_size[2],
            input_otfs_size[1],
            input_otfs_size[0],
            input_num_otfs);
        Arr1D<int> spot_otf_indices((int)input_spot_otf_indices.getDimensions()[0]);
        // Verify dimensions
        if ( (input_num_otfs != fitter->fitter().num_otfs())
            || (input_otfs_size != fitter_otfs_size)
        ) {
            feval_error(
                "OTFs must be of size ("
                + std::to_string(fitter->fitter().num_otfs()) + ","
                + std::to_string(fitter_otfs_size[0]) + ","
                + std::to_string(fitter_otfs_size[1]) + ","
                + std::to_string(fitter_otfs_size[2]) + ") but instead got ("
                + std::to_string(input_num_otfs) + ","
                + std::to_string(input_otfs_size[0]) + ","
                + std::to_string(input_otfs_size[1]) + ","
                + std::to_string(input_otfs_size[2]) + ")"
            );
        }
        if (input_spot_otf_indices.getDimensions()[0] != fitter->fitter().num_spots()) {
            feval_error(
                "spot_otf_indices must be of size " + std::to_string(fitter->fitter().num_spots())
            );
        }
        // Only colum major memory layout is supported (default in Matlab)
        if (input_otfs.getMemoryLayout() != matlab::data::MemoryLayout::COLUMN_MAJOR) {
            feval_error("OTF data must have column major memory layout");
        }

        // Populate data. Because memory layout is row major in C++ and col major in Matlab,
        // the copy of OTF data is done with the axes in reverse order. The axes are reversed
        // back to their original order when passed to set_otfs().
        std::copy(input_otfs.cbegin(), input_otfs.cend(), otfs_reversed_axes.data());
        std::copy(input_spot_otf_indices.cbegin(), input_spot_otf_indices.cend(), spot_otf_indices.data());

        // Set OTF data
        View4D<std::complex<double>> otfs = otfs_reversed_axes.reorder_axes({3, 2, 1, 0});
        fitter->fitter().set_otfs(otfs, spot_otf_indices);
    }

    void checkArguments(ArgumentList outputs, ArgumentList inputs) {
        // inputs[0]: handle: uint64
        // inputs[1]: otfs: 3D complex double array
        // inputs[2]: spot_otf_indices: int array
        // Check number of input arguments
        if (inputs.size() != 3) {
            feval_error("Number of required inputs is 3: (vectorfit_handle, otfs, spot_otf_indices)");
        }
        // Input 1 must be a uint64_t scalar
        if (inputs[0].getType() != ArrayType::UINT64 ||
            inputs[0].getNumberOfElements() != 1) {
            feval_error("Input 1 must be a vectorfit handle in the form of a uint64 scalar");
        }

        // Input 1 must be otfs with complex doubles
        if (inputs[1].getType() != ArrayType::COMPLEX_DOUBLE) {
            feval_error("Input 1 'otfs' must be a complex double array");
        }

        // Input 2 input must be spot_otf_indices with ints
        if (inputs[2].getType() != ArrayType::INT32) {
            feval_error("Input 2 'spot_otf_indices' must be an integer array");
        }

        // No outputs
        if (outputs.size() != 0) {
            feval_error("No output are returned");
        }
    }
};
