#pragma once

#include <complex>
#include <array>

#include "compute/fft.h"
#include "array/container.h"

class CztPlan {
public:
	CztPlan(int nrows, int ncols, double xsize, double qsize) {
		resize(nrows, ncols, xsize, qsize);
	}
	CztPlan(): CztPlan(0, 0, 0.0, 0.0) {}
	CztPlan(CztPlan&&) noexcept = default;
	CztPlan(const CztPlan&) = default;
	CztPlan& operator=(CztPlan&&) = default;
	CztPlan& operator=(const CztPlan&) = default;

	void resize(int nrows, int ncols, double xsize, double qsize);
	void execute(View2D<std::complex<double>> input, WriteView2D<std::complex<double>> output);

	static void PreChirpZ(
			int n, int m,
			double xsize, double qsize,
			Arr1D<std::complex<double>>& Ax,
			Arr1D<std::complex<double>>& Bx,
			Arr1D<std::complex<double>>& Dx);

	// For debugging
	View1D<std::complex<double>> ax() const { return Ax; }
	View1D<std::complex<double>> bx() const { return Bx; }
	View1D<std::complex<double>> dx() const { return Dx; }

private:
	int nrows_ = 0;
	int ncols_ = 0;
	FFT1DPlan fft_ {};
	Arr1D<std::complex<double>> Ax;
	Arr1D<std::complex<double>> Bx;
	Arr1D<std::complex<double>> Dx;
	Arr2D<std::complex<double>> IntermediateImage;
};

void czt(View2D<std::complex<double>> input, WriteView2D<std::complex<double>> output);

class CztPlan3D {
public:
	CztPlan3D(shape_t<3> input_shape, shape_t<3> output_shape, std::array<double, 3> input_sizes, std::array<double, 3> output_sizes) {
		resize(input_shape, output_shape, input_sizes, output_sizes);
	}
	CztPlan3D(): CztPlan3D({0, 0, 0}, {0, 0, 0}, {0.0, 0.0, 0.0}, {0.0, 0.0, 0.0}) {}
	CztPlan3D(CztPlan3D&&) noexcept = default;
	CztPlan3D(const CztPlan3D&) = default;
	CztPlan3D& operator=(CztPlan3D&&) = default;
	CztPlan3D& operator=(const CztPlan3D&) = default;

	void resize(shape_t<3> input_shape, shape_t<3> output_shape, std::array<double, 3> input_sizes, std::array<double, 3> output_sizes);
	void execute(View3D<std::complex<double>> input, WriteView3D<std::complex<double>> output);

	// PreChirpZ in a single dimension
	static void PreChirpZ(
		index_t N,
		index_t M,
		double xsize,
		double qsize,
		Arr1D<std::complex<double>>& Ax,
		Arr1D<std::complex<double>>& Bx,
		Arr1D<std::complex<double>>& Dx);

private:
	struct DimProps {
		index_t M;
		index_t N;
		index_t L;
		double xsize;
		double qsize;
		FFT1DPlan fft {};
		Arr1D<std::complex<double>> Ax;
		Arr1D<std::complex<double>> Bx;
		Arr1D<std::complex<double>> Dx;
	};

	DimProps dim_props_[3];
	Arr3D<std::complex<double>> IntermediateImages[2];
};
